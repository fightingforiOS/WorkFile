//
//  ReminItemView.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/10.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ReminItemView : UIView
- (instancetype)initWithFrame:(CGRect)frame ImageHead:(UIImage*)imgHead Title1:(NSString* )title1 Title2:(NSString* )title2;

@end

NS_ASSUME_NONNULL_END
