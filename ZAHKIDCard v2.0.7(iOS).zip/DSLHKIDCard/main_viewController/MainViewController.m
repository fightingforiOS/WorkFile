//
//  MainViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/10.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "MainViewController.h"

#import "DSLHKBaseIDCardViewController.h"
#import "DSLHKIDCardViewController.h"
#import "DSLHKIDCardInDeskViewController.h"
#import "DSLHKIDCardBundle.h"
#import "AppDelegate.h"
#import "UIColor+DSLCHexColor.h"
#import "RemindViewController.h"

@interface MainViewController ()

@property(nonatomic, strong) UILabel* labelSelectIDCard;
@property(nonatomic, strong) UIImageView* imgViewNewIDCardBk;
@property(nonatomic, strong) UIImageView* imgViewOldIDCardBk;
@property(nonatomic, strong) UIButton* btnNewIDcard;
@property(nonatomic, strong) UIButton* btnOldIDcard;
@property(nonatomic, strong) UILabel* labelAppVersion;
//选择是否是Lite版本模式
@property(nonatomic, strong) UISwitch* switchLiteMode;
@property(nonatomic, strong) UILabel* labelLiteMode;
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIImageView *backgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"main_bk"]];
    backgroundImageView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [self.view addSubview:backgroundImageView];
    
    UIImageView *mainLogoImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"main_logo"]];
    mainLogoImageView.frame = CGRectMake((self.view.bounds.size.width-202)/2, 60, 202, 73);
    [self.view addSubview:mainLogoImageView];
    
    UIButton* backBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 40, 50, 50)];
       
    UIImage* image =  [UIImage imageNamed:@"closeVideo"];
       
    [backBtn setImage:image forState:UIControlStateNormal];
    [backBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.view addSubview:backBtn];
       [backBtn addTarget:self action:@selector(doPopBack:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.labelSelectIDCard];
    self.labelSelectIDCard.frame = CGRectMake(0.0, mainLogoImageView.frame.origin.y+mainLogoImageView.frame.size.height+20, self.view.bounds.size.width, 26);
    
    [self.view addSubview:self.imgViewNewIDCardBk];
    self.imgViewNewIDCardBk.frame = CGRectMake((self.view.bounds.size.width-290)/2, self.labelSelectIDCard.frame.origin.y+self.labelSelectIDCard.frame.size.height+20.0, 290, 180);
    
    [self.imgViewNewIDCardBk addSubview:self.btnNewIDcard];
    self.btnNewIDcard.frame = CGRectMake((self.imgViewNewIDCardBk.bounds.size.width-48.0)/2, (self.imgViewNewIDCardBk.bounds.size.height-48.0)/2, 48.0, 48.0);
    
    [self.view addSubview:self.imgViewOldIDCardBk];
    self.imgViewOldIDCardBk.frame = CGRectMake((self.view.bounds.size.width-290)/2, self.labelSelectIDCard.frame.origin.y+self.imgViewNewIDCardBk.frame.size.height+40.0, 290, 180);
    
    [self.imgViewOldIDCardBk addSubview:self.btnOldIDcard];
    self.btnOldIDcard.frame = CGRectMake((self.imgViewOldIDCardBk.bounds.size.width-48.0)/2, (self.imgViewOldIDCardBk.bounds.size.height-48.0)/2, 48.0, 48.0);
      
    
    [self.view addSubview:self.labelAppVersion];
    self.labelAppVersion.frame = CGRectMake(0.0, self.view.bounds.size.height-40, self.view.bounds.size.width, 20);
    
    [self.view addSubview:self.labelLiteMode];
    self.labelLiteMode.frame = CGRectMake(mainLogoImageView.frame.origin.x,self.imgViewOldIDCardBk.frame.origin.y+190, 138.0, 32.0);
    
    [self.view addSubview:self.switchLiteMode];
    self.switchLiteMode.frame = CGRectMake(self.labelLiteMode.frame.origin.x+self.labelLiteMode.frame.size.width+8.0,self.imgViewOldIDCardBk.frame.origin.y+190, 40.0, 32.0);
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}
- (UILabel* )labelLiteMode
{
    if(_labelLiteMode == nil)
    {
        _labelLiteMode = [[UILabel alloc] init];
        _labelLiteMode.textColor = [UIColor whiteColor];
        _labelLiteMode.textAlignment = NSTextAlignmentCenter;
        _labelLiteMode.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelLiteMode.text = [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title14"];
    }
    return _labelLiteMode;
}
- (UISwitch* )switchLiteMode
{
    if(_switchLiteMode == nil)
    {
        _switchLiteMode = [[UISwitch alloc] init];
    }
    
    return _switchLiteMode;
}

- (UILabel* )labelAppVersion
{
    if(_labelAppVersion == nil)
    {
        _labelAppVersion = [[UILabel alloc] init];
        _labelAppVersion.textColor = [UIColor whiteColor];
        _labelAppVersion.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelAppVersion.textAlignment = NSTextAlignmentCenter;
        _labelAppVersion.text = [NSString stringWithFormat:@"App %@: %@", [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title9"], [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
    }
    return  _labelAppVersion;
}

- (UIButton* )btnNewIDcard
{
    if(_btnNewIDcard == nil)
    {
        _btnNewIDcard = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnNewIDcard setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title16"] forState:UIControlStateNormal];
        [_btnNewIDcard setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnNewIDcard setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
        _btnNewIDcard.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:19.2];
        [_btnNewIDcard addTarget:self action:@selector(clickNewIDCard:) forControlEvents:UIControlEventTouchUpInside];
        _btnNewIDcard.layer.cornerRadius = 24;
    }
    
    return _btnNewIDcard;
}

- (UIButton* )btnOldIDcard
{
    if(_btnOldIDcard == nil)
    {
        _btnOldIDcard = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOldIDcard setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title17"] forState:UIControlStateNormal];
        [_btnOldIDcard setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnOldIDcard setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
        _btnOldIDcard.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:19.2];
        [_btnOldIDcard addTarget:self action:@selector(clickOldIDCard:) forControlEvents:UIControlEventTouchUpInside];
        _btnOldIDcard.layer.cornerRadius = 24;
    }
    
    return _btnOldIDcard;
}

- (UIImageView* )imgViewNewIDCardBk
{
    if(_imgViewNewIDCardBk == nil)
    {
        _imgViewNewIDCardBk = [[UIImageView alloc] init];
        _imgViewNewIDCardBk.image = [UIImage imageNamed:@"main_new_card"];
        _imgViewNewIDCardBk.userInteractionEnabled = YES;
    }
    
    return _imgViewNewIDCardBk;
}

- (UIImageView* )imgViewOldIDCardBk
{
    if(_imgViewOldIDCardBk == nil)
    {
        _imgViewOldIDCardBk = [[UIImageView alloc] init];
        _imgViewOldIDCardBk.image = [UIImage imageNamed:@"main_old_card"];
        _imgViewOldIDCardBk.userInteractionEnabled = YES;
    }
    
    return _imgViewOldIDCardBk;
}

- (UILabel* )labelSelectIDCard
{
    if(_labelSelectIDCard == nil)
    {
        _labelSelectIDCard = [[UILabel alloc] init];
        _labelSelectIDCard.textColor = [UIColor whiteColor];
        _labelSelectIDCard.font = [UIFont fontWithName:@"PingFangSC-Regular" size:20];
        _labelSelectIDCard.textAlignment = NSTextAlignmentCenter;
        _labelSelectIDCard.text = [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title15"];
    }
    return  _labelSelectIDCard;
}

- (void)clickNewIDCard:(id)sender
{
    [self gotoRemindVc: DSLHKIDCardTypeApp_2018];
}

- (void)clickOldIDCard:(id)sender
{
    [self gotoRemindVc: DSLHKIDCardTypeApp_2003];
}


- (void)gotoRemindVc:(DSLHKIDCardTypeApp) recType
{
    RemindViewController* vc = [[RemindViewController alloc] init];
    vc.recType = recType;
    vc.useLiteVersion = self.switchLiteMode.on;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)doPopBack:(id)sender
{
    [[AppDelegate sharedInstance] gotoHKIDCard_MCV];
}
@end
