//
//  DSLHKBaseIDCardViewController+Statistics.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/5/26.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DSLHKBaseIDCardViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DSLHKBaseIDCardViewController (Statistics)

- (void)initStatisticsData;

- (void)collectionStatisticsBaseInfo;

- (NSMutableDictionary* )getStatisticsBaseInfo;

- (void)recordFail:(int)failReason DurationTime:(double)durationTime SessionID:(NSString* )sessionID;

- (void)recordSuccess:(int)failCount DurationTime:(double)durationTime VideoSize:(double)fileSize VideoTimeLenght:(double)videoTimeLenght SessionID:(NSString* )sessionID;

@end

NS_ASSUME_NONNULL_END
