//
//  UploadVideoTipView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2018/12/17.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import "UploadVideoTipView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"

@interface UploadVideoTipView()
@property(nonatomic, strong) UIImageView* imgViewTopBk;
@property(nonatomic, strong) UIImageView* imgViewBk;
@property(nonatomic, strong) UILabel* titleLabel;

@property(nonatomic,strong)UIButton *btnAgree;
@property(nonatomic,strong)UILabel *labelAgree;

@property(nonatomic,strong)UIButton *btnRefuse;
@property(nonatomic,strong)UILabel *labelRefuse;

@property(nonatomic,strong)UIButton *btnNeverTip;
@property(nonatomic,strong)UILabel *labelNeverTip;

@property(nonatomic,strong)UIButton *btnOk;

@property(nonatomic, assign) int selectedType;
@property(nonatomic, assign) BOOL bNeverTip;

@end

@implementation UploadVideoTipView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    [self addSubview:self.imgViewBk];
    self.imgViewBk.frame = CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height);
    
//    [self addSubview:self.imgViewTopBk];
//    self.imgViewTopBk.frame = CGRectMake((self.bounds.size.width-150)/2, 0.0, 150, 130);

    [self addSubview:self.titleLabel];
    self.titleLabel.frame = CGRectMake(25.0, 160, self.bounds.size.width-50.0, 42+22);
    // self.titleLabel.frame = CGRectMake(25.0, 160, self.bounds.size.width-45/2, 42);
    [self addSubview:self.btnAgree];
    self.btnAgree.frame = CGRectMake(36.0, self.titleLabel.frame.origin.y+self.titleLabel.frame.size.height+10, 30+140-30+40+80, 30);
//    self.btnAgree.layer.borderWidth = 1;
//    self.btnAgree.layer.borderColor = [UIColor redColor].CGColor;
    //[self addSubview:self.labelAgree];
   // self.labelAgree.frame = CGRectMake(self.btnAgree.frame.origin.x+self.btnAgree.frame.size.width+10, self.btnAgree.frame.origin.y+5, 140, 18);
    
    [self addSubview:self.btnRefuse];
    self.btnRefuse.frame = CGRectMake(36.0, self.btnAgree.frame.origin.y+self.btnAgree.frame.size.height+10, 100+20+40, 30);
//    self.btnRefuse.layer.borderWidth = 1;
//    self.btnRefuse.layer.borderColor = [UIColor redColor].CGColor;
//    [self addSubview:self.labelRefuse];
//    self.labelRefuse.frame = CGRectMake(self.btnRefuse.frame.origin.x+self.btnRefuse.frame.size.width+10, self.btnRefuse.frame.origin.y+5, 140, 18);
    
    [self addSubview:self.btnNeverTip];
    self.btnNeverTip.frame = CGRectMake(38.0, self.btnRefuse.frame.origin.y+self.btnRefuse.frame.size.height+20, 100+40, 20);
//    self.btnNeverTip.layer.borderWidth = 1;
//    self.btnNeverTip.layer.borderColor = [UIColor redColor].CGColor;
//    [self addSubview:self.labelNeverTip];
//    self.labelNeverTip.frame = CGRectMake(self.btnNeverTip.frame.origin.x+self.btnNeverTip.frame.size.width+10, self.btnNeverTip.frame.origin.y+5, 140, 16);
    
    [self addSubview:self.btnOk];
    self.btnOk.frame = CGRectMake(35.0, self.bounds.size.height-65-5, 236, 44);
    
    
    NSString* selected = [[NSUserDefaults standardUserDefaults] objectForKey:@"selected"];
    
    if(selected != nil && [selected isEqualToString:@"100"])
    {
        [self updateBtnStatus:0];
    }
    else if(selected != nil && [selected isEqualToString:@"200"])
    {
        //[self updateBtnStatus:1];
        [self addObject:@"100" forKey:@"selected"]; //同意
        [self updateBtnStatus:0];
    }
}


- (UIImageView* )imgViewBk
{
    if(_imgViewBk == nil)
    {
        _imgViewBk = [[UIImageView alloc] init];
        _imgViewBk.image = [UIImage imageNamed:@"bk"];
    }
    return _imgViewBk;
}

- (UILabel* )titleLabel
{
    if(_titleLabel == nil)
    {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor dslc_colorWithHexString:@"0x130A31"];
        _titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:15];
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        _titleLabel.text = [DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip1"];
        _titleLabel.numberOfLines = 3;
    }
    
    return _titleLabel;
}

- (UIButton* )btnAgree
{
    if(_btnAgree == nil)
    {
        _btnAgree = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnAgree setImage:[UIImage imageNamed:@"status_normal_single"] forState:UIControlStateNormal];
        _btnAgree.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_btnAgree setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
        [_btnAgree setTitleEdgeInsets:UIEdgeInsetsMake(0, 8, 0, 0)];
        [_btnAgree setTitle:[DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip2"] forState:UIControlStateNormal];
        _btnAgree.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:17];
        [_btnAgree setTitleColor:[UIColor dslc_colorWithHexString:@"0x130A31"] forState:UIControlStateNormal];
        [_btnAgree addTarget:self action:@selector(clickAgree:) forControlEvents:UIControlEventTouchUpInside];
//        _btnAgree.layer.borderColor = [UIColor redColor].CGColor;
//        _btnAgree.layer.borderWidth = 1.0;
    }
    return  _btnAgree;
}

- (UILabel* )labelAgree
{
    if(_labelAgree == nil)
    {
        _labelAgree = [[UILabel alloc] init];
        _labelAgree.textColor = [UIColor whiteColor];
        _labelAgree.font = [UIFont fontWithName:@"PingFangSC-Regular" size:17];
        _labelAgree.textAlignment = NSTextAlignmentLeft;
        _labelAgree.text = [DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip2"];
//        _labelAgree.layer.borderColor = [UIColor blueColor].CGColor;
//        _labelAgree.layer.borderWidth = 1.0;
    }
    
    return _labelAgree;
}

- (UIButton* )btnRefuse
{
    if(_btnRefuse == nil)
    {
        _btnRefuse = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnRefuse setImage:[UIImage imageNamed:@"status_normal_single"] forState:UIControlStateNormal];
        _btnRefuse.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_btnRefuse setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
         [_btnRefuse setTitleEdgeInsets:UIEdgeInsetsMake(0, 8, 0, 0)];
        [_btnRefuse setTitle:[DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip3"] forState:UIControlStateNormal];
        [_btnRefuse setTitleColor:[UIColor dslc_colorWithHexString:@"0x130A31"] forState:UIControlStateNormal];
        _btnRefuse.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:17];
        
        [_btnRefuse addTarget:self action:@selector(clickRefuse:) forControlEvents:UIControlEventTouchUpInside];
//        _btnRefuse.layer.borderColor = [UIColor redColor].CGColor;
//        _btnRefuse.layer.borderWidth = 1.0;
    }
    return  _btnRefuse;
}

- (UILabel* )labelRefuse
{
    if(_labelRefuse == nil)
    {
        _labelRefuse = [[UILabel alloc] init];
        _labelRefuse.textColor = [UIColor whiteColor];
        _labelRefuse.font = [UIFont fontWithName:@"PingFangSC-Regular" size:17];
        _labelRefuse.textAlignment = NSTextAlignmentLeft;
        _labelRefuse.text = [DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip3"];
//        _labelRefuse.layer.borderColor = [UIColor blueColor].CGColor;
//        _labelRefuse.layer.borderWidth = 1.0;
    }
    
    return _labelRefuse;
}

- (UIButton* )btnNeverTip
{
    if(_btnNeverTip == nil)
    {
        _btnNeverTip = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnNeverTip setImage:[UIImage imageNamed:@"status_normal_multiple"] forState:UIControlStateNormal];
        _btnNeverTip.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_btnNeverTip setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
        [_btnNeverTip setTitleEdgeInsets:UIEdgeInsetsMake(0, 8, 0, 0)];
        [_btnNeverTip setTitle:[DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip4"] forState:UIControlStateNormal];
        [_btnNeverTip setTitleColor:[UIColor dslc_colorWithHexString:@"0x130A31"] forState:UIControlStateNormal];
        _btnNeverTip.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:13];
        [_btnNeverTip addTarget:self action:@selector(clickNeverTip:) forControlEvents:UIControlEventTouchUpInside];
//        _btnNeverTip.layer.borderColor = [UIColor redColor].CGColor;
//        _btnNeverTip.layer.borderWidth = 1.0;
    }
    return  _btnNeverTip;
}

- (UILabel* )labelNeverTip
{
    if(_labelNeverTip == nil)
    {
        _labelNeverTip = [[UILabel alloc] init];
        _labelNeverTip.textColor = [UIColor whiteColor];
        _labelNeverTip.font = [UIFont fontWithName:@"PingFangSC-Regular" size:13];
        _labelNeverTip.textAlignment = NSTextAlignmentLeft;
        _labelNeverTip.text = [DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip4"];
//        _labelNeverTip.layer.borderColor = [UIColor blueColor].CGColor;
//        _labelNeverTip.layer.borderWidth = 1.0;
    }
    
    return _labelNeverTip;
}

- (UIButton* )btnOk
{
    if(_btnOk == nil)
    {
        _btnOk = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOk setTitle:[DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip5"] forState:UIControlStateNormal];
        [_btnOk addTarget:self action:@selector(clickOk:) forControlEvents:UIControlEventTouchUpInside];
        [_btnOk setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnOk setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
        _btnOk.layer.cornerRadius = 22.0;
        _btnOk.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:19];
    }
    return  _btnOk;
}

- (void)clickAgree:(id)sender
{
    [self updateBtnStatus:0];
    [self addObject:@"100" forKey:@"selected"]; //同意
}

- (void)clickRefuse:(id)sender
{
    [self updateBtnStatus:1];
    [self addObject:@"200" forKey:@"selected"]; //拒绝
}

- (void)clickNeverTip:(id)sender
{
    [self updateBtnStatus:2];
    if(self.bNeverTip)
    {
        [self addObject:@"300" forKey:@"neverTip"]; //不再提醒
    }
    else
    {
        [self addObject:@"" forKey:@"neverTip"]; //不再提醒
    }
}

- (void)addObject:(id)obj forKey:(NSString* )key
{
    if(obj == nil || [self isEmptyKey:key])
    {
        return;
    }
    
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject: obj forKey: key];
    [defaults synchronize];
}

-(BOOL)isEmptyKey:(NSString *)key{
    BOOL flag = NO;
    
    if (key == nil || [@"" isEqualToString:[key stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]]) {
        flag = YES;
    }
    return flag;
}
- (void)updateBtnStatus:(int)selectedType
{
    self.selectedType = selectedType;
    if(selectedType == 2)
    {
        self.bNeverTip = !self.bNeverTip;
    }

    switch (selectedType)
    {
        case 0:
        {
            [self.btnAgree setImage:[UIImage imageNamed:@"status_selected_single"] forState:UIControlStateNormal];
            [self.btnRefuse setImage:[UIImage imageNamed:@"status_normal_single"] forState:UIControlStateNormal];
        }
            break;
             
        case 1:
        {
            [self.btnAgree setImage:[UIImage imageNamed:@"status_normal_single"] forState:UIControlStateNormal];
            [self.btnRefuse setImage:[UIImage imageNamed:@"status_selected_single"] forState:UIControlStateNormal];
        }
             break;
            
        case 2:
        {
            if(self.bNeverTip)
            {
                [self.btnNeverTip setImage:[UIImage imageNamed:@"status_selected_multiple"] forState:UIControlStateNormal];
            }
            else
            {
                [self.btnNeverTip setImage:[UIImage imageNamed:@"status_normal_multiple"] forState:UIControlStateNormal];
            }

        }
            break;
        default:
            break;
    }
}

- (void)clickOk:(id)sender
{
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(clickUploadVideoTipOK)])
        {
            [self.myDelegate clickUploadVideoTipOK];
        }
    }
}

@end
