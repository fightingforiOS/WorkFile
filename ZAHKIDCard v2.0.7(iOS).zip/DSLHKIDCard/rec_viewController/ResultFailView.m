//
//  ResultFailView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2018/12/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import "ResultFailView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"
@interface ResultFailView()

@property(nonatomic, strong) UIImageView* imgViewBK;
@property(nonatomic, strong) UIImageView* imgViewHead;
@property(nonatomic, strong) UILabel* labelTitle;
@property(nonatomic, strong) UILabel* labelDes;
@property(nonatomic,strong)UIButton *btnOk;
@property(nonatomic,strong)UIButton *btnViewGuide;

@end

@implementation ResultFailView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    self.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.imgViewHead];
    self.imgViewHead.frame = CGRectMake((self.frame.size.width-193)/2, 30.0, 193, 120);
    [self addSubview:self.labelTitle];
    self.labelTitle.frame = CGRectMake(0.0, 169, self.frame.size.width, 30.0);
    [self addSubview:self.labelDes];
    if([DSLHKIDCardBundle isChineseLanguage])
    {
        self.labelDes.frame = CGRectMake(0.0, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+8.0, self.frame.size.width, 20.0);
    }
    else
    {
        self.labelDes.frame = CGRectMake(0.0, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+8.0, self.frame.size.width, 50.0);
    }
    [self addSubview:self.btnOk];
    self.btnOk.frame = CGRectMake((self.frame.size.width-270)/2, 260, 270, 46);
    [self addSubview:self.btnViewGuide];
    self.btnViewGuide.frame = CGRectMake(10.0, self.btnOk.frame.origin.y+self.btnOk.frame.size.height+20.0, self.frame.size.width-20.0, 20);
}

- (void)showResultFailView:(DSLHKIDCardRecFailType)failType
{
    NSString* imgName = @"";
    
    switch (failType) {
        case DSLHKIDCardRecFailType_OverSpeed: //移动速度太快
            imgName = @"resultFail_overspeed_bk";
            
            if([self isCurrentLanguageEn])
            {
                imgName = @"resultFail_overspeed_bk_english";
            }

            self.imgViewBK.image = [UIImage imageNamed:imgName];
            break;
        case DSLHKIDCardRecFailType_Slices: //反光
            imgName = @"resultFail_dark";
            self.imgViewHead.image = [UIImage imageNamed:imgName];
            self.labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title7"];
            self.labelDes.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title8"];
            break;
        case DSLHKIDCardRecFailType_Default: //普通错误
            
            imgName = @"resultFail_dark";
            self.imgViewHead.image = [UIImage imageNamed:imgName];
            self.labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title7"];
            self.labelDes.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title8"];
        
            break;
        case DSLHKIDCardRecFailType_OverTime: //超时错误
            
            imgName = @"resultFail_overtime";
            self.imgViewHead.image = [UIImage imageNamed:imgName];
            self.labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title3"];
            self.labelDes.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title4"];
            break;
        case DSLHKIDCardRecFailType_LostObject: //失去目标错误
            
            imgName = @"resultFail_lost";
            self.imgViewHead.image = [UIImage imageNamed:imgName];
            self.labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title5"];
            self.labelDes.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title6"];
            break;
        case DSLHKIDCardRecFailType_Dark: //光线过暗
            
            imgName = @"resultFail_dark";
            self.imgViewHead.image = [UIImage imageNamed:imgName];
            self.labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title9"];
            self.labelDes.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title10"];
            break;
        case DSLHKIDCardRecFailType_Invalid: //不正确的操作动作，重新开始识别
        {
            imgName = @"resultFail_dark";
            self.imgViewHead.image = [UIImage imageNamed:imgName];
            self.labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title7"];
            self.labelDes.text = [DSLHKIDCardBundle IDCardBundleString:@"result_fail_title8"];
            break;
        }
        break;
        case DSLHKIDCardRecFailType_IDCard2003_Postion: //证件位置放置不正确，重新开始识别
        {
            imgName = @"resultFail_idcard2003_position_error_bk";
                              
            if([self isCurrentLanguageEn])
            {
                imgName = @"resultFail_idcard2003_position_error_bk_english";
            }
                                                            
            self.imgViewBK.image = [UIImage imageNamed:imgName];
        }
        break;
        case DSLHKIDCardRecFailType_IDCard2018_Postion: //证件位置放置不正确，重新开始识别
        {
            imgName = @"resultFail_idcard2018_position_error_bk";
                              
            if([self isCurrentLanguageEn])
            {
                imgName = @"resultFail_idcard2018_position_error_bk_english";
            }
                                                            
            self.imgViewBK.image = [UIImage imageNamed:imgName];
        }
        break;
        case DSLHKIDCardRecFailType_VideoQuality_Low: //视频质量低
        {
            imgName = @"resultFail_bk";
                    
            if([self isCurrentLanguageEn])
            {
                imgName = @"resultFail_bk_english";
            }
            
            self.imgViewBK.image = [UIImage imageNamed:imgName];
        }
        break;
        default:
            break;
    }
    
    self.hidden = NO;
}

- (void)delayClickOk
{
    [self clickOk:nil];
}

- (UILabel* )labelTitle
{
    if (_labelTitle == nil) {
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.font = [UIFont fontWithName:@"PingFangSC-Medium" size:24];
        _labelTitle.text = @"";
        
    }
    return _labelTitle;
}

- (UILabel* )labelDes
{
    if (_labelDes == nil) {
        _labelDes = [[UILabel alloc] init];
        _labelDes.textAlignment = NSTextAlignmentCenter;
        _labelDes.textColor = [UIColor blackColor];
        _labelDes.font = [UIFont fontWithName:@"PingFangSC-Medium" size:15];
        _labelDes.text = @"";
        _labelDes.lineBreakMode = NSLineBreakByWordWrapping;
        _labelDes.numberOfLines = 0;
        
    }
    return _labelDes;
}

- (UIImageView* )imgViewHead
{
    if(_imgViewHead == nil)
    {
        _imgViewHead = [[UIImageView alloc] init];
        _imgViewHead.image = [UIImage imageNamed:@"resultFail_lost"];
    }
    return _imgViewHead;
}

- (UIButton* )btnOk
{
    if(_btnOk == nil)
    {
        _btnOk = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOk setTitle:[DSLHKIDCardBundle IDCardBundleString:@"result_fail_title1"] forState:UIControlStateNormal];
        [_btnOk addTarget:self action:@selector(clickOk:) forControlEvents:UIControlEventTouchUpInside];
        [_btnOk setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnOk setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x1FC7EC"]];
        _btnOk.layer.cornerRadius = 22.0;
        _btnOk.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
    }
    return  _btnOk;
}

- (UIButton* )btnViewGuide
{
    if(_btnViewGuide == nil)
    {
        _btnViewGuide = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnViewGuide setTitle:[DSLHKIDCardBundle IDCardBundleString:@"result_fail_title2"] forState:UIControlStateNormal];
        [_btnViewGuide addTarget:self action:@selector(clickGuide:) forControlEvents:UIControlEventTouchUpInside];
        [_btnViewGuide setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateNormal];
        _btnViewGuide.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
    }
    return  _btnViewGuide;
}

- (void)clickGuide:(id)sender
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayClickOk) object:nil];
       
       self.hidden = YES;
       if(self.myDelegate)
       {
           if([self.myDelegate respondsToSelector:@selector(clickGuide)])
           {
               [self.myDelegate clickGuide];
           }
       }
}
- (void)clickOk:(id)sender
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayClickOk) object:nil];
    
    self.hidden = YES;
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(clickFailOK)])
        {
            [self.myDelegate clickFailOK];
        }
    }
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

@end
