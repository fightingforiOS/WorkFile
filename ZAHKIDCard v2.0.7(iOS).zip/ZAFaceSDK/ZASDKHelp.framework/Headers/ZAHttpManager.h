//
//  ZAHttpManager.h
//  ZABankAndIDCardSDK
//
//  Created by chenliqun on 16/4/25.
//  Copyright © 2016年 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZAHttpManager : NSObject

+ (instancetype) shareInstance;

/**
 *  请求处理
 *
 *  @param dic        请求参数
 *  @param RequestURL url
 *  @param bSynchronized 是否同步情况
 *  @param completion 请求结果block
 *
 *  @return 当同步情况下返回值有用，
 */
- (NSDictionary* ) requestDataWithDic:(NSDictionary* ) dic RequestURL:(NSString* )url TransferMode:(BOOL) bSynchronized IsFormType:(BOOL) bFormType completion: (void(^)(id result, id requestError, NSURLResponse *response)) completion;

- (void)uploadLogData:(NSArray* )logs RequestURL:(NSString* )url completion: (void(^)(id result, id requestError, NSURLResponse *response)) completion;

@end
