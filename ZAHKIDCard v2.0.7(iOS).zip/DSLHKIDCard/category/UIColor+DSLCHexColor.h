//
//  UIColor+DSLCHexColor.h
//  ZAChicken
//
//  Created by za on 2017/7/10.
//  Copyright © 2017年 ZAChicken. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (DSLCHexColor)
+ (UIColor *)dslc_colorWithHexString:(NSString *)color;
+ (UIColor *)dslc_colorWithHexString:(NSString *)color alpha:(CGFloat)alpha;
@end
