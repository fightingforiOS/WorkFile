//
//  ResutlItemView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/22.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class ResutlItemView;

@protocol ResutlItemViewDelegate <NSObject>

- (void)clickResultItem:(ResutlItemView*) resultItemView Tag:(int)tag;

@end

@interface ResutlItemView : UIView

@property(nonatomic, assign) id<ResutlItemViewDelegate> myDelegate;

- (instancetype)initWithFrame:(CGRect)frame;
- (void)setResutlItem:(NSString* ) imgName Content:(NSString* )content AllowClick:(BOOL)allowClick ContentLines:(int)lines;
- (void)resetStatus:(NSString*) isNormal;

@end

NS_ASSUME_NONNULL_END
