//
//  DSLRecStepFinishView.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/5/7.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "DSLRecStepFinishView.h"
#import "DSLHKIDCardConfig.h"
@interface DSLRecStepFinishView()

@property(nonatomic,strong)UILabel *labelTip;
@property(nonatomic,strong)UIImageView *imgViewMark;

@end

@implementation DSLRecStepFinishView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    self.backgroundColor = [UIColor blackColor];
    self.alpha = 0.57;
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = 4.0;
    
    //[self addSubview:self.imgViewMark];
    [self addSubview:self.labelTip];
    //self.imgViewMark.frame = CGRectMake((self.frame.size.width-27)/2, 27, 27.0, 27.0);
    self.labelTip.frame = CGRectMake(0.0, (self.frame.size.height-36.0)/2, self.frame.size.width, 36.0);
}

- (UILabel* )labelTip
{
    if (_labelTip == nil) {
        _labelTip = [[UILabel alloc] init];
        _labelTip.textAlignment = NSTextAlignmentCenter;
        _labelTip.textColor = [UIColor whiteColor];
        _labelTip.font = [UIFont fontWithName:@"PingFangSC-Medium" size:32];
        _labelTip.text = @"3";
        
    }
    return _labelTip;
}

- (UIImageView* )imgViewMark
{
    if(_imgViewMark == nil)
    {
        _imgViewMark = [[UIImageView alloc] init];
        _imgViewMark.image = [UIImage imageNamed:@"rec_step_finish_mark"];
    }
    return _imgViewMark;
}

- (void)setRecStepFinishTip:(NSString* )text
{
//    if([text isEqualToString:@""] || text == nil)
//    {
//        self.labelTip.text = @"3";
//        [self performSelector:@selector(show2) withObject:nil afterDelay:0.5];
//        [self performSelector:@selector(show1) withObject:nil afterDelay:0.5];
//    }
//    else
//    {
//        self.labelTip.text = @"完成";
//    }
   
    self.labelTip.text = @"3";
    [self performSelector:@selector(show2) withObject:nil afterDelay:0.5];
    [self performSelector:@selector(show1) withObject:nil afterDelay:1.1];
}

- (void)delayHide
{
    self.hidden = YES;
}

- (void)show2
{
    self.labelTip.text = @"2";
}

- (void)show1
{
    self.labelTip.text = @"完成";
}
@end
