//
//  ZASDKAuthorization.h
//  ZASDKHelp
//
//  Created by chenliqun on 2018/4/16.
//  Copyright © 2018年 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^VoidBlock_logInfo)(NSArray* logInfos);

@interface ZASDKAuthorization : NSObject

+ (instancetype _Nullable)sharedInstance;


/**
众安sdk验权
@param completion 验证结果 -1:网络错误；0:验权通过；1验权失败; 
*/
- (void)zaSDKAuthorization: (void(^ _Nullable)(int result)) completion;

/**
 设置用户ID
 主要是用于定位反馈问题的客户，快速解决问题
 一般在用户登录成功后设置
 非必选可以不设置
 @param userID  账号ID
 */
- (void)setUserID:(nonnull NSString* )userID;

@end
