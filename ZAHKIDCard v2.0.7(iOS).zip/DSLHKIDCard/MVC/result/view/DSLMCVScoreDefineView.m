//
//  DSLMCVScoreDefineView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import "DSLMCVScoreDefineView.h"
#import "UIColor+DSLCHexColor.h"
#import "AppDelegate.h"
#import "DSLMCVIDCardBundle.h"

@interface DSLMCVScoreDefineView()

@property(nonatomic, strong) UILabel* labelTitle;
@property(nonatomic, strong) UILabel* labelLowRisk;
@property(nonatomic, strong) UILabel* labelMediumRisk;
@property(nonatomic, strong) UILabel* labelHighRisk;

@property(nonatomic, strong) UIImageView* imgViewLowRiskColor;
@property(nonatomic, strong) UIImageView* imgViewMediumRiskColor;
@property(nonatomic, strong) UIImageView* imgViewHighRiskColor;

@property(nonatomic, strong) UIButton* btnClose;

@end

@implementation DSLMCVScoreDefineView


+ (void)showScoreDefine:(float)lowScore MediumScore:(float)mediumScore HighScore:(float)highScore
{
    DSLMCVScoreDefineView* scoreDefineView = [[DSLMCVScoreDefineView alloc] init];
    
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    
    [window addSubview:scoreDefineView];
    scoreDefineView.frame = [UIScreen mainScreen].bounds;
    
    [scoreDefineView setupView];
    [scoreDefineView setScoreDefineData:lowScore MediumScore:mediumScore HighScore:highScore];
}

- (void)setScoreDefineData:(float)lowScore MediumScore:(float)mediumScore HighScore:(float)highScore
{
    self.labelHighRisk.text = [NSString stringWithFormat:@"%.3f %@（%@)", lowScore, [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title10"], [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title7"]];
    self.labelMediumRisk.text = [NSString stringWithFormat:@"%.3f~%.3f（%@)", mediumScore, highScore, [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title9"]];
    self.labelLowRisk.text = [NSString stringWithFormat:@"%.3f %@（%@)", highScore, [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title11"], [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title8"]];
}

- (void)setupView
{
    self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.85];
    
    UIView* viewBk = [[UIView alloc] init];
    viewBk.backgroundColor = [UIColor whiteColor];
    viewBk.layer.cornerRadius = 6.0;
    viewBk.alpha = 1.0;
    
    [self addSubview:viewBk];
    viewBk.frame = CGRectMake((self.bounds.size.width-230)/2, (self.bounds.size.height-190)/2, 230, 190);
    
    float w = viewBk.bounds.size.width;
    
    [viewBk addSubview:self.labelTitle];
    self.labelTitle.frame = CGRectMake(0.0, 10.0, w, 22.0);
    
    UIImageView* imgViewDottedLine = [[UIImageView alloc] init];
    imgViewDottedLine.image = [UIImage imageNamed:@"score_define_dotted_line"];
    [viewBk addSubview:imgViewDottedLine];
    imgViewDottedLine.frame = CGRectMake(0.0, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+10.0, w, 1);
    
    [viewBk addSubview:self.imgViewHighRiskColor];
    self.imgViewHighRiskColor.frame = CGRectMake(58.0, imgViewDottedLine.frame.origin.y+imgViewDottedLine.frame.size.height+30, 10, 10);
    
    [viewBk addSubview:self.labelHighRisk];
    self.labelHighRisk.frame = CGRectMake(self.imgViewHighRiskColor.frame.origin.x+self.imgViewHighRiskColor.frame.size.width+5.0, imgViewDottedLine.frame.origin.y+imgViewDottedLine.frame.size.height+27, 120, 16);
    
    [viewBk addSubview:self.imgViewMediumRiskColor];
    self.imgViewMediumRiskColor.frame = CGRectMake(58.0, self.imgViewHighRiskColor.frame.origin.y+self.imgViewHighRiskColor.frame.size.height+20, 10, 10);
    
    [viewBk addSubview:self.labelMediumRisk];
    self.labelMediumRisk.frame = CGRectMake(self.imgViewMediumRiskColor.frame.origin.x+self.imgViewMediumRiskColor.frame.size.width+5.0, self.labelHighRisk.frame.origin.y+self.labelHighRisk.frame.size.height+14, 140, 16);
    
    [viewBk addSubview:self.imgViewLowRiskColor];
    self.imgViewLowRiskColor.frame = CGRectMake(58.0, self.imgViewMediumRiskColor.frame.origin.y+self.imgViewMediumRiskColor.frame.size.height+20, 10, 10);
    
    [viewBk addSubview:self.labelLowRisk];
    self.labelLowRisk.frame = CGRectMake(self.imgViewMediumRiskColor.frame.origin.x+self.imgViewMediumRiskColor.frame.size.width+5.0, self.labelMediumRisk.frame.origin.y+self.labelMediumRisk.frame.size.height+14, 120, 16);
    
    [self addSubview:self.btnClose];
    self.btnClose.frame = CGRectMake((self.bounds.size.width-30)/2, viewBk.frame.origin.y+viewBk.frame.size.height+40, 32, 32);
    
}

- (UILabel* )labelTitle
{
    if(_labelTitle == nil)
    {
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.text = [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title12"];
    }
    return  _labelTitle;
}

- (UILabel* )labelLowRisk
{
    if(_labelLowRisk == nil)
    {
        _labelLowRisk = [[UILabel alloc] init];
        _labelLowRisk.textColor = [UIColor blackColor];
        _labelLowRisk.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelLowRisk.textAlignment = NSTextAlignmentLeft;
        _labelLowRisk.text = @"";
    }
    return  _labelLowRisk;
}

- (UILabel* )labelMediumRisk
{
    if(_labelMediumRisk == nil)
    {
        _labelMediumRisk = [[UILabel alloc] init];
        _labelMediumRisk.textColor = [UIColor blackColor];
        _labelMediumRisk.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelMediumRisk.textAlignment = NSTextAlignmentLeft;
        _labelMediumRisk.text = @"";
    }
    return  _labelMediumRisk;
}

- (UILabel* )labelHighRisk
{
    if(_labelHighRisk == nil)
    {
        _labelHighRisk = [[UILabel alloc] init];
        _labelHighRisk.textColor = [UIColor blackColor];
        _labelHighRisk.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelHighRisk.textAlignment = NSTextAlignmentLeft;
        _labelHighRisk.text = @"";
    }
    return  _labelHighRisk;
}

- (UIImageView* )imgViewLowRiskColor
{
    if(_imgViewLowRiskColor == nil)
    {
        _imgViewLowRiskColor = [[UIImageView alloc] init];
        _imgViewLowRiskColor.layer.masksToBounds = YES;
        _imgViewLowRiskColor.layer.backgroundColor = [UIColor dslc_colorWithHexString:@"0x13D46B"].CGColor;
        _imgViewLowRiskColor.layer.cornerRadius = 5.0;
    }
    return _imgViewLowRiskColor;
}

- (UIImageView* )imgViewMediumRiskColor
{
    if(_imgViewMediumRiskColor == nil)
    {
        _imgViewMediumRiskColor = [[UIImageView alloc] init];
        _imgViewMediumRiskColor.layer.masksToBounds = YES;
        _imgViewMediumRiskColor.layer.backgroundColor = [UIColor dslc_colorWithHexString:@"0xFD9312"].CGColor;
        _imgViewMediumRiskColor.layer.cornerRadius = 5.0;
        
    }
    return _imgViewMediumRiskColor;
}

- (UIImageView* )imgViewHighRiskColor
{
    if(_imgViewHighRiskColor == nil)
    {
        _imgViewHighRiskColor = [[UIImageView alloc] init];
        _imgViewHighRiskColor.layer.masksToBounds = YES;
        _imgViewHighRiskColor.layer.backgroundColor = [UIColor dslc_colorWithHexString:@"0xF44336"].CGColor;
        _imgViewHighRiskColor.layer.cornerRadius = 5.0;
    }
    return _imgViewHighRiskColor;
}

- (UIButton* )btnClose
{
    if(_btnClose == nil)
    {
        _btnClose = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnClose setImage:[UIImage imageNamed:@"score_define_close"] forState:UIControlStateNormal];
        [_btnClose addTarget:self action:@selector(clickBtnClose:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnClose;
}

- (void)clickBtnClose:(id)sender
{
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    for (UIView* itemView in window.subviews)
    {
        if ([itemView isKindOfClass:[DSLMCVScoreDefineView class]])
        {
            [itemView removeFromSuperview];
            break;
        }
    }
}


@end
