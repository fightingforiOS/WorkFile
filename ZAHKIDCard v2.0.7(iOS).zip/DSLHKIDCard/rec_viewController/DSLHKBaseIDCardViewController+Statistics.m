//
//  DSLHKBaseIDCardViewController+Statistics.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/5/26.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#include <sys/sysctl.h>

#import "DSLHKBaseIDCardViewController+Statistics.h"
#import "DSLCoreKeychainUtils.h"
#import "STConstants.h"
#import "DSLHKIDCardConfig.h"
#import <DSLHKIDCard/DSLHKIDCard.h>
#import "IRNetworkEngine.h"

NSString * const kDSLService = @"com.dsl.idcard.uuid";
NSString * const kDSLUuidAccount = @"com.dsl.idcard.uuid";
 
@implementation DSLHKBaseIDCardViewController (Statistics)

- (void)recordFail:(int)failReason DurationTime:(double)durationTime SessionID:(NSString* )sessionID
{
    NSMutableDictionary* muDicFailInfo = [NSMutableDictionary dictionaryWithCapacity:5];
    [muDicFailInfo setValue:[NSString stringWithFormat:@"%0.f", [[NSDate date] timeIntervalSince1970] * 1000] forKey:DSL_ST_EVENT_PROPERTY_TIME_STAMP];
    [muDicFailInfo setValue:[NSString stringWithFormat:@"%i", failReason] forKey:DSL_ST_EVENT_PROPERTY_FAIL_REASON];
    [muDicFailInfo setValue:[NSString stringWithFormat:@"%0.f", durationTime] forKey:DSL_ST_EVENT_PROPERTY_DURATION_TIME];
    [muDicFailInfo setValue:@"0" forKey:DSL_ST_EVENT_PROPERTY_SUCCESS];
    [muDicFailInfo setValue:sessionID forKey:DSL_ST_EVENT_PROPERTY_SESSION_ID];
    
    NSMutableDictionary* muDicWarnInfo = [NSMutableDictionary dictionaryWithCapacity:5];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iInvalidCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_INVALID];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iBlurCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_BLUR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iFarCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_FAR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iBlurCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_BLUR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iNearCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_NEAR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iOutOfRangeCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_OUT_OF_RANGE];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iNoParallelToMobilePhoneCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_NO_PARALLEL_TO_MOBILEPHONE];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iTiltCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_TILT];
    [muDicFailInfo setValue:muDicWarnInfo forKey:DSL_ST_EVENT_PROPERTY_WARN_INFO];
    
    [self uploadStatisticsRecords:[muDicFailInfo copy]];
}

- (void)recordSuccess:(int)failCount DurationTime:(double)durationTime VideoSize:(double)fileSize VideoTimeLenght:(double)videoTimeLenght SessionID:(NSString* )sessionID
{
    NSMutableDictionary* muDicSuccessInfo = [NSMutableDictionary dictionaryWithCapacity:5];
    [muDicSuccessInfo setValue:[NSString stringWithFormat:@"%0.f", [[NSDate date] timeIntervalSince1970] * 1000] forKey:DSL_ST_EVENT_PROPERTY_TIME_STAMP];
    [muDicSuccessInfo setValue:[NSString stringWithFormat:@"%i", failCount] forKey:DSL_ST_EVENT_PROPERTY_FAIL_COUNT];
    [muDicSuccessInfo setValue:[NSString stringWithFormat:@"%0.f", durationTime] forKey:DSL_ST_EVENT_PROPERTY_DURATION_TIME];
    [muDicSuccessInfo setValue:@"1" forKey:DSL_ST_EVENT_PROPERTY_SUCCESS];
    [muDicSuccessInfo setValue:[NSString stringWithFormat:@"%0.f", fileSize] forKey:DSL_ST_EVENT_PROPERTY_VIDEO_SIZE];
    [muDicSuccessInfo setValue:[NSString stringWithFormat:@"%0.f", videoTimeLenght] forKey:DSL_ST_EVENT_PROPERTY_VIDEO_TIME_LENGTH];
    [muDicSuccessInfo setValue:sessionID forKey:DSL_ST_EVENT_PROPERTY_SESSION_ID];
    
    NSMutableDictionary* muDicWarnInfo = [NSMutableDictionary dictionaryWithCapacity:5];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iInvalidCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_INVALID];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iBlurCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_BLUR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iFarCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_FAR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iBlurCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_BLUR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iNearCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_NEAR];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iOutOfRangeCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_OUT_OF_RANGE];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iNoParallelToMobilePhoneCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_NO_PARALLEL_TO_MOBILEPHONE];
    [muDicWarnInfo setValue:[NSString stringWithFormat:@"%i", self.iTiltCount] forKey:DSL_ST_EVENT_PROPERTY_WARN_TILT];
    [muDicSuccessInfo setValue:muDicWarnInfo forKey:DSL_ST_EVENT_PROPERTY_WARN_INFO];
    
    [self uploadStatisticsRecords:[muDicSuccessInfo copy]];
    
}

- (void)uploadStatisticsRecords:(NSDictionary* ) dic
{
    if([dic count] == 0)
    {
        return;
    }
    
    NSMutableDictionary* muDicUpload = [NSMutableDictionary dictionaryWithDictionary:[self getStatisticsBaseInfo]];
    [muDicUpload addEntriesFromDictionary:dic];
    
    NSString *jsonString = [self buildJSONStringWithObject:[muDicUpload copy]];
    NSLog(@"---------------------- Statistics Info  ----------------------\n");
    //NSLog(@"%@\n", jsonString);
    [IRNetworkEngine uploadStatistics:@"/kyc/client/info/upload" UploadData:jsonString completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        if(error == nil)
        {
            NSLog(@"------------- statistics info uploaded success.");
        }
        else
        {
            NSLog(@"------------- statistics info uploaded error = %@", error.localizedDescription);
        }
    }];

}

- (NSString *)buildJSONStringWithObject:(id)obj {
    NSData *jsonData = [self jsonSerializeObject:obj];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}

- (NSData *)jsonSerializeObject:(id)obj {
    NSError *error = nil;
    NSData *data = nil;
    if (![NSJSONSerialization isValidJSONObject:obj]) {
        return data;
    }
    @try {
        data = [NSJSONSerialization dataWithJSONObject:obj options:0 error:&error];
    }
    @catch (NSException *exception) {
        NSLog(@"%@ exception encoding api data: %@", self, exception);
    }
    if (error) {
         NSLog(@"%@ error encoding api data: %@", self, error);
    }
    return data;
}

- (void)initStatisticsData
{
    self.iInvalidCount = 0;
    self.iBlurCount = 0;
    self.iFarCount = 0;
    self.iNearCount = 0;
    self.iOutOfRangeCount = 0;
    self.iNoParallelToMobilePhoneCount = 0;
    self.iTiltCount = 0;
}

- (void)collectionStatisticsBaseInfo
{
    if(self.muDicStatisticsBaseInfo == nil)
    {
        self.muDicStatisticsBaseInfo = [NSMutableDictionary dictionaryWithCapacity:5];
    }
   
    //登录账号
    NSString* userName = [[NSUserDefaults standardUserDefaults] objectForKey:USER_NAME];
    [self.muDicStatisticsBaseInfo setValue:userName forKey:DSL_ST_EVENT_PROPERTY_USER_ID];
    //设备ID
    [self.muDicStatisticsBaseInfo setValue:[self getDeviceID] forKey:DSL_ST_EVENT_PROPERTY_DEVICE_ID];
    //来源
    [self.muDicStatisticsBaseInfo setValue:@"iOS" forKey:DSL_ST_EVENT_PROPERTY_SOURCE];
    UIDevice *device = [UIDevice currentDevice];
    NSString* strDeviceName = device.name;
    if(strDeviceName != nil)
    {
        //设备名称
        [self.muDicStatisticsBaseInfo setValue:strDeviceName forKey:DSL_ST_EVENT_PROPERTY_DEVICE_NAME];
    }
    //App 版本号
    [self.muDicStatisticsBaseInfo setValue:[[NSBundle mainBundle] infoDictionary][@"CFBundleShortVersionString"] forKey:DSL_ST_EVENT_PROPERTY_APP_VERSION];
    //SDK 版本号
    [self.muDicStatisticsBaseInfo setValue:[DSLHKIDCardSDK getVersion] forKey:DSL_ST_EVENT_PROPERTY_SDK_VERSION];
    //系统版本
    [self.muDicStatisticsBaseInfo setValue:device.systemVersion forKey:DSL_ST_EVENT_PROPERTY_OS_VERSION];
    //设备型号
    [self.muDicStatisticsBaseInfo setValue:[self deviceModel] forKey:DSL_ST_EVENT_PROPERTY_DEVICE_MODEL];
    //设备品牌
    [self.muDicStatisticsBaseInfo setValue:@"apple" forKey:DSL_ST_EVENT_PROPERTY_BRAND];
    //系统语言
    [self.muDicStatisticsBaseInfo setValue:[self language] forKey:DSL_ST_EVENT_PROPERTY_LANGUAGE];
    //操作版本:手持/桌面
    [self.muDicStatisticsBaseInfo setValue:[NSString stringWithFormat:@"%i", self.iOpType] forKey:DSL_ST_EVENT_PROPERTY_OP_VERSION_TYPE];
    //证件类型
    [self.muDicStatisticsBaseInfo setValue:(self.recType == DSLHKIDCardTypeApp_2018) ? @"2018" : @"2003"  forKey:DSL_ST_EVENT_PROPERTY_ID_CARD_TYPE];
}

- (NSDictionary* )getStatisticsBaseInfo
{
    return [self.muDicStatisticsBaseInfo copy];
}

- (NSString* )getDeviceID
{
    // get to keychain
    NSString *uuid = [DSLCoreKeychainUtils getPasswordForUsername:kDSLUuidAccount
                                                andServiceName:kDSLService error:nil];
    if(uuid == nil || [uuid isEqualToString:@""])
    {
        CFUUIDRef puuid = CFUUIDCreate( nil );

        CFStringRef uuidString = CFUUIDCreateString( nil, puuid );
        uuid = (NSString *)CFBridgingRelease(CFStringCreateCopy( NULL, uuidString));
        uuid = [uuid stringByReplacingOccurrencesOfString:@"-" withString:@""];
        CFRelease(puuid);
        CFRelease(uuidString);
        
        //存储
        [DSLCoreKeychainUtils storeUsername:kDSLUuidAccount andPassword:uuid forServiceName:kDSLService updateExisting:YES error:nil];
    }
    
    return uuid;
}

- (NSString *)deviceModel {
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char answer[size];
    sysctlbyname("hw.machine", answer, &size, NULL, 0);
    NSString *results = @(answer);
    return results;
}

- (NSString *)language {
    
    NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
    NSArray * allLanguages = [defaults objectForKey:@"AppleLanguages"];
    NSString * preferredLang = [allLanguages objectAtIndex:0];

    if (preferredLang == nil) {
        return @"";
    }
    return preferredLang;
}
@end
