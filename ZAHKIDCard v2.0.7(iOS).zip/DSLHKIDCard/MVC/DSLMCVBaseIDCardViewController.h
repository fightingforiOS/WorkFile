//
//  DSLMCVBaseIDCardViewController.h
//  DSLMCVIDCard
//
//  Created by chenliqun on 2019/7/15.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "FLAnimatedImageView.h"
#import "FLAnimatedImage.h"
#import "DSLMCVIDCardEnumType.h"

#define dispatch_main_safe(block)\
if ([NSThread isMainThread])\
{\
block();\
}\
else\
{\
dispatch_async(dispatch_get_main_queue(), block);\
}

//转动动画时间
#define Play_Time 8

NS_ASSUME_NONNULL_BEGIN

@interface DSLMCVBaseIDCardViewController : UIViewController

//图片处理会话
@property(nonatomic,strong)AVCaptureSession *captureSession;

//摄像头数据输入设备
@property(nonatomic,strong)AVCaptureDevice *inputDevice;

//身份证件需要放置的区域
@property (assign, nonatomic) CGRect idCardToRect;

//摄像拍摄的有效区域
@property (assign, nonatomic) CGRect effectiveRect;

//身份证件需要放置的区域背景框
@property(nonatomic, strong) UIImageView* idCardToRectImgView;

//操作动作提示图标
@property(nonatomic, strong) FLAnimatedImageView* imgViewRecStatus;

//是否已经停止录制视频
@property (nonatomic, assign) BOOL bStopRecording;

//是否开始识别
@property(nonatomic, assign) BOOL bStartRec;

//已经点击退出按钮
@property(nonatomic, assign) BOOL bExited;

//APP是否是从后台恢复
@property(nonatomic, assign) BOOL bAppRelaunched;

@property(nonatomic, assign) BOOL bOCRCheckCodeFail;



//当前进行到哪一步
@property(nonatomic, assign) int curStep;

//码率倍数
//@property(nonatomic, assign) int iBitRate;

/**
 重置视频UI
 */
- (void)resetVideoUI;

/**
初始化身份证件需要放置的区域
*/
- (void)initIDCardToRect;

/**
 绘制摄像拍摄的有效区域

 @param needDraw 是否需要更新; YES:需要更新; NO:不需要更新
 */
- (void)updateEffectiveRect:(BOOL)needDraw;


/**
 计算文件大小

 @param path 文件路径
 @return 文件大小
 */
- (CGFloat)fileSize:(NSURL *)path;


/**
 视频录制结束后执行,由子类来实现
 */
- (void)proccessRecordVideo;

/**
 设置闪光灯

 @param on YES:开；NO:关闭
 */
- (void)turnTorchOn:(BOOL)on;

- (void)rotateIDCardForCNHKIDCardPicture:(BOOL) bUp;

@end

NS_ASSUME_NONNULL_END
