//
//  DSLMCVResutlItemView.h
//
//
//  Created by chenliqun on 2019/1/22.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DSLMCVResutlItemView : UIView

- (instancetype)initWithFrame:(CGRect)frame;

- (void)setResutlItem:(NSString* ) imgName ContentLeft:(NSString* )contentLeft ContentRight:(NSString* )contentRight ContentLines:(int)lines;

@end

NS_ASSUME_NONNULL_END
