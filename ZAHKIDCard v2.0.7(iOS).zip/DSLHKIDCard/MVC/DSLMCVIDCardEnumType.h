//
//  DSLMCVIDCardEnumType.h
//  DSLMCVIDCard
//
//  Created by chenliqun on 2020/2/13.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


//识别失败错误类型
typedef NS_ENUM(NSInteger,DSLMCVIDCardRecFailType){
    DSLMCVIDCardRecFailType_Default = 0,
    DSLMCVIDCardRecFailType_OverTime,    //超时
    DSLMCVIDCardRecFailType_LostObject,  //目标丢失
};


@interface DSLMCVIDCardEnumType : NSObject

@end

NS_ASSUME_NONNULL_END
