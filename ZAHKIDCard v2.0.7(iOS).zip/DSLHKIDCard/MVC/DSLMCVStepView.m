//
//  DSLMCVStepView.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2021/4/22.
//  Copyright © 2021 chenliqun. All rights reserved.
//

#import "DSLMCVStepView.h"
#import "UIColor+DSLCHexColor.h"

@interface DSLMCVStepView()

@property(nonatomic,strong)UIButton *btnSetp;
@property(nonatomic,strong)UIView *viewBk;
@property(nonatomic,strong)UIImageView *imgViewFinishedMark;
@end

@implementation DSLMCVStepView

- (instancetype)initWithFrame:(CGRect)frame Step:(int)step
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView:step];
    }
    
    return self;
}

- (void)initData:(int)step
{
    [self.btnSetp setTitle:[NSString stringWithFormat:@"Step%d", step] forState:UIControlStateNormal];
    if(step == 1)
    {
        [self.btnSetp setTitleColor:[UIColor dslc_colorWithHexString:@"#FFFFFF" alpha:1.0] forState:UIControlStateNormal];
    }
    else
    {
        [self.btnSetp setTitleColor:[UIColor dslc_colorWithHexString:@"#FFFFFF" alpha:0.15] forState:UIControlStateNormal];
    }

    [self.btnSetp setBackgroundImage:[UIImage new] forState:UIControlStateNormal];
    self.imgViewFinishedMark.hidden = YES;
    self.viewBk.hidden = YES;
}

- (void)setupView:(int)step
{
    [self addSubview:self.viewBk];
    self.viewBk.frame = CGRectMake(0.0, 0.0, 87, 57);
    [self addSubview: self.btnSetp];
    self.btnSetp.frame = CGRectMake((87-79)/2, (57-49)/2, 79, 49);

    [self addSubview:self.imgViewFinishedMark];
    self.imgViewFinishedMark.frame = CGRectMake((self.bounds.size.width-19)/2, (self.bounds.size.height-19)/2, 19, 19);
    
    [self initData:step];
}

- (UIButton* )btnSetp
{
    if(_btnSetp == nil)
    {
        _btnSetp = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnSetp setTitle:@"Step1" forState:UIControlStateNormal];
        [_btnSetp setTitleColor:[UIColor dslc_colorWithHexString:@"#FFFFFF" alpha:0.15] forState:UIControlStateNormal];
        _btnSetp.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:20];
        [_btnSetp setBackgroundColor:[UIColor dslc_colorWithHexString:@"#FFFFFF" alpha:0.13]];
        _btnSetp.layer.cornerRadius = 6;
        _btnSetp.layer.masksToBounds = YES;
        _btnSetp.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    }
    return  _btnSetp;
}

- (UIView* )viewBk
{
    if(_viewBk == nil)
    {
        _viewBk = [[UIView alloc] init];
        [_viewBk setBackgroundColor:[UIColor clearColor]];
        _viewBk.layer.borderColor = [UIColor dslc_colorWithHexString:@"#0FEDA2"].CGColor;
        _viewBk.layer.borderWidth = 1.0;
        _viewBk.layer.cornerRadius = 6;
    }
    
    return _viewBk;
}

- (UIImageView* )imgViewFinishedMark
{
    if(_imgViewFinishedMark == nil)
    {
        _imgViewFinishedMark = [[UIImageView alloc] init];
        _imgViewFinishedMark.image = [UIImage imageNamed:@"rec_op_finish"];
    }
    return _imgViewFinishedMark;
}

- (void)updateData:(int)step
{
    [self.btnSetp setTitle:[NSString stringWithFormat:@"Step%d", step] forState:UIControlStateNormal];
    [self.btnSetp setTitleColor:[UIColor dslc_colorWithHexString:@"#FFFFFF" alpha:1.0] forState:UIControlStateNormal];
}

- (void)stepFinished:(UIImage* )img
{
    self.viewBk.hidden = NO;
    self.imgViewFinishedMark.hidden = NO;
    [self.btnSetp setTitle:@"" forState:UIControlStateNormal];
    [self.btnSetp setBackgroundImage:img forState:UIControlStateNormal];
}

@end
