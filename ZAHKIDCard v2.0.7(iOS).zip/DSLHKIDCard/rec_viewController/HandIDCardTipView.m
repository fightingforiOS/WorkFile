//
//  HandIDCardTipView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/22.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "HandIDCardTipView.h"
#import "UIColor+DSLCHexColor.h"
#import "FLAnimatedImageView.h"
#import "FLAnimatedImage.h"
#import "DSLHKIDCardBundle.h"

@interface HandIDCardTipView()

@property(nonatomic, strong) UIImageView* imgViewHandTip;  //
@property(nonatomic, assign) BOOL bOldType;
@end

@implementation HandIDCardTipView

- (instancetype)initWithFrame:(CGRect)frame IDCardType:(BOOL) bOldType
{
    if(self = [super initWithFrame:frame])
    {
        self.bOldType = bOldType;
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    self.backgroundColor = [UIColor clearColor];
    
    [self addSubview:self.imgViewHandTip];
    //[self performSelector:@selector(delayMoveLine) withObject:nil afterDelay:1.0];
}


- (UIImageView* )imgViewHandTip
{
    if(_imgViewHandTip == nil)
    {
        _imgViewHandTip = [[UIImageView alloc] init];
        NSString* imgName = @"rec_handle_tip_2018_card";
        if(_bOldType)
        {
            imgName = @"rec_handle_tip_2003_card";
        }
        NSBundle* bundle = [NSBundle bundleForClass:self.class];
        _imgViewHandTip.image = [UIImage imageNamed:imgName inBundle:bundle compatibleWithTraitCollection:nil];
        
        _imgViewHandTip.frame = CGRectMake(0.0, 0.0, self.frame.size.width, self.frame.size.height);
    }
    
    return _imgViewHandTip;
}


- (void)setShowTime:(int)times
{
    if(times < 1)
    {
        times = 2;
    }
    
    [self performSelector:@selector(clickOk:) withObject:nil afterDelay:times];
}
- (void)clickOk:(id)sender
{
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(clickHandIDCardTipViewOK)])
        {
            [self.myDelegate clickHandIDCardTipViewOK];
        }
    }
}

@end
