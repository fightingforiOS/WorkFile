//
//  GuideViewFirst.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/11.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "GuideViewFirst.h"
#import "UIColor+DSLCHexColor.h"
@interface GuideViewFirst()

@property(nonatomic, strong) UIImageView* imgViewHandleMark1;
@property(nonatomic, strong) UIImageView* imgViewHandleMark2;
@property(nonatomic, strong) UIImageView* imgViewHandleIDCard;
@property(nonatomic, strong) UIView* viewIDCardMask;

@end

@implementation GuideViewFirst

- (instancetype)initWithFrame:(CGRect)frame RecType:(DSLHKIDCardTypeApp) recType
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView:recType];
    }
    
    return self;
}

- (void)setupView: (DSLHKIDCardTypeApp) recType
{
    [self addSubview:self.imgViewHandleIDCard];
    [self addSubview:self.viewIDCardMask];
    [self addSubview:self.imgViewHandleMark1];
    [self addSubview:self.imgViewHandleMark2];

    if(recType == DSLHKIDCardTypeApp_2018)
    {
        self.imgViewHandleMark1.image = [UIImage imageNamed:@"guide1_handle_mark"];
        self.imgViewHandleMark2.image = [UIImage imageNamed:@"guide1_handle_mark"];
        self.imgViewHandleIDCard.image = [UIImage imageNamed:@"guide1_handleidcard_new"];
    }
    else
    {
        self.imgViewHandleMark1.image = [UIImage imageNamed:@"guide1_handle_mark"];
        self.imgViewHandleMark2.image = [UIImage imageNamed:@"guide1_handle_mark"];
        self.imgViewHandleIDCard.image = [UIImage imageNamed:@"guide1_handleidcard_old"];
    }
    
    [self initViewLayout];
}

- (void)initViewLayout
{
    
    self.imgViewHandleIDCard.frame = CGRectMake(-140+10, (self.frame.size.height-272-200)/2, 440, 269);
    self.imgViewHandleMark1.frame = CGRectMake(90+10, self.imgViewHandleIDCard.frame.origin.y+10, 66, 66);
    self.imgViewHandleMark2.frame = CGRectMake(90+10, self.imgViewHandleMark1.frame.origin.y+self.imgViewHandleMark1.frame.size.height+ 88, 66, 66);
    self.viewIDCardMask.frame = CGRectMake(88-12+10, self.imgViewHandleIDCard.frame.origin.y+58, 112*2-2, 59*2+4);
    self.viewIDCardMask.hidden = YES;

}

- (void)playAnimate
{
    [self initViewLayout];
    
    [UIView animateWithDuration:0.5 animations:^{
      self.imgViewHandleMark1.alpha = 0;
      self.imgViewHandleMark2.alpha = 0;
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.5 animations:^{
            self.imgViewHandleMark1.alpha = 1;
            self.imgViewHandleMark2.alpha = 1;
        } completion:^(BOOL finished) {

        }];
    }];
    
    [self performSelector:@selector(delayShowMark) withObject:nil afterDelay:1.1];
    
}

- (void)delayShowMask
{
     [UIView animateWithDuration:0.5 animations:^{
              self.imgViewHandleMark1.alpha = 0;
              self.imgViewHandleMark2.alpha = 0;
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.5 animations:^{
                    self.imgViewHandleMark1.alpha = 1;
                    self.imgViewHandleMark2.alpha = 1;
                } completion:^(BOOL finished) {

                }];
            }];
}

- (void)delayShowMark
{
     [UIView animateWithDuration:0.5 animations:^{
              self.imgViewHandleMark1.alpha = 0;
              self.imgViewHandleMark2.alpha = 0;
            } completion:^(BOOL finished) {
                [UIView animateWithDuration:0.5 animations:^{
                    self.imgViewHandleMark1.alpha = 1;
                    self.imgViewHandleMark2.alpha = 1;
                } completion:^(BOOL finished) {
                    self.viewIDCardMask.hidden = NO;
                    [UIView animateWithDuration:0.5 animations:^{
                        self.viewIDCardMask.backgroundColor = [UIColor dslc_colorWithHexString:@"#F60000" alpha:0.21];
                    } completion:^(BOOL finished) {
                        
                        [UIView animateWithDuration:0.5 animations:^{
                             self.viewIDCardMask.backgroundColor = [UIColor dslc_colorWithHexString:@"#F60000" alpha:0];
                        } completion:^(BOOL finished) {
                            [UIView animateWithDuration:0.5 animations:^{
                                self.viewIDCardMask.backgroundColor = [UIColor dslc_colorWithHexString:@"#F60000" alpha:0.21];
                            }];
                        }];
                        
                    }];
                }];
            }];
}

- (UIImageView* )imgViewHandleMark1
{
    if(_imgViewHandleMark1 == nil)
    {
        _imgViewHandleMark1 = [[UIImageView alloc] init];
    }
    return _imgViewHandleMark1;
}

- (UIImageView* )imgViewHandleMark2
{
    if(_imgViewHandleMark2 == nil)
    {
        _imgViewHandleMark2 = [[UIImageView alloc] init];
    }
    return _imgViewHandleMark2;
}

- (UIImageView* )imgViewHandleIDCard
{
    if(_imgViewHandleIDCard == nil)
    {
        _imgViewHandleIDCard = [[UIImageView alloc] init];
    }
    return _imgViewHandleIDCard;
}



- (UIView* )viewIDCardMask
{
    if(_viewIDCardMask == nil)
    {
        _viewIDCardMask = [[UIView alloc] init];
        _viewIDCardMask.backgroundColor = [UIColor dslc_colorWithHexString:@"#F60000" alpha:0.0];
    }
    return _viewIDCardMask;
}

@end
