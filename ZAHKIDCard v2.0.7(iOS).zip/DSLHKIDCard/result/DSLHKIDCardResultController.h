//
//  DSLHKIDCardResultController.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/21.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ResultInfoModel.h"
#import "DSLHKIDCardEnumType.h"
NS_ASSUME_NONNULL_BEGIN

@protocol DSLHKIDCardResultVcDelegate <NSObject>

- (void)resultDismissVc;

@end

@interface DSLHKIDCardResultController : UIViewController

@property(nonatomic, assign) id<DSLHKIDCardResultVcDelegate> myDelegate;

@property(nonatomic, strong) UIImage* imgFaceRec;
@property(nonatomic, strong) UIImage* imgSmallHead;
@property(nonatomic, strong) UIImage* imgIDCard;

@property(nonatomic, strong) NSDictionary* dicAntiFakeResult;
@property(nonatomic, strong) NSDictionary* dicOCRResult;
@property(nonatomic, strong) ResultInfoModel* resultInfoModel;
@property(nonatomic, copy) NSString* recID; //验证ID
@property(nonatomic, assign) DSLHKIDCardTypeApp recType;

@end

NS_ASSUME_NONNULL_END
