//
//  DSLMCVResultInfoModel.h
//  DSLHKIDCard
//
//  Created by chenliqun13 on 2020/12/1.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DSLMCVResultInfoModel : NSObject

@property(nonatomic,copy)NSString *certiType;
@property(nonatomic,copy)NSString *certiNo;
@property(nonatomic,copy)NSString *certExpiryDate;
@property(nonatomic, assign) double certRiskScore;   //证件风险值

@end

NS_ASSUME_NONNULL_END
