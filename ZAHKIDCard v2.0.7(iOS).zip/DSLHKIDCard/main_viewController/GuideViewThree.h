//
//  GuideViewThree.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/11.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLHKIDCardEnumType.h"

NS_ASSUME_NONNULL_BEGIN

@interface GuideViewThree : UIView

- (instancetype)initWithFrame:(CGRect)frame RecType:(DSLHKIDCardTypeApp) recType;

- (void)playAnimate:(DSLHKIDCardPlayOpAnimation)playOpAnimation;

@end

NS_ASSUME_NONNULL_END
