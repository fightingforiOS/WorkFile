//
//  IRNetworkEngine.h
//  InterOCR
//
//  Created by Carl Fu on 2018/7/11.
//  Copyright © 2018 Carl Fu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^IRNetCompletionHandler)(NSDictionary * _Nullable result, NSError * _Nullable error);

@interface IRNetworkEngine : NSObject

+ (void)uploadTaskIRService:(NSString *_Nullable)path
                      files:(NSArray *_Nullable)files
                   filename:(NSString *_Nullable)filename
                   header:(NSDictionary* _Nullable)header
                 parameters:(NSDictionary *_Nullable)params
                    custom:(NSDictionary *_Nullable)custom
          completionHandler:(IRNetCompletionHandler _Nullable )completionHandler;

+ (void)loginService:(NSString* _Nullable)path parameters:(NSDictionary* _Nullable)params header:(NSDictionary* _Nullable)header completionHandler:(IRNetCompletionHandler _Nullable)completionHandler;

+ (void)getServiceVersion:(NSString* _Nullable)path completionHandler:(IRNetCompletionHandler _Nullable)completionHandler;

+ (void)uploadJsonFile:(NSString* _Nullable)path JsonStr:(NSString* _Nullable)jsonStr FileKey: (NSString* _Nullable) key completionHandler:(IRNetCompletionHandler _Nullable)completionHandler;

+ (void)uploadStatistics:(NSString* _Nullable)path UploadData:(NSString* _Nullable)uploadData completionHandler:(IRNetCompletionHandler _Nullable)completionHandler;

+ (void)uploadTaskIRServiceForMCV:(NSString *_Nullable)path
            files:(NSArray *_Nullable)files
         filenames:(NSArray *_Nullable)filenames
         header:(NSDictionary* _Nullable)header
       parameters:(NSDictionary *_Nullable)params
          custom:(NSDictionary *_Nullable)custom
completionHandler:(IRNetCompletionHandler _Nullable )completionHandler;

@end
