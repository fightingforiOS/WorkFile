//
//  GuideViewThree.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/11.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "GuideViewThree.h"
#import "UIColor+DSLCHexColor.h"

#define GUIDE_Max_Rotate_Angle 2.5
#define GUIDE_Add_Angle 0.04

@interface GuideViewThree()

@property(nonatomic, strong) UIImageView* imgViewPhone;
@property(nonatomic, strong) UIImageView* imgViewHandleIDCard;
//中间竖线提示
@property(nonatomic,strong)UIImageView *imgViewCenterLine;
//旋转方向提示
@property(nonatomic,strong)UIImageView *imgViewRotationDirection;

@property(nonatomic, strong) UIImageView* imgViewIDCardBorder;

@property(nonatomic, assign) DSLHKIDCardPlayOpAnimation playOpAnimation;

@property(nonatomic, strong) NSTimer* timerPlayAnimation;    //播放动画定时器
@property(nonatomic, assign) BOOL bIDCardRotateAngleAdd;//动画角度变化方向，YES:表示增加；NO:表示减少
//当前操作动画类型
@property(nonatomic, assign) DSLHKIDCardPlayOpAnimation curPlayOpAnimationType;

//当前证件旋转角度
@property(nonatomic, assign) double curIDCardRotateAngle;

@end

@implementation GuideViewThree

- (instancetype)initWithFrame:(CGRect)frame RecType:(DSLHKIDCardTypeApp) recType
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView:recType];
    }
    
    return self;
}

- (void)setupView: (DSLHKIDCardTypeApp) recType
{
    [self initPlayAnimationTimer];
    [self addSubview:self.imgViewHandleIDCard];
    [self addSubview:self.imgViewPhone];
    [self.imgViewHandleIDCard addSubview:self.imgViewIDCardBorder];
    [self addSubview:self.imgViewCenterLine];
    [self addSubview:self.imgViewRotationDirection];

//    self.imgViewIDCardBorder.layer.borderColor = [UIColor blueColor].CGColor;
//    self.imgViewIDCardBorder.layer.borderWidth = 1;
//
//    self.imgViewCenterLine.layer.borderColor = [UIColor redColor].CGColor;
//    self.imgViewCenterLine.layer.borderWidth = 1;
    if(recType == DSLHKIDCardTypeApp_2018)
    {
        self.imgViewPhone.image = [UIImage imageNamed:@"guide3_phone"];
        self.imgViewIDCardBorder.image = [UIImage imageNamed:@"guide3_idcardbord"];
        self.imgViewHandleIDCard.image = [UIImage imageNamed:@"guide3_handleidcard_new"];
    }
    else
    {
        self.imgViewPhone.image = [UIImage imageNamed:@"guide3_phone"];
        self.imgViewIDCardBorder.image = [UIImage imageNamed:@"guide3_idcardbord"];
        self.imgViewHandleIDCard.image = [UIImage imageNamed:@"guide3_handleidcard_old"];
    }
    
    [self initViewLayout];
}

- (void)initViewLayout
{
    self.imgViewCenterLine.hidden = YES;
    self.imgViewRotationDirection.hidden = YES;
    self.imgViewIDCardBorder.hidden = YES;
    if(self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Right)
    {
//        self.imgViewHandleIDCard.frame = CGRectMake(-368, 140+40, 368-4, 215-2);
//        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-360)/2, 218, 440);
//        self.imgViewIDCardBorder.frame = CGRectMake(88+20+60+14, 32, 191-5, 122);
        self.imgViewHandleIDCard.frame = CGRectMake(-368, (self.frame.size.height-213+40)/2, 368-4, 213);
        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-360)/2, 218, 440);
        self.imgViewIDCardBorder.frame = CGRectMake(88+20+60+14+2, 32, 191-3, 122);
    }
    else if(self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Left)
    {
//        self.imgViewHandleIDCard.frame = CGRectMake(-368, 140+40, 368-8, 215-4);
//        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-272-360)/2, 218, 440);
//        self.imgViewIDCardBorder.frame = CGRectMake(88+20+60+15+3-6, 32, 191, 122);
        self.imgViewHandleIDCard.frame = CGRectMake(-368, (self.frame.size.height-213+40)/2, 368-8, 213);
        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-360)/2, 218, 440);
        self.imgViewIDCardBorder.frame = CGRectMake(88+20+60+15+3-6-2, 32, 191-2, 122);
    }
    else if(self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Up)
    {
//        self.imgViewHandleIDCard.frame = CGRectMake(-368, 140+40, 368, 215);
//        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-272-360)/2, 218, 440);
//        self.imgViewIDCardBorder.frame = CGRectMake(88+20+60+15-2, 32, 191, 122);
        self.imgViewHandleIDCard.frame = CGRectMake(-368, (self.frame.size.height-213+40)/2, 368, 215);
        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-360)/2, 218, 440);
        self.imgViewIDCardBorder.frame = CGRectMake(88+20+60+15-2, 32, 191, 122);
    }
    else if(self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Down)
    {
        self.imgViewHandleIDCard.frame = CGRectMake(-368, (self.frame.size.height-213+40)/2, 368-8, 213);
        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-360)/2, 218, 440);
//        self.imgViewHandleIDCard.frame = CGRectMake(-368, 140+40, 368, 215);
//        self.imgViewPhone.frame = CGRectMake(85+10, (self.frame.size.height-272-360)/2, 218, 440);
        self.imgViewIDCardBorder.frame = CGRectMake(88+20+60+15-2, 32, 191, 122);
    }

}

- (void)playAnimate:(DSLHKIDCardPlayOpAnimation)playOpAnimation
{
    
    self.playOpAnimation = playOpAnimation;
    self.curPlayOpAnimationType = playOpAnimation;
    [self initViewLayout];
    [self setDefaultAnchorPointForView:self.imgViewHandleIDCard];
    [self setDefaultAnchorPointForView:self.imgViewIDCardBorder];
    
    if(self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Left ||
       self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Down
       )
    {
        self.imgViewHandleIDCard.frame = CGRectMake(-75+2, (self.frame.size.height-213+40)/2, 368-4, 215-2);
        [self performSelector:@selector(delayPlayAnimate) withObject:nil afterDelay:1.0];
    }
    else
    {
        [UIView animateWithDuration:1.0 animations:^{
                   self.imgViewHandleIDCard.frame = CGRectMake(-75+2, (self.frame.size.height-213+40)/2, 368-4, 215-2);
           } completion:^(BOOL finished) {
               self.imgViewIDCardBorder.hidden = NO;
               [self performSelector:@selector(delayPlayAnimate) withObject:nil afterDelay:0.5];
           }];
    }
   

}

- (void)delayPlayAnimate
{
    if(self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Left ||
       self.playOpAnimation == DSLHKIDCardPlayOpAnimation_Down
       )
    {
        self.imgViewIDCardBorder.hidden = NO;
    }

    self.bIDCardRotateAngleAdd = YES;
    self.curIDCardRotateAngle = 0.0;
    [self updateRotationDirection];
    [self playOpAnimation:self.playOpAnimation];
   
}


- (void)updateRotationDirection
{
    switch (self.playOpAnimation)
    {
        case DSLHKIDCardPlayOpAnimation_Right:
        {
            self.imgViewCenterLine.hidden = NO;
            self.imgViewCenterLine.image = [UIImage imageNamed:@"guide3_vertical_line_tip"];
            self.imgViewCenterLine.frame = CGRectMake(200, self.imgViewHandleIDCard.frame.origin.y, 2, 188);
            
            self.imgViewRotationDirection.hidden = NO;
            self.imgViewRotationDirection.image = [UIImage imageNamed:@"guide3_rotation_direction_right"];
            self.imgViewRotationDirection.frame = CGRectMake(self.imgViewCenterLine.frame.origin.x-6, self.imgViewCenterLine.frame.origin.y+self.imgViewCenterLine.frame.size.height+5, 23, 13);
        }
            break;
            
        case DSLHKIDCardPlayOpAnimation_Left:
        {
            self.imgViewCenterLine.hidden = NO;
            self.imgViewCenterLine.image = [UIImage imageNamed:@"guide3_vertical_line_tip"];
            self.imgViewCenterLine.frame = CGRectMake(200, self.imgViewHandleIDCard.frame.origin.y, 2, 188);
                
            self.imgViewRotationDirection.hidden = NO;
            self.imgViewRotationDirection.image = [UIImage imageNamed:@"guide3_rotation_direction_left"];
            self.imgViewRotationDirection.frame = CGRectMake(self.imgViewCenterLine.frame.origin.x-6, self.imgViewCenterLine.frame.origin.y+self.imgViewCenterLine.frame.size.height+5, 23, 13);
        }
            break;
            
        case DSLHKIDCardPlayOpAnimation_Up:
        {
            self.imgViewCenterLine.hidden = NO;
            self.imgViewCenterLine.image = [UIImage imageNamed:@"guide3_level_line_tip"];
            self.imgViewCenterLine.frame = CGRectMake(88+20, self.imgViewHandleIDCard.frame.origin.y+96, 188, 2);
                
            self.imgViewRotationDirection.hidden = NO;
            self.imgViewRotationDirection.image = [UIImage imageNamed:@"guide3_rotation_direction_up"];
            self.imgViewRotationDirection.frame = CGRectMake(self.imgViewCenterLine.frame.origin.x+self.imgViewCenterLine.frame.size.width-6, self.imgViewCenterLine.frame.origin.y-6, 13, 23);
        }
            break;
            
        case DSLHKIDCardPlayOpAnimation_Down:
        {
            self.imgViewCenterLine.hidden = NO;
            self.imgViewCenterLine.image = [UIImage imageNamed:@"guide3_level_line_tip"];
            self.imgViewCenterLine.frame = CGRectMake(88+20, self.imgViewHandleIDCard.frame.origin.y+96, 188, 2);
                
            self.imgViewRotationDirection.hidden = NO;
            self.imgViewRotationDirection.image = [UIImage imageNamed:@"guide3_rotation_direction_down"];
            self.imgViewRotationDirection.frame = CGRectMake(self.imgViewCenterLine.frame.origin.x+self.imgViewCenterLine.frame.size.width-6, self.imgViewCenterLine.frame.origin.y-6, 13, 23);
        }
            break;
        default:
            break;
    }
}
- (UIImageView* )imgViewPhone
{
    if(_imgViewPhone == nil)
    {
        _imgViewPhone = [[UIImageView alloc] init];
    }
    return _imgViewPhone;
}

- (UIImageView* )imgViewIDCardBorder
{
    if(_imgViewIDCardBorder == nil)
    {
        _imgViewIDCardBorder = [[UIImageView alloc] init];
    }
    return _imgViewIDCardBorder;
}

- (UIImageView* )imgViewHandleIDCard
{
    if(_imgViewHandleIDCard == nil)
    {
        _imgViewHandleIDCard = [[UIImageView alloc] init];
    }
    return _imgViewHandleIDCard;
}

- (UIImageView* )imgViewCenterLine
{
    if(_imgViewCenterLine == nil)
    {
        _imgViewCenterLine = [[UIImageView alloc] init];
    }
    return _imgViewCenterLine;
}

- (UIImageView* )imgViewRotationDirection
{
    if(_imgViewRotationDirection == nil)
    {
        _imgViewRotationDirection = [[UIImageView alloc] init];
    }
    return _imgViewRotationDirection;
}


#pragma mark-- 翻转动画相关

- (void)setDefaultAnchorPointForView:(UIView *)view
{
    [self setAnchorPoint:CGPointMake(0.5f, 0.5f) forView:view];
}

- (void)setAnchorPoint:(CGPoint)anchorPoint forView:(UIView *)view
{
    CGRect oldFrame = view.frame;
    
    view.layer.anchorPoint = anchorPoint;
    
    view.frame = oldFrame;
    
}

/**
 翻转动画
 
 @param type 0:上；1：下；2：右；3：左；4：恢复默认
 */
- (void)playOpAnimation:(DSLHKIDCardPlayOpAnimation)type
{
    NSLog(@"--------------------playOpAnimation type = %li", (long)type);
    
    //暂停动画
    [self stopTimerAnimation];
    
    self.curPlayOpAnimationType = type;
    
    //复位，则不需要重新初始旋转向量
    if(type == DSLHKIDCardPlayOpAnimation_Right_Reset || type == DSLHKIDCardPlayOpAnimation_Up_Reset)
    {
        self.bIDCardRotateAngleAdd = NO;
        [self startTimerAnimation];
        return;
    }
    else
    {
        CATransform3D myTransform = CATransform3DIdentity;
        myTransform.m34 = 0;
        if(type == DSLHKIDCardPlayOpAnimation_Up || type == DSLHKIDCardPlayOpAnimation_Down)
        {
            myTransform = CATransform3DRotate(myTransform,M_PI/180, 1, 0, 0);
        }
        else
        {
            myTransform = CATransform3DRotate(myTransform,M_PI/180, 0, 1, 0);
        }
        
        self.imgViewHandleIDCard.layer.transform = myTransform;
        [self setDefaultAnchorPointForView:self.imgViewHandleIDCard];
        
        self.imgViewIDCardBorder.layer.transform = myTransform;
        [self setDefaultAnchorPointForView:self.imgViewIDCardBorder];
        
        //非默认情况下需要开启动画
        if(type != DSLHKIDCardPlayOpAnimation_Defualt)
        {
            CGPoint point;
            switch (type)
            {
                case DSLHKIDCardPlayOpAnimation_Up:
                {
                    [self startTimerAnimation];
                    point = CGPointMake(0.5, 1.0-0.1);
                    break;
                }
                case DSLHKIDCardPlayOpAnimation_Down:
                {
                    self.curIDCardRotateAngle = 0;
                    self.bIDCardRotateAngleAdd = YES;
                    [self startTimerAnimation];
                    point = CGPointMake(0.5, 0.0);
                    break;
                }
                case DSLHKIDCardPlayOpAnimation_Right:
                {
                    [self startTimerAnimation];
                    point = CGPointMake(0.46, 0.5);
                    break;
                }
                case DSLHKIDCardPlayOpAnimation_Left:
                {
                    self.curIDCardRotateAngle = 0;
                    self.bIDCardRotateAngleAdd = YES;
                    
                    [self startTimerAnimation];
                    point = CGPointMake(1.0-0.24, 0.7);
                    break;
                }
                default:
                {
                    self.bIDCardRotateAngleAdd = YES;
                    [self stopTimerAnimation];
                    point = CGPointMake(1.0, 0.5);
                    break;
                }
            }
            [self setAnchorPoint:point forView:self.imgViewHandleIDCard];
            [self setAnchorPoint:point forView:self.imgViewIDCardBorder];
        }
    }
}

- (void)updateIDCardRotate:(DSLHKIDCardPlayOpAnimation)type
{
    CGFloat angle;
    switch (type)
    {
        case DSLHKIDCardPlayOpAnimation_Up:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Down:
        {
            angle = -M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Right:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Left:
        {
            angle = -M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Right_Reset:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Up_Reset:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        default:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
            
    }
    
    CATransform3D myTransform = CATransform3DIdentity;
    myTransform.m34 = -0.01;
    
    //沿（0，1，0）这个向量旋转
    if(type == DSLHKIDCardPlayOpAnimation_Up || type == DSLHKIDCardPlayOpAnimation_Up_Reset || type == DSLHKIDCardPlayOpAnimation_Down)
    {
        myTransform = CATransform3DRotate(myTransform,angle, 1, 0, 0);
    }
    else
    {
        myTransform = CATransform3DRotate(myTransform,angle, 0, 1, 0);
    }
    
    self.imgViewHandleIDCard.layer.transform = myTransform;
    self.imgViewIDCardBorder.layer.transform = myTransform;

}

- (void)initPlayAnimationTimer
{
    if(self.timerPlayAnimation != nil)
    {
        return;
    }
    self.timerPlayAnimation = [NSTimer timerWithTimeInterval:0.02 target:self selector:@selector(timeredAnimation:) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timerPlayAnimation forMode:NSDefaultRunLoopMode];
    [self stopTimerAnimation];
}

- (void)timeredAnimation:(NSTimer* )timer
{
    if(self.bIDCardRotateAngleAdd)
    {
        self.curIDCardRotateAngle += GUIDE_Add_Angle;
        if(self.curIDCardRotateAngle >= GUIDE_Max_Rotate_Angle)
        {
            self.bIDCardRotateAngleAdd = NO;
            //动画只需要播放一次
            [self stopTimerAnimation];
        }
    }
    else if (!self.bIDCardRotateAngleAdd)
    {
        self.curIDCardRotateAngle -= GUIDE_Add_Angle;
        if(self.curIDCardRotateAngle < 0)
        {
            self.curIDCardRotateAngle = 0;
            self.bIDCardRotateAngleAdd = YES;
            if(self.curPlayOpAnimationType == DSLHKIDCardPlayOpAnimation_Right_Reset
               ||
               self.curPlayOpAnimationType  == DSLHKIDCardPlayOpAnimation_Up_Reset
               )
            {
                //复位动画已经播放一遍回到正面则停止
                [self stopTimerAnimation];
            }
        }
    }

    [self updateIDCardRotate:self.curPlayOpAnimationType];
}

- (void)initPlayOpAnimation
{
    
    [self stopTimerAnimation];
    self.curIDCardRotateAngle = 0.0;
    self.bIDCardRotateAngleAdd = YES;
    
}
- (void)startTimerAnimation
{
    [self stopTimerAnimation];
    
    [self.timerPlayAnimation setFireDate:[NSDate distantPast]];
}

- (void)stopTimerAnimation
{
    [self.timerPlayAnimation setFireDate:[NSDate distantFuture]];
}

@end
