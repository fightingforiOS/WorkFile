//
//  RecIDCardOkTipView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2018/12/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import "RecIDCardOkTipView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"
@interface RecIDCardOkTipView()

@property(nonatomic, strong) UIImageView* imgViewHead;
@property(nonatomic, strong) UILabel* labelTitle;
@property(nonatomic, strong) UILabel* labelDes;

@end

@implementation RecIDCardOkTipView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    self.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.imgViewHead];
    self.imgViewHead.frame = CGRectMake((self.frame.size.width-56)/2, 39.0, 56, 56);
    [self addSubview:self.labelTitle];
    self.labelTitle.frame = CGRectMake(0.0, self.imgViewHead.frame.origin.y+self.imgViewHead.frame.size.height+26.0, self.frame.size.width, 30.0);
//    [self addSubview:self.labelDes];
//    self.labelDes.frame = CGRectMake(0.0, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+20.0, self.frame.size.width, 20.0);
//
}

- (UILabel* )labelTitle
{
    if (_labelTitle == nil) {
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.font = [UIFont fontWithName:@"PingFangSC-Medium" size:21];
        _labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title24"];
        
    }
    return _labelTitle;
}

- (UILabel* )labelDes
{
    if (_labelDes == nil) {
        _labelDes = [[UILabel alloc] init];
        _labelDes.textAlignment = NSTextAlignmentCenter;
        _labelDes.textColor = [UIColor blackColor];
        _labelDes.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _labelDes.text = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title24"];
        
    }
    return _labelDes;
}

- (UIImageView* )imgViewHead
{
    if(_imgViewHead == nil)
    {
        _imgViewHead = [[UIImageView alloc] init];
        _imgViewHead.image = [UIImage imageNamed:@"rec_finish"];
    }
    return _imgViewHead;
}

@end
