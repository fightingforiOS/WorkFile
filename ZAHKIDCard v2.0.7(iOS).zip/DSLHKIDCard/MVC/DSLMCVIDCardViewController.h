//
//  DSLMCVIDCardViewController.h
//  DSLMCVIDCard
//
//  Created by chenliqun on 2019/4/15.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLMCVBaseIDCardViewController.h"


@interface DSLMCVIDCardViewController: DSLMCVBaseIDCardViewController


@end

