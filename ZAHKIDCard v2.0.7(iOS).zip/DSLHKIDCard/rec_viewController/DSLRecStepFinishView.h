//
//  DSLRecStepFinishView.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/5/7.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DSLRecStepFinishView : UIView

- (void)setRecStepFinishTip:(NSString* )text;

@end

NS_ASSUME_NONNULL_END
