//
//  ZAFaceSDK.h
//  ZAFaceSDK
//
//  Created by zhongan on 2018/4/16.
//  Copyright © 2018年 zhongan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZAFaceSDK.
FOUNDATION_EXPORT double ZAFaceSDKVersionNumber;

//! Project version string for ZAFaceSDK.
FOUNDATION_EXPORT const unsigned char ZAFaceSDKVersionString[];

#import <ZAFaceSDK/ZAFaceManager.h>


