//
//  DSLMCVIDCardViewController.h
//  DSLMCVIDCard
//
//  Created by chenliqun on 2019/4/15.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "DSLMCVIDCardViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <DSLHKIDCard/DSLHKIDCard.h>


#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/PHImageManager.h>
#import <Photos/PHPhotoLibrary.h>
#import <Photos/PHAssetChangeRequest.h>
#import <Photos/PHAsset.h>
#import <Photos/PHAssetResource.h>

#import <CoreImage/CoreImage.h>

#import "UIColor+DSLCHexColor.h"

#import "DSLMCVResultFailView.h"
#import "UIView+Toast.h"

#import "LoadingRecView.h"

#import "IRNetworkEngine.h"

#import "DSLMCVNextOperationView.h"
#import "DSLHKIDCardConfig.h"
#import "DSLMCVIDCardBundle.h"

#import "DSLPlayAudio.h"

#import "AppDelegate.h"

#import "DSLMCVIDCardNewResultController.h"
#import "DSLMCVGuideViewController.h"

#import "IRNetworkEngine.h"

#import "DSLMCVStepView.h"

@interface DSLMCVIDCardViewController ()  <DSLMCVIDCardDetectObserverDelegate, DSLMCVResultFailViewDelegate>

@property(nonatomic,strong)UIButton *backButton;
    
@property(nonatomic,strong)DSLMCVNextOperationView *mcvNextOperationView;

//在识别过程中出现的操作错误提示
@property(nonatomic,strong)UILabel *labelOpErrorTip;

//在识别过程中遇到的失败提示(比如，超时，旋转速度过快等)
@property(nonatomic, strong) DSLMCVResultFailView* resultFailView;


@property(nonatomic, copy) NSString* ocrResultId;

//识别Session ID,方便后台定位
@property(nonatomic, copy) NSString* contextId;


@property(nonatomic, strong) DSLMCVIDCardResult* curIDCardResult;

@property(nonatomic, strong) UIImage* curImgFaceData;

@property(nonatomic, strong) LoadingRecView* loadingRecView;

//当前流程操作动作提示语
@property(nonatomic, strong) NSString* strCurOpTip;

//图片保存到相册的文件名
@property(nonatomic, strong) NSString* imgSaveAlbumFileName;


@property(nonatomic, strong) UILabel* labelOpStep;    //当前操作步骤

@property(nonatomic, strong) NSArray* arrResultImgs;

@property(nonatomic, assign) BOOL bUploadImgForOcrFinish;

@property(nonatomic, assign) BOOL bUploadImgForDaFinish;
@property(nonatomic, strong) DSLMCVResultInfoModel* resultModel;

@property(nonatomic,strong)DSLMCVStepView *stepView1;
@property(nonatomic,strong)DSLMCVStepView *stepView2;
@property(nonatomic,strong)DSLMCVStepView *stepView3;
@property(nonatomic, strong) UIImageView* imgViewPlay;

@end

@implementation DSLMCVIDCardViewController


/**
 初始化SDK
 */
- (void)initMCVHKIDCardSDK
{
    [DSLMCVIDCardSDK initMCVDetect];
    
    //必需, 注册回调对象
    [DSLMCVIDCardSDK registerMCVObserver:self];
    
    //可选, 设置识别超时时间
    [DSLMCVIDCardSDK setMCVOverTimes:Rec_Over_Time];

}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self configBackButton];
    
    //SDK初始化
    [self initMCVHKIDCardSDK];
    
    float leftGap = (self.view.bounds.size.width-321)/2;
    self.stepView1 = [[DSLMCVStepView alloc] initWithFrame:CGRectMake(leftGap, self.idCardToRect.origin.y-104-57, 87, 57) Step:1];
    [self.view addSubview: self.stepView1];
    
    self.stepView2 = [[DSLMCVStepView alloc] initWithFrame:CGRectMake(self.stepView1.frame.origin.x+self.stepView1.frame.size.width+30.0, self.idCardToRect.origin.y-104-57, 87, 57) Step:2];
    [self.view addSubview: self.stepView2];
    
    self.stepView3 = [[DSLMCVStepView alloc] initWithFrame:CGRectMake(self.stepView2.frame.origin.x+self.stepView2.frame.size.width+30.0, self.idCardToRect.origin.y-104-57, 87, 57) Step:3];
    [self.view addSubview: self.stepView3];
   
    [self.view addSubview:self.mcvNextOperationView];
    self.mcvNextOperationView.hidden = YES;
    
    [self.view addSubview:self.loadingRecView];
        
    [self.mcvNextOperationView setNextOpStatus:DSLMCVIDCardOperation_Default Text:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title23"]];

    [self.view addSubview:self.resultFailView];
    self.resultFailView.hidden = YES;
    [self.view addSubview:self.labelOpErrorTip];
    
//    [self.view addSubview:self.labelOpStep];
    
    [self.view addSubview:self.imgViewPlay];
    
    [self startRecognize:YES];
    
    [self initNotification];
}

- (void)initNotification
{
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
      [notificationCenter addObserver:self
                               selector:@selector(applicationWillEnterForeground:)
                                   name:UIApplicationWillEnterForegroundNotification
                                 object:nil];
    
      [notificationCenter addObserver:self
                               selector:@selector(applicationDidBecomeActive:)
                                   name:UIApplicationDidBecomeActiveNotification
                                 object:nil];
    
      [notificationCenter addObserver:self
                               selector:@selector(applicationDidEnterBackground:)
                                   name:UIApplicationDidEnterBackgroundNotification
                                 object:nil];
}

- (void)applicationDidBecomeActive:(NSNotification *)notification
{
    if(self.bAppRelaunched)
    {
        self.bAppRelaunched = NO;
        //SDK初始化
        [self initMCVHKIDCardSDK];
        if(!self.bStopRecording)
        {
            [self startRecognize:YES];
        }

    }
}
- (void)applicationWillEnterForeground:(NSNotification *)notification
{
    NSLog(@"applicationWillEnterForeground....");
    
    self.bAppRelaunched = YES;
}

- (void)applicationDidEnterBackground:(NSNotification *)notification
{
    NSLog(@"applicationDidEnterBackground....");

    [self hideOpErrorTip];
    //取消所有延时处理任务
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    //必需, 注销回调设置的对象
    [DSLMCVIDCardSDK unregisterMCVObserver:self];
    [self clearData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [UIApplication sharedApplication].idleTimerDisabled = YES;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    NSLog(@"%@ viewWillDisappear!",NSStringFromClass([self class]));
    
    [UIApplication sharedApplication].idleTimerDisabled = NO;
    
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter removeObserver:self];
    
    //必需, 注销回调设置的对象
    [DSLMCVIDCardSDK unregisterMCVObserver:self];
    
    [self clearData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    NSLog(@"%@ dealloc!",NSStringFromClass([self class]));
    
    //必需, 注销回调设置的对象
    [DSLMCVIDCardSDK unregisterMCVObserver:self];
    
    self.resultFailView.myDelegate = nil;
}

#pragma mark -- 退出识别按钮
-(void)configBackButton{
    _backButton = [[UIButton alloc] initWithFrame:CGRectMake(10, 40, 50, 50)];
    
    UIImage* image =  [UIImage imageNamed:@"closeVideo"];
    
    [_backButton setImage:image forState:UIControlStateNormal];
    //[_backButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.view addSubview:_backButton];
    [_backButton addTarget:self action:@selector(doPopBack:) forControlEvents:UIControlEventTouchUpInside];
}
    
-(void)doPopBack:(id)sender{
    
//    [self gotoResultVcNew:nil];
//    return;
    
//    [self playRecFinishedAnimation:2 Image:[UIImage imageNamed:@"result_idcardOld_test"]];
//
//    return;
    [self clearData];

    self.bExited = YES;
    
    [[AppDelegate sharedInstance] gotoHKIDCard_MCV];
    
}

- (void)clearData
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [NSObject cancelPreviousPerformRequestsWithTarget:self.mcvNextOperationView];
    
    if ([self.captureSession isRunning])
    {
        [self.captureSession stopRunning];
    }
    //识别停止
    self.bStartRec = NO;
   
    
    //必需, 当页面消失的时候，需要调用destroyOCR把SDK内部的资源销毁
    [DSLMCVIDCardSDK destroyMCVOCR];
}


- (void)startRecognize:(BOOL)bStartIDCardSDK
{
    [self resetVideoUI];
    
    [self resetUUID];
    
    self.curStep = 1;
    
    self.labelOpStep.text = @"第1/3步";
    self.bStartRec = YES;
    self.bStopRecording = NO;
    
    self.mcvNextOperationView.hidden = NO;
    self.curIDCardResult = nil;

    self.resultModel = nil;
    
    self.imgViewRecStatus.hidden = YES;
    
    self.imgSaveAlbumFileName = @"";
    [self.captureSession startRunning];
    if(bStartIDCardSDK)
    {
        self.idCardToRectImgView.hidden = NO;

        [DSLMCVIDCardSDK startMCVDetect];
    }
    else
    {
        self.idCardToRectImgView.hidden = YES;
    }
    
    [self.stepView1 initData:1];
    [self.stepView2 initData:2];
    [self.stepView3 initData:3];
    
    [self.view hideToasts];
}

- (void)updateStepView:(int)step Image:(UIImage* )img
{
    switch (step)
    {
        case 1:
        {
            [self.stepView1 stepFinished:img];
            [self.stepView2 updateData:step+1];
        }
            break;
            
        case 2:
        {
            [self.stepView2 stepFinished:img];
            [self.stepView3 updateData:step+1];
        }
            break;
        case 3:
        {
            [self.stepView3 stepFinished:img];
        }
            break;
        default:
            break;
    }
}
- (void)playRecFinishedAnimation:(int)step Image:(UIImage* )img
{
    self.imgViewPlay.frame = CGRectMake(self.view.center.x-50.0, self.view.center.y-50, 100.0, 100.0);
    self.imgViewPlay.image = img;
    CGPoint pt = self.stepView1.center;
    if(step == 2)
    {
        pt = self.stepView2.center;
    }
    else if(step == 3)
    {
        pt = self.stepView3.center;
    }
    self.imgViewPlay.hidden = NO;
    [UIView animateWithDuration:0.5f animations:^{
        self.imgViewPlay.center = pt;
     
            } completion:^(BOOL finished) {
                [self updateStepView:step Image:img];
                self.imgViewPlay.hidden = YES;
            }];
}
#pragma mark -- UI相关

- (UIImageView* )imgViewPlay
{
    if(_imgViewPlay == nil)
    {
        _imgViewPlay = [[UIImageView alloc] init];
        _imgViewPlay.image = [UIImage imageNamed:@"result_idcardOld_test"];
        _imgViewPlay.hidden = YES;
    }
    return _imgViewPlay;
}

- (LoadingRecView* )loadingRecView
{
    if(_loadingRecView == nil)
    {
        _loadingRecView = [[LoadingRecView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-190)/2, 304, 190)];
        _loadingRecView.hidden = YES;
    }
    
    return _loadingRecView;
}


- (DSLMCVResultFailView* )resultFailView
{
    if(_resultFailView == nil)
    {
        _resultFailView = [[DSLMCVResultFailView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-227)/2, 304, 227)];
        _resultFailView.myDelegate = self;
    }
    return _resultFailView;
}



- (UIView* )mcvNextOperationView
{
    if(_mcvNextOperationView == nil)
    {
       _mcvNextOperationView = [[DSLMCVNextOperationView alloc] initWithFrame:CGRectMake(self.idCardToRect.origin.x, self.idCardToRect.origin.y-62.0, self.view.bounds.size.width-(2 * self.idCardToRect.origin.x), 42.0)];

    }
    return _mcvNextOperationView;
}



- (UILabel* )labelOpErrorTip
{
    if (_labelOpErrorTip == nil) {
        _labelOpErrorTip = [[UILabel alloc] init];
        
        if([DSLMCVIDCardBundle isChineseLanguage])
        {
            _labelOpErrorTip.frame = CGRectMake((self.view.bounds.size.width-180.0)/2, self.idCardToRect.origin.y+90.0, 180.0, 46.0);
        }
        else
        {
            _labelOpErrorTip.frame = CGRectMake(30, self.idCardToRect.origin.y+90.0, self.view.bounds.size.width-60, 42.0);
            _labelOpErrorTip.lineBreakMode = NSLineBreakByWordWrapping;
            _labelOpErrorTip.numberOfLines = 0;
        }
    
        _labelOpErrorTip.textAlignment = NSTextAlignmentCenter;
        _labelOpErrorTip.textColor = [UIColor whiteColor];
        _labelOpErrorTip.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _labelOpErrorTip.text = @"证件超出识别框外";
        _labelOpErrorTip.backgroundColor = [UIColor dslc_colorWithHexString:@"#FD4444"];
        //_labelOpErrorTip.alpha = 0.5;
        _labelOpErrorTip.layer.masksToBounds = YES;
        _labelOpErrorTip.layer.cornerRadius = 23.0;
        _labelOpErrorTip.hidden = YES;
    }
    return _labelOpErrorTip;
}

- (UILabel* )labelOpStep
{
    if(_labelOpStep == nil)
    {
        _labelOpStep = [UILabel new];
        _labelOpStep.textAlignment = NSTextAlignmentLeft;
        _labelOpStep.textColor = [UIColor dslc_colorWithHexString:@"0x0266FF"];
        _labelOpStep.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
        _labelOpStep.text = @"第1/3步";
        //_labelOpStep.frame = CGRectMake(self.idCardToRect.origin.x, self.idCardToRect.origin.y-80, 100, 22);
        _labelOpStep.frame = CGRectMake(self.idCardToRect.origin.x, self.idCardToRect.origin.y-140.0, 100, 22);
    }
    return _labelOpStep;
}
- (CGSize) computerContentHeight:(NSString*) content ContentSize:(CGSize) contentSize FontSize:(float) fontSize
{
    UIFont *font = [UIFont systemFontOfSize:fontSize];
    
    NSDictionary *attrDictionary = [NSDictionary dictionaryWithObject:font
                                                               forKey:NSFontAttributeName];
    
    NSAttributedString* attrContent = [[NSAttributedString alloc] initWithString:content attributes:attrDictionary];
    CGRect attrContentSize = [attrContent boundingRectWithSize:contentSize options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize size = CGSizeMake(ceilf(attrContentSize.size.width), ceilf(attrContentSize.size.height));
    return size;
    
}


- (void)setOpErrorTip:(NSString* )errorTip
{
    if(self.bStopRecording)
    {
        return;
    }
    self.labelOpErrorTip.hidden = NO;
    self.labelOpErrorTip.text = errorTip;
}
- (void)hideOpErrorTip
{
    self.labelOpErrorTip.hidden = YES;
}



- (void)updateOpTip:(DSLMCVIDCardNextOperation *)command
{
    switch (command.currentStatus) {
        case DSLMCVIDCardOperation_BEGIN:
        {
          
            [self.mcvNextOperationView setNextOpStatus:command.currentStatus Text:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title1"]];
            break;
        }
        case DSLMCVIDCardOperation_UP:
        {
            [self.mcvNextOperationView setNextOpStatus:command.currentStatus Text:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title2"]];
                       break;
        }
        case DSLMCVIDCardOperation_BACK:
        {
            [self.mcvNextOperationView setNextOpStatus:command.currentStatus Text:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title3"]];
            break;
        }
         case DSLMCVIDCardOperation_COMPLETE:
        {
            [self.mcvNextOperationView setNextOpStatus:command.currentStatus Text:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title7"]];
        
            [[DSLPlayAudio sharedAudioPlayer] playWithFileName:@"op_success" continueNext:NO];
            self.labelOpErrorTip.hidden = YES;
            break;
        }
        case DSLMCVIDCardOperation_FAR:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title13"]];
            break;
        }
        case DSLMCVIDCardOperation_BLUR:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title15"]];
            break;
        }
        case DSLMCVIDCardOperation_EXCEED_TOP:
        case DSLMCVIDCardOperation_EXCEED_EXCEED_BOTTOM:
        case DSLMCVIDCardOperation_EXCEED_EXCEED_RIGHT:
        case DSLMCVIDCardOperation_EXCEED_EXCEED_LEFT:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title19"]];
            break;
        }
        case DSLMCVIDCardOperation_DIRECTION_TILT:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title21"]];
            break;
        }
            
        case DSLMCVIDCardOperation_INVALID:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title16"]];
            break;
        }
        case DSLMCVIDCardOperation_VALID:
        {
            [self hideOpErrorTip];
            break;
        }
        case DSLMCVIDCardOperation_INVALID_CARD:
        {
            if(self.curStep == 4)
            {
                [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title27"]];
            }
            else
            {
                [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title16"]];
            }

            break;
        }
        case DSLMCVIDCardOperation_LESS_ROTATE:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title28"]];
            break;
        }
        case DSLMCVIDCardOperation_MORE_ROTATE:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title29"]];
            break;
        }
        case DSLMCVIDCardOperation_Exposure:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title30"]];
            break;
        }
        case DSLMCVIDCardOperation_Dark:
        {
            [self setOpErrorTip:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title31"]];
            break;
        }
            
        default:
            break;
    }

}

#pragma mark -- Delegate protocols

#pragma mark -- DSLMCVIDCardDetectObserverDelegate
-(void)didUpdateOperationCommand:(DSLMCVIDCardNextOperation *)command {
    
    NSLog(@"operation command = %@, 操作: %@",@(command.currentStatus), command.nextOperationHint);
    dispatch_main_safe(^{
        
        [self updateOpTip:command];
        
        if(command.currentStatus == DSLMCVIDCardOperation_BEGIN)
        {
            [DSLMCVIDCardSDK startMCVOverTime];
            
            [self rotateIDCardForCNHKIDCardPicture:NO];
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_front_card_bk"];
        }
        else if(command.currentStatus == DSLMCVIDCardOperation_ORTH)
        {
            
            
            
        }
        else if (command.currentStatus == DSLMCVIDCardOperation_FLASH)
        {
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_front_card_bk"];
            
            NSLog(@"will set status = DSLMCVIDCardOperation_FLASH-------------------");
            self.curStep = 2;
            NSLog(@" seted status = DSLMCVIDCardOperation_FLASH-------------------");
            //可以进行步骤二,打开闪光灯
            [self turnTorchOn:YES];
            NSLog(@" open flash -------------------");
            
        }
        else if(command.currentStatus == DSLMCVIDCardOperation_UP)
        {
            [self rotateIDCardForCNHKIDCardPicture:YES];
            
            //self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_tilt_card_bk"];
            
            self.labelOpStep.text = @"第2/3步";
            //可以进行步骤三，关闭闪光灯
            [self turnTorchOn:NO];
            self.curStep = 3;
        }
        else if(command.currentStatus == DSLMCVIDCardOperation_BACK)
        {
            [self rotateIDCardForCNHKIDCardPicture:NO];
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_front_card_bk"];
            self.labelOpStep.text = @"第3/3步";
            //可以进行步骤四
            self.curStep = 4;
        }
        else if(command.currentStatus == DSLMCVIDCardOperation_COMPLETE)
        {
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_front_card_bk"];
        }
    });
}

-(void)didDetectResult:(DSLMCVIDCardResult *)result
{
    
    NSLog(@"didDetectResult retCode=%li", (long)result.idCardResultStatus);
    
    
    dispatch_main_safe((^{
        {
            
            if(result.idCardResultStatus == DSLMCVIDCardResultStatus_Pause_Photo)
            {
                //中间过程吐图
                
                //暂停变绿
                UIImage *image = nil;
                int playStep = 1;
                switch (self.curStep)
                {
                    case 1: //正面
                    {
                        image = [UIImage imageWithData:[result.imageDataArray objectAtIndex:4]];
                        break;
                    }
                    case 3: //斜面
                    {
                        image = [UIImage imageWithData:[result.imageDataArray objectAtIndex:5]];
                        playStep = 2;
                        break;
                    }
                    case 4: //背面
                    {
                        image = [UIImage imageWithData:[result.imageDataArray objectAtIndex:6]];
                        playStep = 3;
                        break;
                    }
                    default:
                        break;
                }
                
                if(self.curStep == 3)
                {
                    //斜图
                    self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_front_card_pause_bk"];
                }
                else
                {
                    self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_front_card_pause_bk"];
                }
                
                [self playRecFinishedAnimation:playStep Image:image];
            
                return;
            }
            
            //隐藏错误提示框
            [self hideOpErrorTip];
            self.bStopRecording = YES;
            
            if ([self.captureSession isRunning])
            {
                [self.captureSession stopRunning];
            }
                        
            if (result.idCardResultStatus != DSLMCVIDCardResultStatus_Success)
            {
                //识别失败
                //取消所有延时处理任务
                [NSObject cancelPreviousPerformRequestsWithTarget:self];
                [self proccessRecFail:result];
                self.curIDCardResult = nil;
                
            }
            else
            {
                self.curIDCardResult = result;

                [self uploadImgForOCR];
                [self uploadImgsForDa];
                
            }
        }
        
    }));
}

- (void)proccessRecFail:(DSLMCVIDCardResult *)result
{
    switch (result.idCardResultStatus)
    {
        case DSLMCVIDCardResultStatus_Lost:
        {
            //lost:目标(证件)丢失,在识别证件过程中，发现某些证件特征持续捕获不到导致识别失败
            self.bStartRec = NO;
            [self showRecFailResult:DSLMCVIDCardRecFailType_LostObject];
        }
            break;
        case DSLMCVIDCardResultStatus_Overtime:
        {
            //overtime:识别超时,超时时间可以设置
            self.bStartRec = NO;
            [self showRecFailResult:DSLMCVIDCardRecFailType_OverTime];
        }
            break;
        default:
            //异常的情况
            [self showRecFailResult:DSLMCVIDCardRecFailType_Default];
            break;
    }
}


    

- (void)proccessRecordVideo
{
    [super proccessRecordVideo];
    

}


- (void)showRecFailResult:(DSLMCVIDCardRecFailType)failType
{
    [self.resultFailView showResultFailView:failType];
}

- (void)clickFailOK
{
#warning 当用户点击退出按钮后，由于一些网络请求的原因，该viewcontroller并不会立即dealloc,加了个判断
    if(!self.bExited && [UIApplication sharedApplication].applicationState == UIApplicationStateActive)
    {
        [self startRecognize:YES];
    }
}

- (void)clickGuide
{
    DSLMCVGuideViewController* vc = [[DSLMCVGuideViewController alloc] init];
   vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:^{
        
    }];
}

- (void)clickCloseGuide
{
    
    [self startRecognize:YES];
}


#pragma mark -- help methods
- (NSString* )getUUID
{
    if(self.contextId == nil || [self.contextId isEqualToString:@""])
    {
        self.contextId = [[NSUUID UUID] UUIDString];
        
        
    }
    
    return self.contextId;
}

- (void)resetUUID
{
    
    self.contextId = @"";
}


#pragma mark -- 上传相关
-(void)uploadImgForOCR
{
    if(self.curIDCardResult == nil)
    {
        return;
    }
    self.bUploadImgForOcrFinish = NO;
    if(self.resultModel == nil)
    {
        self.resultModel = [DSLMCVResultInfoModel new];
    }
    self.loadingRecView.hidden = NO;
    NSArray* arrImg = [NSArray arrayWithObjects:self.curIDCardResult.imageDataArray[3], nil];
    NSArray* arrFileName = [NSArray arrayWithObjects:@"vertical_back", nil];
    __weak typeof(self) weakSelf = self;
    
    [IRNetworkEngine uploadTaskIRServiceForMCV:@"ocr" files:arrImg filenames:arrFileName header:nil parameters:[NSDictionary dictionaryWithObjectsAndKeys:[self getUUID], @"context_id", nil] custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
           
            weakSelf.bUploadImgForOcrFinish = YES;
            
            if(error)
            {
                 [weakSelf showRecFailResult:DSLMCVIDCardRecFailType_Default];
                 [weakSelf.view makeToast:@"网络错误" duration:30.0 position:CSToastPositionCenter];
            }
            else
            {
                if([result[@"success"] boolValue])
                {
                    NSDictionary* dicOCRResult = result[@"data"];
                     weakSelf.resultModel.certExpiryDate = dicOCRResult[@"back"][@"expire_date"];
                     weakSelf.resultModel.certiNo = dicOCRResult[@"back"][@"id"];
                     weakSelf.resultModel.certiType = dicOCRResult[@"back"][@"type"];
                    if([ weakSelf.resultModel.certiType isEqualToString:@"None"])
                    {
                         weakSelf.resultModel.certiType = @"";
                    }
                    
                    if(weakSelf.bUploadImgForDaFinish && weakSelf.bUploadImgForOcrFinish)
                    {
                        weakSelf.loadingRecView.hidden = YES;
                        [weakSelf gotoResultVcNew: weakSelf.resultModel];
                    }
                }
                else
                {
                     weakSelf.loadingRecView.hidden = YES;
                    [weakSelf showRecFailResult:DSLMCVIDCardRecFailType_Default];
                    [weakSelf.view makeToast:[NSString stringWithFormat:@"message= %@", result[@"message"]] duration:30.0 position:CSToastPositionCenter];
                }
            }
        });
        
    }];
}

- (void)uploadImgsForDa
{
    if(self.curIDCardResult == nil)
    {
        return;
    }
    
    self.loadingRecView.hidden = NO;
    
    if(self.resultModel == nil)
    {
        self.resultModel = [DSLMCVResultInfoModel new];
    }
    
    NSMutableArray* arrImgs = [NSMutableArray arrayWithCapacity:4];
    for(int i = 0; i < 3; ++i)
    {
        [arrImgs addObject:self.curIDCardResult.imageDataArray[i]];
    }
    NSArray* arrFileNames = [NSArray arrayWithObjects:@"vertical_front", @"light_vertical_front", @"inclined_front" ,nil];
    
    for(int i = 0; i < (int)[self.curIDCardResult.imageDataArray count]; ++i)
    {
        UIImage *image = [UIImage imageWithData:[self.curIDCardResult.imageDataArray objectAtIndex:i]];
        UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
    }
    
    
    __weak typeof(self) weakSelf = self;
    
    [IRNetworkEngine uploadTaskIRServiceForMCV:@"da" files:arrImgs filenames:arrFileNames header:nil parameters:[NSDictionary dictionaryWithObjectsAndKeys:[self getUUID], @"context_id", nil] custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
    
        dispatch_async(dispatch_get_main_queue(), ^{
           
            weakSelf.bUploadImgForDaFinish = YES;
            
            if(error)
            {
                 [weakSelf showRecFailResult:DSLMCVIDCardRecFailType_Default];
                 [weakSelf.view makeToast:@"网络错误" duration:30.0 position:CSToastPositionCenter];
            }
            else
            {
                 if([result[@"success"] boolValue])
                {
                    weakSelf.resultModel.certRiskScore = [result[@"final_result"][@"score"] doubleValue];
                    
                    if(weakSelf.bUploadImgForOcrFinish && weakSelf.bUploadImgForDaFinish)
                    {
                        weakSelf.loadingRecView.hidden = YES;
                        [weakSelf gotoResultVcNew: weakSelf.resultModel];
                    }
                }
                else
                {
                    weakSelf.loadingRecView.hidden = YES;
                    [weakSelf showRecFailResult:DSLMCVIDCardRecFailType_Default];
                    [weakSelf.view makeToast:[NSString stringWithFormat:@"message= %@", result[@"message"]] duration:30.0 position:CSToastPositionCenter];
                }
            }
        });
        
    }];
}


- (void)gotoResultVcNew:(DSLMCVResultInfoModel* )model
{
    DSLMCVResultInfoModel* m = [DSLMCVResultInfoModel new];
//    m.certExpiryDate = @"2019.02.14-2020.02.13";
//    m.certiNo = @"CA6509932";
//    m.certiType = @"来往港澳通行证";
//    m.certRiskScore = 0.2;
    m = model;
    DSLMCVIDCardNewResultController* resultVc = [[DSLMCVIDCardNewResultController alloc] init];
    
    if([self.curIDCardResult.imageDataArray count] == 7)
    {
        resultVc.imgFrontIDCard = [UIImage imageWithData:self.curIDCardResult.imageDataArray[4]];
        resultVc.imgBackIDCard = [UIImage imageWithData:self.curIDCardResult.imageDataArray[6]];
    }
    resultVc.mcvResultInfoModel = m;
    resultVc.recID = [self getUUID];
    [self presentViewController:resultVc animated:YES completion:nil];
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

#pragma mark-- DSLMCVIDCardResultFailVcDelegate methods
- (void)resultFailDismissVc
{
   [[AppDelegate sharedInstance] gotoMainVc];
}

@end

