//
//  RemindViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/10.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "RemindViewController.h"
#import "UIColor+DSLCHexColor.h"
#import "ReminItemView.h"
#import "DSLHKIDCardBundle.h"
#import "GuideViewController.h"
#import "DSLHKIDCardConfig.h"

@interface RemindViewController ()

@property(nonatomic, strong) UILabel* labelTip;
@property(nonatomic, strong) UIButton* btnOk;
@end

@implementation RemindViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor whiteColor];
    
    [self initBackButton];
    
    [self.view addSubview:self.labelTip];
    self.labelTip.frame = CGRectMake(0.0, 80.0, self.view.bounds.size.width, 80.0);
    
    ReminItemView* itemView1 = [[ReminItemView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-300)/2, self.labelTip.frame.origin.y+self.labelTip.frame.size.height+20.0, self.view.bounds.size.width, 103) ImageHead:[UIImage imageNamed:@"remind_tip_idcard_layout_error"] Title1:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title18"] Title2:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title19"]];
    [self.view addSubview:itemView1];
    
    ReminItemView* itemView2 = [[ReminItemView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-300)/2, itemView1.frame.origin.y+itemView1.frame.size.height+40.0, self.view.bounds.size.width, 103) ImageHead:[UIImage imageNamed:@"remind_tip_slices"] Title1:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title20"] Title2:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title21"]];
    [self.view addSubview:itemView2];
    
    ReminItemView* itemView3 = [[ReminItemView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-300)/2, itemView2.frame.origin.y+itemView2.frame.size.height+40.0, self.view.bounds.size.width, 103) ImageHead:[UIImage imageNamed:@"remind_tip_out_of_range"] Title1:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title22"] Title2:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title23"]];
    [self.view addSubview:itemView3];
    
    [self.view addSubview:self.btnOk];
    self.btnOk.frame = CGRectMake((self.view.bounds.size.width-270)/2, itemView3.frame.origin.y+itemView3.frame.size.height+30.0, 270, 46);
    
    if([self isFirstGiude])
    {
        [self performSelector:@selector(next3s) withObject:nil afterDelay:1.0];
    }
    else
    {
        [self next1s];
    }

}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //self.navigationController.navigationBarHidden = NO;
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

- (UILabel* )labelTip
{
    if (_labelTip == nil) {
        _labelTip = [[UILabel alloc] init];
        _labelTip.textAlignment = NSTextAlignmentCenter;
        _labelTip.textColor = [UIColor blackColor];
        _labelTip.font = [UIFont fontWithName:@"PingFangSC-Medium" size:28];
        _labelTip.text = [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title24"];
        _labelTip.lineBreakMode = NSLineBreakByWordWrapping;
        _labelTip.numberOfLines = 0;
        
    }
    return _labelTip;
}

- (UIButton* )btnOk
{
    if(_btnOk == nil)
    {
        _btnOk = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOk setTitle:[NSString stringWithFormat:@"%@ (3s)", [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title25"]] forState:UIControlStateNormal];
        [_btnOk addTarget:self action:@selector(clickBtnOk:) forControlEvents:UIControlEventTouchUpInside];
        [_btnOk setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnOk setBackgroundColor:[UIColor dslc_colorWithHexString:@"0xC5C5C5"]];
        _btnOk.layer.cornerRadius = 24.0;
        _btnOk.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        [_btnOk setEnabled:NO];
    }
    return  _btnOk;
}

- (void)clickBtnOk:(id)sender
{
    GuideViewController* guideVc = [[GuideViewController alloc] init];
    guideVc.recType = self.recType;
    guideVc.useLiteVersion = self.useLiteVersion;
    guideVc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:guideVc animated:YES completion:^{
    }];
}
-(void)initBackButton{
    
    UIButton* backButton = [[UIButton alloc] initWithFrame:CGRectMake(10, 40, 60, 40)];
    UIImage* image =  [UIImage imageNamed:@"remind_back"];
    [backButton setTitle:[DSLHKIDCardBundle IDCardBundleString:@"guide_title2"] forState:UIControlStateNormal];
    [backButton setImage:image forState:UIControlStateNormal];
    backButton.titleLabel.font = [UIFont systemFontOfSize:14.0];
    [backButton setTitleColor:[UIColor dslc_colorWithHexString:@"0x131313"] forState:UIControlStateNormal];
    [self.view addSubview:backButton];
    [backButton addTarget:self action:@selector(clickBtnBack:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)clickBtnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)next3s
{
    [self.btnOk setTitle:[NSString stringWithFormat:@"%@ (2s)", [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title25"]] forState:UIControlStateNormal];
    [self performSelector:@selector(next2s) withObject:nil afterDelay:1.0];
}
- (void)next2s
{
    [self.btnOk setTitle:[NSString stringWithFormat:@"%@ (1s)", [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title25"]] forState:UIControlStateNormal];
    [self performSelector:@selector(next1s) withObject:nil afterDelay:1.0];
}
- (void)next1s
{
    [self.btnOk setEnabled:YES];
    [self.btnOk setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title25"]] forState:UIControlStateNormal];
    [self.btnOk setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x1FC7EC"]];
    [self.btnOk setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}

- (BOOL)isFirstGiude
{
    NSString* firstGiude = [[NSUserDefaults standardUserDefaults] objectForKey:FirstGiude];
    return (firstGiude == nil || [firstGiude isEqualToString:@""]);
}

@end
