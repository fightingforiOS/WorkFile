//
//  DSLPlayAudio.m
//  text
//
//  Created by clq on 19-4-29.
//  Copyright (c) 2019Year DSL. All rights reserved.
//

#import "DSLPlayAudio.h"
#import <AVFoundation/AVFoundation.h>

@interface DSLPlayAudio () <AVAudioPlayerDelegate, AVSpeechSynthesizerDelegate>

@property (strong, nonatomic) AVAudioPlayer *audioPlayer;
@property (assign, nonatomic) BOOL nextPlayGod;
@property (nonatomic, copy) NSString *nextPlayName;
@property(nonatomic, strong) AVSpeechSynthesizer *player;
@property(nonatomic,assign)float rate;   //语速
@property(nonatomic,assign)float volume; //音量
@property(nonatomic,assign)float pitchMultiplier;  //音调
@property(nonatomic, assign) BOOL bPlaySounding;    //是否正在播放声音

@end

@implementation DSLPlayAudio

#pragma mark - Init
+ (id)sharedAudioPlayer {
    static DSLPlayAudio *audioPlayer;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        audioPlayer = [[DSLPlayAudio alloc] init];
    });
    return audioPlayer;
}

#pragma mark - Operation
- (void)play {
    [self.audioPlayer stop];
    [self.audioPlayer play];
}

- (void)stop {
    [self.audioPlayer stop];
}

- (void)playWithFileName:(NSString *)name{
    self.nextPlayGod = NO;
    NSString *path = [self audioPathForResource:name];
    NSData *data = [NSData dataWithContentsOfFile:path];
    [self setplayData:data];
}

- (void)playWithFileName:(NSString *)name continueNext:(BOOL)bContinue
{
    self.nextPlayGod = bContinue;
    NSString *tempName = nil;
    if (bContinue) {
        tempName = name;//@"meglive_well_done";
        self.nextPlayName = name;
    } else {
        tempName = name;
    }
    
    NSString *path = [self audioPathForResource:tempName];
    NSData *data = [NSData dataWithContentsOfFile:path];
    [self setplayData:data];
}

- (void)setplayData:(NSData *)data {
    NSError *error;
    if (self.audioPlayer != nil) {
        [self.audioPlayer stop];
        self.audioPlayer = nil;
    }
    self.audioPlayer = [[AVAudioPlayer alloc] initWithData:data error:&error];
    [self.audioPlayer setDelegate:self];
    [self.audioPlayer prepareToPlay];
    [self.audioPlayer play];
}

- (void)setplayURL:(NSURL *)url {
    NSError *error;
    if (self.audioPlayer != nil) {
        self.audioPlayer = nil;
    }
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error];
    
    [self.audioPlayer prepareToPlay];
}

- (void)cancelAllPlay {
    self.nextPlayName = nil;
    self.nextPlayGod = NO;
    self.audioPlayer.delegate = nil;
    self.audioPlayer = nil;
}

- (NSString* )audioPathForResource:(NSString* )name
{
   return [[NSBundle mainBundle] pathForResource:name ofType:@"mp3"];
}
#pragma mark - AVAudioPlayerDelegate
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag { 
    if (self.nextPlayGod) {
        [self playWithFileName:self.nextPlayName];
    }
}

//停止播放
- (void)stopPlay
{
    if(self.player.isSpeaking)
    {
        [self.player stopSpeakingAtBoundary:AVSpeechBoundaryImmediate];
    }
}

//----------------------------------------
//播放声音
//----------------------------------------
//播放声音

-(void)play:(NSString *)string
{
    
    self.rate   = 0.5;//self.rate;  //设置语速
    
    self.volume = 1.0;//self.volume;  //设置音量（0.0~1.0）默认为1.0
    
    self.pitchMultiplier  = 0.8;//1.25;//self.pitchMultiplier;  //设置语调 (0.5-2.0)
    
    if(string && string.length > 0)
    {
     
        self.bPlaySounding = YES;
        
        NSLog(@"播放声音......");
        AVAudioSession *audioSession=[AVAudioSession sharedInstance];
        //设置为播放和录音状态，以便可以在录制完之后播放录音
        [audioSession setCategory:AVAudioSessionCategoryPlayback error:nil];
        
        if(self.player == nil)
        {
            self.player  = [[AVSpeechSynthesizer alloc]init];
            self.player.delegate = self;
        }
        
        AVSpeechUtterance *utterance = [[AVSpeechUtterance alloc]initWithString:string];//设置语音内容
        
        utterance.voice  = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh-CN"];//设置语言
        
        utterance.rate   = self.rate;  //设置语速
        
        utterance.volume = 1.0;//self.volume;  //设置音量（0.0~1.0）默认为1.0
        
        utterance.pitchMultiplier    = self.pitchMultiplier;  //设置语调 (0.5-2.0)
        
        utterance.postUtteranceDelay = 1; //目的是让语音合成器播放下一语句前有短暂的暂停
        
        [self.player speakUtterance:utterance];
    }
    
}

- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer didFinishSpeechUtterance:(AVSpeechUtterance *)utterance
{
    self.bPlaySounding = NO;
}

- (void)speechSynthesizer:(AVSpeechSynthesizer *)synthesizer didCancelSpeechUtterance:(AVSpeechUtterance *)utterance
{
    
}

@end
