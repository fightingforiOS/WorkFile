//
//  DSLHKIDCardEnumType.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/2/13.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//身份证件类型版本
typedef NS_ENUM(NSInteger,DSLHKIDCardTypeApp){
    DSLHKIDCardTypeApp_Default = -1,
    DSLHKIDCardTypeApp_2018,       //身份证件2018版本
    DSLHKIDCardTypeApp_2003        //身份证件2003版本
};

//身份证件识别状态
typedef NS_ENUM(NSInteger,DSLHKIDCardRecStatus){
    DSLHKIDCardRecStatus_Default = -1,
    DSLHKIDCardRecStatus_Normal,        //恢复正常
    DSLHKIDCardRecStatus_UpOrRight,     //老证件上翻，新证件右翻
    DSLHKIDCardRecStatus_DownOrLeft,    //老证件下翻，新证件左翻
    DSLHKIDCardRecStatus_Reset         //识别过程中的复位(恢复正常)
};

//播放动作动画类型
typedef NS_ENUM(NSInteger,DSLHKIDCardPlayOpAnimation){
    DSLHKIDCardPlayOpAnimation_Defualt = -1,
    DSLHKIDCardPlayOpAnimation_Up,       //向上翻转
    DSLHKIDCardPlayOpAnimation_Down,     //向下翻转
    DSLHKIDCardPlayOpAnimation_Right,    //向右翻转
    DSLHKIDCardPlayOpAnimation_Left,     //向左翻转
    DSLHKIDCardPlayOpAnimation_Right_Reset,  //右翻转复位
    DSLHKIDCardPlayOpAnimation_Up_Reset    //上翻转复位
};

//识别失败错误类型
typedef NS_ENUM(NSInteger,DSLHKIDCardRecFailType){
    DSLHKIDCardRecFailType_Default = 0,
    DSLHKIDCardRecFailType_OverSpeed,   //移动速度过快
    DSLHKIDCardRecFailType_Slices,      //反光
    DSLHKIDCardRecFailType_OverTime,    //超时
    DSLHKIDCardRecFailType_LostObject,  //目标丢失
    DSLHKIDCardRecFailType_Dark,         //光线过暗
    DSLHKIDCardRecFailType_Invalid,      //不正确的操作动作，重新开始识别
    DSLHKIDCardRecFailType_IDCard2003_Postion,      //桌面版2003证件放置错误，重新开始识别
    DSLHKIDCardRecFailType_IDCard2018_Postion,      //桌面版2003证件放置错误，重新开始识别
     DSLHKIDCardRecFailType_VideoQuality_Low     //视频质量低，重新开始识别
};


@interface DSLHKIDCardEnumType : NSObject

@end

NS_ASSUME_NONNULL_END
