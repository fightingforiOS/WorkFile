//
//  UploadVideoTipView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2018/12/17.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol UploadVideoTipViewDelegate <NSObject>

- (void)clickUploadVideoTipOK;

@end

@interface UploadVideoTipView : UIView

@property(nonatomic, assign) id<UploadVideoTipViewDelegate> myDelegate;

@end

NS_ASSUME_NONNULL_END
