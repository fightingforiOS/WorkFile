//
//  DSLHKIDCardConfig.h
//
//
//  Created by chenliqun on 2019/4/17.
//

#import <Foundation/Foundation.h>

//上海测试服务器
#define kShanghaiBaseUrl @"https://kyc-test.zhongan.io"

//国际VB测试服务器
#define kVBBaseUrl @"http://bank-uat-ekyc.zatech.com"
//TU Demo服务器
#define kTUBaseUrl @"https://ekyc-demo.zatech.com"

//MCV
#define kMCVBaseUrl @"https://kyc-test.zhongan.io/mvc/api/"

//0表示上海，1表示国际，2表示TU
#define USE_TYPE_URL 0

#define SHOW_HAND_IDCARD_TIP_VIEW  NO   //是否显示手持证件提示

#define SHOW_UPLOAD_VIDEO_TIP NO    //是否显示授权书

/**
 警告:这个宏定义仅在测试环境下设置为YES
 功能:是否保存视频及图片到相册，主要是在测试过程中方便查看视频，图片
 */
#define Is_Save_Video_Picture   NO

/**
 警告:这个宏定义仅在测试环境下设置为YES
 功能:把识别失败的视频也录制下来(视频从进入页面就开始录制，在识别过程中遇到超时，目标丢失等情况，视频不中断，继续录制，直到识别成功)，方便回放校验算法
 */
#define ALL_Save_Video  NO

/**
 视频及图片存储在相册版本，不需要发送服务器接口，主要是方便无网情况下采集数据使用
 */
#define Is_Local_Save  NO

#define USER_NAME @"userName"
#define PASSWORD  @"password"

#define OVERSPEEDSTATUS  @"overspeedStatus" //转速检测状态

#define EXPSURESTATUS  @"exposureStatus"   //光亮检测状态

#define PLAYVIDEOSTATUS  @"playVideoStatus"   //演示视频播放

#define FirstGiude  @"FirstGiude"   //是否首次浏览引导页


//识别阶段成功提示时长
#define Show_Rec_Step_Finish_Tip_Time 1.5

//识别超时时间
#define Rec_Over_Time 60.0

//动画最大旋转角度
#define Max_Rotate_Angle 10.0

NS_ASSUME_NONNULL_BEGIN

@interface DSLHKIDCardConfig : NSObject

@end

NS_ASSUME_NONNULL_END
