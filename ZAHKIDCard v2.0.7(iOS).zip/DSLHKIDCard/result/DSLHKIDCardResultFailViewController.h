//
//  DSLHKIDCardResultFailViewController.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/25.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol DSLHKIDCardResultFailVcDelegate <NSObject>

- (void)resultFailDismissVc;

@end

@interface DSLHKIDCardResultFailViewController : UIViewController

@property(nonatomic, assign) id<DSLHKIDCardResultFailVcDelegate> myDelegate;

@end

NS_ASSUME_NONNULL_END
