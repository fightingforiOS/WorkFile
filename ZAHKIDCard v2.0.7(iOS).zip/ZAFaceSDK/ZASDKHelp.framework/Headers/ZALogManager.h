//
//  ZALogManager.h
//  ZASDKHelp
//
//  Created by chenliqun on 2019/8/22.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZALogManager : NSObject

+ (instancetype)shareZALogManager;

- (void)setUserID:(nonnull NSString* )userID;

- (void)zaLogNeedSaveWith:(int)logType Log:(NSString*) log DataSource:(int)dateSource Custom:(NSString* )custom IsUploadAtOnce:(BOOL)isUploadAtOnce;

- (void)zaLog:(NSString*) log;

- (void)printLog:(BOOL)print;

@end

NS_ASSUME_NONNULL_END
