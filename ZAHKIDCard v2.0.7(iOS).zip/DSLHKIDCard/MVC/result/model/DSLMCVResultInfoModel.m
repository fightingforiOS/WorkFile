//
//  DSLMCVResultInfoModel.m
//  DSLHKIDCard
//
//  Created by chenliqun13 on 2020/12/1.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "DSLMCVResultInfoModel.h"

@implementation DSLMCVResultInfoModel

@end
