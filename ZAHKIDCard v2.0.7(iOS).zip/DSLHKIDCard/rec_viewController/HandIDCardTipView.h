//
//  HandIDCardTipView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/22.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol HandIDCardTipViewDelegate <NSObject>

- (void)clickHandIDCardTipViewOK;

@end

@interface HandIDCardTipView : UIView

@property(nonatomic, assign) id<HandIDCardTipViewDelegate> _Nullable myDelegate;

- (instancetype)initWithFrame:(CGRect)frame IDCardType:(BOOL) bOldType;

/// 设置提示显示时长
/// @param times 单位/s
- (void)setShowTime:(int)times;

@end

NS_ASSUME_NONNULL_END
