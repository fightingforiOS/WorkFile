//
//  DSLMCVIDCardBundle.h
//  DSLMCVIDCard
//
//  Created by chenliqun on 2019/7/17.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DSLMCVIDCardBundle : NSObject


/**
 返回对应语言的字符串

 @param key 字符串的 key
 @return 字符串
 */
+ (NSString* )IDCardBundleString:(NSString* )key;

+ (BOOL)isChineseLanguage;

@end

NS_ASSUME_NONNULL_END
