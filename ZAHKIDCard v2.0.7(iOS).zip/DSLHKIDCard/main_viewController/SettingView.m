//
//  SettingView.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/6/18.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "SettingView.h"
#import "DSLHKIDCardConfig.h"
#import "DSLHKIDCardBundle.h"

@interface SettingView()

@property(nonatomic, strong) UILabel* labelOverspeed;
@property(nonatomic, strong) UISwitch* switchOverspeed;

@property(nonatomic, strong) UILabel* labelExposure;
@property(nonatomic, strong) UISwitch* switchExposure;

@property(nonatomic, strong) UILabel* labelPlayVideo;
@property(nonatomic, strong) UISwitch* switchPlayVideo;

@end

@implementation SettingView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        
        [self setupViews];
    }
    
    return self;
}

- (void)updateUIStatus
{
    [self.switchOverspeed setOn:[self getStatus:OVERSPEEDSTATUS]];
    [self.switchExposure setOn:[self getStatus:EXPSURESTATUS]];
    [self.switchPlayVideo setOn:[self getStatus:PLAYVIDEOSTATUS]];
}
- (void)setupViews
{
    self.layer.borderColor = [UIColor whiteColor].CGColor;
    self.layer.borderWidth = 1.0;
    self.layer.cornerRadius = 5.0;
    self.backgroundColor = [UIColor whiteColor];
    
//    [self addSubview:self.labelOverspeed];
//    [self addSubview:self.switchOverspeed];
//    [self addSubview:self.labelExposure];
//    [self addSubview:self.switchExposure];
    
    [self addSubview:self.labelPlayVideo];
    [self addSubview:self.switchPlayVideo];
    
    self.labelOverspeed.frame = CGRectMake(22.0, 18.0, 80.0+2, 18.0);
    self.switchOverspeed.frame = CGRectMake(self.labelOverspeed.frame.origin.x+self.labelOverspeed.frame.size.width+10.0, 10.0, 40.0, 32.0);
    self.labelExposure.frame = CGRectMake(22.0, self.labelOverspeed.frame.origin.y+self.labelOverspeed.frame.size.height+24.0+2, 80.0, 18.0);
    self.switchExposure.frame = CGRectMake(self.labelExposure.frame.origin.x+self.labelExposure.frame.size.width+10.0, self.switchOverspeed.frame.origin.y+self.switchOverspeed.frame.size.height+14.0, 40.0, 32.0);
    
    self.labelPlayVideo.frame = CGRectMake(10.0, 18.0, 150.0, 18.0);
    self.switchPlayVideo.frame = CGRectMake(self.labelPlayVideo.frame.origin.x+self.labelPlayVideo.frame.size.width+10.0, 10.0, 40.0, 32.0);
    
    [self.switchOverspeed setOn:[self getStatus:OVERSPEEDSTATUS]];
    [self.switchExposure setOn:[self getStatus:EXPSURESTATUS]];
    [self.switchPlayVideo setOn:[self getStatus:PLAYVIDEOSTATUS]];
}

- (UILabel* )labelOverspeed
{
    if(_labelOverspeed == nil)
    {
        _labelOverspeed = [[UILabel alloc] init];
        _labelOverspeed.textColor = [UIColor blackColor];
        _labelOverspeed.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelOverspeed.text = [DSLHKIDCardBundle IDCardBundleString:@"setting_view_title1"];
    }
    return _labelOverspeed;
}

- (UISwitch* )switchOverspeed
{
    if(_switchOverspeed == nil)
    {
        _switchOverspeed = [[UISwitch alloc] init];
        [_switchOverspeed addTarget:self action:@selector(switchOverspeed:) forControlEvents:UIControlEventValueChanged];  // 开关事件切换通知
    }
    
    return _switchOverspeed;
}

- (UILabel* )labelExposure
{
    if(_labelExposure == nil)
    {
        _labelExposure = [[UILabel alloc] init];
        _labelExposure.textColor = [UIColor blackColor];
        _labelExposure.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelExposure.text = [DSLHKIDCardBundle IDCardBundleString:@"setting_view_title2"];
        
    }
    return _labelExposure;
}

- (UISwitch* )switchExposure
{
    if(_switchExposure == nil)
    {
        _switchExposure = [[UISwitch alloc] init];
        [_switchExposure addTarget:self action:@selector(switchExposure:) forControlEvents:UIControlEventValueChanged];  // 开关事件切换通知
    }
    
    return _switchExposure;
}

- (UILabel* )labelPlayVideo
{
    if(_labelPlayVideo == nil)
    {
        _labelPlayVideo = [[UILabel alloc] init];
        _labelPlayVideo.textColor = [UIColor blackColor];
        _labelPlayVideo.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelPlayVideo.text = [DSLHKIDCardBundle IDCardBundleString:@"setting_view_title3"];
        
    }
    return _labelPlayVideo;
}

- (UISwitch* )switchPlayVideo
{
    if(_switchPlayVideo == nil)
    {
        _switchPlayVideo = [[UISwitch alloc] init];
        [_switchPlayVideo addTarget:self action:@selector(switchPlayVideo:) forControlEvents:UIControlEventValueChanged];  // 开关事件切换通知
    }
    
    return _switchPlayVideo;
}

-(void)switchOverspeed:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    [self saveStatus:switchButton.on ? @"1" : @"0" key:OVERSPEEDSTATUS];
}

-(void)switchExposure:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    [self saveStatus:switchButton.on ? @"1" : @"0" key:EXPSURESTATUS];
}

-(void)switchPlayVideo:(id)sender
{
    UISwitch *switchButton = (UISwitch*)sender;
    [self saveStatus:switchButton.on ? @"1" : @"0" key:PLAYVIDEOSTATUS];
}

- (void)saveStatus:(NSString* )status key:(NSString* )key
{
    if(key)
    {
        [[NSUserDefaults standardUserDefaults] setObject:status forKey:key];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

- (BOOL)getStatus:(NSString* )key
{
    BOOL status = NO;
    if(key)
    {
        status = [[[NSUserDefaults standardUserDefaults] objectForKey:key] boolValue];
    }
    return status;
}
@end
