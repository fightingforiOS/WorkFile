//
//  DSLMCVResultFailView.h
//
//
//  Created by chenliqun on 2018/12/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLMCVIDCardEnumType.h"
NS_ASSUME_NONNULL_BEGIN

@protocol DSLMCVResultFailViewDelegate <NSObject>

- (void)clickFailOK;

- (void)clickGuide;
@end

@interface DSLMCVResultFailView : UIView

@property(nonatomic, assign) id<DSLMCVResultFailViewDelegate> _Nullable myDelegate;

- (void)showResultFailView:(DSLMCVIDCardRecFailType)failType;

@end

NS_ASSUME_NONNULL_END
