//
//  SettingView.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/6/18.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SettingView : UIView

- (void)saveStatus:(NSString* )status key:(NSString* )key;
- (void)updateUIStatus;
@end

NS_ASSUME_NONNULL_END
