//
//  DSLHKIDCardViewController.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/4/15.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLHKBaseIDCardViewController.h"


@interface DSLHKIDCardViewController: DSLHKBaseIDCardViewController

@end

