//
//  DSLHKIDCardResultFailViewController.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/25.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "DSLHKIDCardResultFailViewController.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"
@interface DSLHKIDCardResultFailViewController ()

@property(nonatomic, strong) UIImageView* imgViewBK;
@property(nonatomic, strong) UILabel* labelTitle;
@property(nonatomic,strong)UIButton *btnOk;


@end

@implementation DSLHKIDCardResultFailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupView];
}


- (void)setupView
{
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:self.imgViewBK];
    self.imgViewBK.frame = CGRectMake((self.view.bounds.size.width-210)/2, 160, 210, 210);
    
    [self.view addSubview:self.labelTitle];
    self.labelTitle.frame = CGRectMake(0, self.imgViewBK.frame.origin.y+self.imgViewBK.frame.size.height, self.view.bounds.size.width, 50);
    
    [self.view addSubview:self.btnOk];
    self.btnOk.frame = CGRectMake((self.view.bounds.size.width-235)/2, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+44, 235, 45);
}

- (UIImageView* )imgViewBK
{
    if(_imgViewBK == nil)
    {
        _imgViewBK = [[UIImageView alloc] init];
        _imgViewBK.image = [UIImage imageNamed:@"rec_upload_fail"];
    }
    return _imgViewBK;
}

- (UILabel* )labelTitle
{
    if(_labelTitle == nil)
    {
        float viewW = self.view.bounds.size.width;
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.numberOfLines = 2;
        _labelTitle.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"result_title59"];
        _labelTitle.frame = CGRectMake(0, self.imgViewBK.frame.origin.y+self.imgViewBK.frame.size.height+20, viewW, 50);
    }
    return  _labelTitle;
}


- (UIButton* )btnOk
{
    if(_btnOk == nil)
    {
        _btnOk = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOk setTitle:[DSLHKIDCardBundle IDCardBundleString:@"result_title58"] forState:UIControlStateNormal];
        [_btnOk addTarget:self action:@selector(clickOk:) forControlEvents:UIControlEventTouchUpInside];
        [_btnOk setTitleColor:[UIColor dslc_colorWithHexString:@"0xFFFFFF"] forState:UIControlStateNormal];
        [_btnOk setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
        _btnOk.layer.cornerRadius = 22.0;
        _btnOk.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
    }
    return  _btnOk;
}

- (void)clickOk:(id)sender
{
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(resultFailDismissVc)])
        {
            [self.myDelegate resultFailDismissVc];
        }
    }
}

@end
