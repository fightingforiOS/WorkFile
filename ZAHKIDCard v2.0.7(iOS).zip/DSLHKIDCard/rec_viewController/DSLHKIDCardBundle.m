//
//  DSLHKIDCardBundle.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/7/17.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "DSLHKIDCardBundle.h"

#define IDCardString @"DSLHKIDCard"

@implementation DSLHKIDCardBundle

+ (NSString* )IDCardBundleString:(NSString* )key
{
//    NSString* preferredLang = [[[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"] firstObject];
//    NSString* languageVersion = [NSString stringWithFormat:@"%@Zh", IDCardString];
//    if([preferredLang hasPrefix:@"zh-Hans"])
//    {
//        languageVersion = [NSString stringWithFormat:@"%@Zh", IDCardString];
//    }
    
    NSString* str = NSLocalizedString(key, nil);
    return str;
}

+ (BOOL)isChineseLanguage
{
 
  NSArray *languages = [NSLocale preferredLanguages];
    
    NSString *pfLanguageCode = [languages objectAtIndex:0];
    
    if ([pfLanguageCode isEqualToString:@"zh-Hant"] ||
        [pfLanguageCode hasPrefix:@"zh-Hant"] ||
        [pfLanguageCode hasPrefix:@"yue-Hant"] ||
        [pfLanguageCode isEqualToString:@"zh-HK"] ||
        [pfLanguageCode isEqualToString:@"zh-TW"]||
        [pfLanguageCode isEqualToString:@"zh-Hans"] ||
        [pfLanguageCode hasPrefix:@"yue-Hans"] ||
        [pfLanguageCode hasPrefix:@"zh-Hans"]
        )
    {
        return YES;
    }
    else
    {
        return NO;
    }
 
 return NO;
}

@end
