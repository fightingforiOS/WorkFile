//
//  SelectTypeForSaveLocal.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/8/26.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SelectTypeForSaveLocalDelegate <NSObject>

- (void)selectTypeForSaveLocalOk:(NSString* )env IDCardType:(NSString* )idCardType;

@end

@interface SelectTypeForSaveLocal : UIView

@property(nonatomic, assign) id<SelectTypeForSaveLocalDelegate> myDelegate;

@end

NS_ASSUME_NONNULL_END
