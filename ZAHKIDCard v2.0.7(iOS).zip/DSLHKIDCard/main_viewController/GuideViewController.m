//
//  GuideViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/10.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "GuideViewController.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"
#import "DSLHKIDCardConfig.h"
#import "AppDelegate.h"
#import "GuideViewFirst.h"
#import "GuideViewSecond.h"
#import "GuideViewThree.h"
#import "DSLHKIDCardEnumType.h"

@interface GuideViewController ()

@property(nonatomic, strong) UILabel* labelTitle1Left;
@property(nonatomic, strong) UILabel* labelTitle1Center;
@property(nonatomic, strong) UILabel* labelTitle1Right;

@property(nonatomic, strong) UILabel* labelTitle2;

@property(nonatomic, strong) UILabel* labelStep;

@property(nonatomic, strong) UIButton* btnNext;
@property(nonatomic, strong) UIButton* btnPrev;
@property(nonatomic, strong) UIButton* btnClose;
@property(nonatomic, assign) int iCurStep;

@property(nonatomic, assign) int guidedStep;    //已经看过到第几页

@property(nonatomic, strong) GuideViewFirst* guideViewFirst;
@property(nonatomic, strong) GuideViewSecond* guideViewSecond;
@property(nonatomic, strong) GuideViewThree* guideViewThree;
@property(nonatomic, strong) GuideViewThree* guideViewFour;
@end

@implementation GuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.iCurStep = 1;
    
    [self initView];
    
    [self updateUI:NO];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self updateViewAnimation];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //self.navigationController.navigationBarHidden = NO;
    
}


- (void)initView
{
    [self.view addSubview:self.guideViewFirst];
    
    [self.view addSubview:self.guideViewSecond];
    
    [self.view addSubview:self.guideViewThree];
    
    [self.view addSubview:self.guideViewFour];
    
    [self.view addSubview:self.btnClose];
    self.btnClose.frame = CGRectMake(10.0, 40.0, 30.0, 30.0);
    
    [self.view addSubview:self.labelStep];
    self.labelStep.frame =  CGRectMake(self.view.bounds.size.width-50.0, 40.0, 40.0, 20.0);
    
    [self.view addSubview:self.labelTitle1Left];
    self.labelTitle1Left.frame = CGRectMake(70.0, 300.0, 40.0, 34.0);
    
    [self.view addSubview:self.labelTitle1Center];
    self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, 300.0, 40.0, 34.0);
    
    [self.view addSubview:self.labelTitle1Right];
    self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, 300.0, 80.0, 34.0);
    
    [self.view addSubview:self.labelTitle2];
    self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0);
    
    [self.view addSubview:self.btnPrev];
    
    [self.view addSubview:self.btnNext];
    
}

 - (void)updateViewAnimation
{
    self.guideViewFirst.hidden = YES;
    self.guideViewSecond.hidden = YES;
    self.guideViewThree.hidden = YES;
    self.guideViewFour.hidden = YES;
    
    switch (self.iCurStep)
    {
        case 1:
        {
            self.guideViewFirst.hidden = NO;
            [self.guideViewFirst playAnimate];
        }
            break;
        case 2:
        {
            self.guideViewSecond.hidden = NO;
            [self.guideViewSecond playAnimate];
        }
            break;
            
        case 3:
        {
            self.guideViewThree.hidden = NO;
            if(self.recType == DSLHKIDCardTypeApp_2003)
            {
                [self.guideViewThree playAnimate:DSLHKIDCardPlayOpAnimation_Up];
            }
            else
            {
                [self.guideViewThree playAnimate:DSLHKIDCardPlayOpAnimation_Right];
            }

        }
            break;
        case 4:
        {
            self.guideViewFour.hidden = NO;
            if(self.recType == DSLHKIDCardTypeApp_2003)
            {
                [self.guideViewFour playAnimate:DSLHKIDCardPlayOpAnimation_Down];
            }
            else
            {
                [self.guideViewFour playAnimate:DSLHKIDCardPlayOpAnimation_Left];
            }
        }
            break;
                   
        default:
            break;
    }
}

- (CGSize) computerContentHeight:(NSString*) content ContentSize:(CGSize) contentSize FontSize:(float) fontSize
{
    UIFont *font = [UIFont systemFontOfSize:fontSize];
    
    NSDictionary *attrDictionary = [NSDictionary dictionaryWithObject:font
                                                               forKey:NSFontAttributeName];
    
    NSAttributedString* attrContent = [[NSAttributedString alloc] initWithString:content attributes:attrDictionary];
    CGRect attrContentSize = [attrContent boundingRectWithSize:contentSize options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize size = CGSizeMake(ceilf(attrContentSize.size.width), ceilf(attrContentSize.size.height));
    return size;
    
}

- (void)updateUI:(BOOL)bPrev
{
    switch (self.iCurStep)
    {
        case 1:
        {
            self.labelStep.text = @"1/4";
            self.labelTitle1Left.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title1"];
            self.labelTitle1Center.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title2"];
            self.labelTitle1Right.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title3"];
            self.labelTitle2.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title4"];
            if([DSLHKIDCardBundle isChineseLanguage])
            {
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title1"], [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title2"], [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title3"]];
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272, 60.0, 34.0);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 60.0, 34.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 120.0, 34.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0);
            }
            else
            {
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title1"], [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title2"], [DSLHKIDCardBundle IDCardBundleString:@"guide_first_title3"]];
                 self.labelTitle1Left.text = context;
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272-40, sz.width, sz.height+20);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0+36);
                
            }
           
            
            self.btnNext.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270, 46);
            
            if([self isFirstGiude] && !bPrev && (self.guidedStep < self.iCurStep))
            {
                self.btnPrev.hidden = YES;
                [self.btnNext setEnabled:NO];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0xC5C5C5"]];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (3s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
            }
            else
            {
                self.btnPrev.hidden = NO;
                self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
                
                self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
                
                [self.btnNext setEnabled:YES];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x1FC7EC"]];
                [self.btnNext setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
            }
        }
        break;
            
        case 2:
        {

            self.labelStep.text = @"2/4";
            self.labelTitle1Left.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title1"];
            self.labelTitle1Center.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title2"];
            self.labelTitle1Right.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title3"];
            self.labelTitle2.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title4"];
            
            if([DSLHKIDCardBundle isChineseLanguage])
            {
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title1"], [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title2"], [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title3"]];
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272, 90.0, 34.0);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 60.0+120.0, 34.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 34.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0);
            }
            else
            {
                
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title1"], [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title2"], [DSLHKIDCardBundle IDCardBundleString:@"guide_second_title3"]];
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                self.labelTitle1Left.text = context;
                
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272-40, sz.width, sz.height+20);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0+36);
            }
           
            
            self.btnNext.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270, 46);
            
            if([self isFirstGiude] && !bPrev && (self.guidedStep < self.iCurStep))
            {
                self.btnPrev.hidden = YES;
                [self.btnNext setEnabled:NO];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0xC5C5C5"]];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (3s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
            }
            else
            {
                self.btnPrev.hidden = NO;
                self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
                
                [self.btnNext setEnabled:YES];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x1FC7EC"]];
                [self.btnNext setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
                self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
                CAGradientLayer *gl = [CAGradientLayer layer];
                gl.frame = self.btnNext.frame;
                gl.startPoint = CGPointMake(0, 0.5);
                gl.endPoint = CGPointMake(1, 0.5);
                gl.colors = @[(__bridge id)[UIColor dslc_colorWithHexString:@"#69D1FF"].CGColor,(__bridge id)[UIColor dslc_colorWithHexString:@"#1FC7EC"].CGColor, (__bridge id)[UIColor dslc_colorWithHexString:@"#1FC7EC"].CGColor];
                gl.locations = @[@(0),@(1.0f)];
                [self.btnNext.layer addSublayer:gl];
            }
        }
        break;
            
        case 3:
        {
            self.labelStep.text = @"3/4";
            self.labelTitle1Left.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_three_title1"];
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                self.labelTitle1Center.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_three_title2"];
            }
            else
            {
                self.labelTitle1Center.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_three_title5"];
            }
            self.labelTitle1Right.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_three_title3"];
            self.labelTitle2.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_three_title4"];
            
            
            if([DSLHKIDCardBundle isChineseLanguage])
            {
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", self.labelTitle1Left.text, self.labelTitle1Center.text, self.labelTitle1Right.text];
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272, 90.0, 34.0);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 60.0+120.0, 34.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 34.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0);
            }
            else
            {
                
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", self.labelTitle1Left.text, self.labelTitle1Center.text, self.labelTitle1Right.text];
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                self.labelTitle1Left.text = context;
                
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272-40, sz.width, sz.height+20);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0+36);
            }
            

            
            self.btnNext.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270, 46);
            
            if([self isFirstGiude] && !bPrev && (self.guidedStep < self.iCurStep))
            {
                self.btnPrev.hidden = YES;
                [self.btnNext setEnabled:NO];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0xC5C5C5"]];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (3s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
            }
            else
            {
                self.btnPrev.hidden = NO;
                self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
                
                [self.btnNext setEnabled:YES];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x1FC7EC"]];
                [self.btnNext setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
                self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
                CAGradientLayer *gl = [CAGradientLayer layer];
                gl.frame = self.btnNext.frame;
                gl.startPoint = CGPointMake(0, 0.5);
                gl.endPoint = CGPointMake(1, 0.5);
                gl.colors = @[(__bridge id)[UIColor dslc_colorWithHexString:@"#69D1FF"].CGColor,(__bridge id)[UIColor dslc_colorWithHexString:@"#1FC7EC"].CGColor, (__bridge id)[UIColor dslc_colorWithHexString:@"#1FC7EC"].CGColor];
                gl.locations = @[@(0),@(1.0f)];
                [self.btnNext.layer addSublayer:gl];
            }
        }
        break;
        
        case 4:
        {
            self.labelStep.text = @"4/4";
            self.labelTitle1Left.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title1"];
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                self.labelTitle1Center.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title2"];
            }
            else
            {
                self.labelTitle1Center.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title5"];
            }
            self.labelTitle1Right.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title3"];
            self.labelTitle2.text = [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title4"];
            
            if([DSLHKIDCardBundle isChineseLanguage])
            {
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", self.labelTitle1Left.text, self.labelTitle1Center.text, self.labelTitle1Right.text];
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272, 120.0, 34.0);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 60.0+150.0, 34.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 34.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0);
            }
            else
            {
                
                NSString* context = [NSString stringWithFormat:@"%@ %@%@", self.labelTitle1Left.text, self.labelTitle1Center.text, self.labelTitle1Right.text];
                CGSize sz = [self computerContentHeight:context ContentSize:self.view.bounds.size FontSize:28];
                self.labelTitle1Left.text = context;
                
                self.labelTitle1Left.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.view.bounds.size.height-272-40, sz.width, sz.height+20);
                self.labelTitle1Center.frame = CGRectMake(self.labelTitle1Left.frame.origin.x+self.labelTitle1Left.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle1Right.frame = CGRectMake(self.labelTitle1Center.frame.origin.x+self.labelTitle1Center.frame.size.width, self.labelTitle1Left.frame.origin.y, 0.0, 0.0);
                self.labelTitle2.frame = CGRectMake(0.0, self.labelTitle1Left.frame.origin.y+self.labelTitle1Left.frame.size.height+10.0, self.view.bounds.size.width, 24.0+36);
            }
            
            self.btnNext.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270, 46);
            
            
            if([self isFirstGiude] && !bPrev && (self.guidedStep < self.iCurStep))
            {
                self.btnPrev.hidden = YES;
                [self.btnNext setEnabled:NO];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0xC5C5C5"]];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (3s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title6"]] forState:UIControlStateNormal];
            }
            else
            {
                self.btnPrev.hidden = NO;
                self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
                
                [self.btnNext setEnabled:YES];
                [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x1FC7EC"]];
                [self.btnNext setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title6"]] forState:UIControlStateNormal];
                self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
                CAGradientLayer *gl = [CAGradientLayer layer];
                gl.frame = self.btnNext.frame;
                gl.startPoint = CGPointMake(0, 0.5);
                gl.endPoint = CGPointMake(1, 0.5);
                gl.colors = @[(__bridge id)[UIColor dslc_colorWithHexString:@"#69D1FF"].CGColor,(__bridge id)[UIColor dslc_colorWithHexString:@"#1FC7EC"].CGColor, (__bridge id)[UIColor dslc_colorWithHexString:@"#1FC7EC"].CGColor];
                gl.locations = @[@(0),@(1.0f)];
                [self.btnNext.layer addSublayer:gl];
            }
        }
        break;
            
        default:
            break;
    }
    
    if([self isFirstGiude] && !bPrev && (self.guidedStep < self.iCurStep))
    {
        [self performSelector:@selector(next3s) withObject:nil afterDelay:1.0];
    }
}

- (GuideViewFirst* )guideViewFirst
{
    if(_guideViewFirst == nil)
    {
        _guideViewFirst = [[GuideViewFirst alloc] initWithFrame:self.view.bounds RecType:self.recType];
        _guideViewFirst.hidden = NO;
    }
    return _guideViewFirst;
}

- (GuideViewSecond* )guideViewSecond
{
    if(_guideViewSecond == nil)
    {
        _guideViewSecond = [[GuideViewSecond alloc] initWithFrame:self.view.bounds RecType:self.recType];
        _guideViewSecond.hidden = YES;
    }
    return _guideViewSecond;
}

- (GuideViewThree* )guideViewThree
{
    if(_guideViewThree == nil)
    {
        _guideViewThree = [[GuideViewThree alloc] initWithFrame:CGRectMake(0.0, 0, self.view.bounds.size.width, self.view.bounds.size.height-272) RecType:self.recType];
        _guideViewThree.hidden = YES;
    }
    return _guideViewThree;
}

- (GuideViewThree* )guideViewFour
{
    if(_guideViewFour == nil)
    {
        _guideViewFour = [[GuideViewThree alloc] initWithFrame:CGRectMake(0.0, 0, self.view.bounds.size.width, self.view.bounds.size.height-272) RecType:self.recType];
        _guideViewFour.hidden = YES;
    }
    return _guideViewFour;
}


- (UILabel* )labelTitle1Left
{
    if (_labelTitle1Left == nil) {
        _labelTitle1Left = [[UILabel alloc] init];
         if([DSLHKIDCardBundle isChineseLanguage])
         {
            _labelTitle1Left.textAlignment = NSTextAlignmentLeft;
         }
        else
        {
            _labelTitle1Left.textAlignment = NSTextAlignmentCenter;
        }

        _labelTitle1Left.textColor = [UIColor dslc_colorWithHexString:@"0x2B3033"];
        _labelTitle1Left.font = [UIFont fontWithName:@"PingFangSC-Medium" size:28];
        _labelTitle1Left.text = @"如图";
        _labelTitle1Left.lineBreakMode = NSLineBreakByWordWrapping;
        _labelTitle1Left.numberOfLines = 0;
        
    }
    return _labelTitle1Left;
}

- (UILabel* )labelTitle1Center
{
    if (_labelTitle1Center == nil) {
        _labelTitle1Center = [[UILabel alloc] init];
        _labelTitle1Center.textAlignment = NSTextAlignmentLeft;
        _labelTitle1Center.textColor = [UIColor dslc_colorWithHexString:@"0x02A6CA"];
        _labelTitle1Center.font = [UIFont fontWithName:@"PingFangSC-Medium" size:28];
        _labelTitle1Center.text = @"手持";
        
    }
    return _labelTitle1Center;
}

- (UILabel* )labelTitle1Right
{
    if (_labelTitle1Right == nil) {
        _labelTitle1Right = [[UILabel alloc] init];
        _labelTitle1Right.textAlignment = NSTextAlignmentLeft;
        _labelTitle1Right.textColor = [UIColor dslc_colorWithHexString:@"0x2B3033"];
        _labelTitle1Right.font = [UIFont fontWithName:@"PingFangSC-Medium" size:28];
        _labelTitle1Right.text = @"证件边缘";
        
    }
    return _labelTitle1Right;
}

- (UILabel* )labelTitle2
{
    if (_labelTitle2 == nil) {
        _labelTitle2 = [[UILabel alloc] init];
        _labelTitle2.textAlignment = NSTextAlignmentCenter;
        _labelTitle2.textColor = [UIColor dslc_colorWithHexString:@"0x000000" alpha:0.5];
        _labelTitle2.font = [UIFont fontWithName:@"PingFangSC-Medium" size:20];
        _labelTitle2.text = @"勿遮擋證件紅色區域信息";
        _labelTitle2.lineBreakMode = NSLineBreakByWordWrapping;
        _labelTitle2.numberOfLines = 0;
        
    }
    return _labelTitle2;
}

- (UILabel* )labelStep
{
    if(_labelStep == nil) {
        _labelStep = [[UILabel alloc] init];
        _labelStep.textAlignment = NSTextAlignmentCenter;
        _labelStep.textColor = [UIColor dslc_colorWithHexString:@"0x000000" alpha:1];
        _labelStep.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _labelStep.text = @"";
        
    }
    return _labelStep;
}

- (UIButton* )btnClose
{
    if(_btnClose == nil)
    {
        _btnClose = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnClose setImage:[UIImage imageNamed:@"remind_close"] forState:UIControlStateNormal];
        [_btnClose addTarget:self action:@selector(clickBtnClose:) forControlEvents:UIControlEventTouchUpInside];
    }
    return  _btnClose;
}

- (UIButton* )btnPrev
{
    if(_btnPrev == nil)
    {
        _btnPrev = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnPrev setImage:[UIImage imageNamed:@"remind_prev"] forState:UIControlStateNormal];
        [_btnPrev addTarget:self action:@selector(clickBtnPrev:) forControlEvents:UIControlEventTouchUpInside];
        _btnPrev.hidden = YES;
    }
    return  _btnPrev;
}

- (UIButton* )btnNext
{
    if(_btnNext == nil)
    {
        _btnNext = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnNext setTitle:[NSString stringWithFormat:@"%@ (3s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
        [_btnNext addTarget:self action:@selector(clickBtnNext:) forControlEvents:UIControlEventTouchUpInside];
        [_btnNext setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0xC5C5C5"]];
        _btnNext.layer.cornerRadius = 24.0;
        _btnNext.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        [_btnNext setEnabled:NO];
    }
    return  _btnNext;
}

- (void)clickBtnClose:(id)sender
{
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(clickCloseGuide)])
        {
            [self.myDelegate clickCloseGuide];
        }
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)clickBtnPrev:(id)sender
{
    if(self.iCurStep > 1)
    {
        self.iCurStep--;
    }
    else
    {
        [self clickBtnClose:nil];
    }
    
    if(self.iCurStep == 3)
    {
        [self.guideViewThree removeFromSuperview];
        self.guideViewThree = nil;
        [self.view addSubview:self.guideViewThree];
        [self.view sendSubviewToBack:self.guideViewThree];
    }
    else if(self.iCurStep == 4)
    {
        [self.guideViewFour removeFromSuperview];
        self.guideViewFour = nil;
        [self.view addSubview:self.guideViewFour];
        [self.view sendSubviewToBack:self.guideViewFour];
    }

    [self updateUI:YES];
    [self updateViewAnimation];
}

- (void)clickBtnNext:(id)sender
{
    if(self.iCurStep >= 4)
    {
        //进入识别
        [[AppDelegate sharedInstance] gotoIDCardVc:self.recType useLiteVersion:self.useLiteVersion];
    }
    
    if(self.iCurStep < 4)
    {
//        if(self.iCurStep == 3)
//        {
//            [self.guideViewThree removeFromSuperview];
//            self.guideViewThree = nil;
//        }
//        else if(self.iCurStep == 4)
//        {
//            [self.guideViewFour removeFromSuperview];
//            self.guideViewFour = nil;
//        }
        self.iCurStep++;
        
        if(self.iCurStep == 3)
        {
            [self.guideViewThree removeFromSuperview];
            self.guideViewThree = nil;
            [self.view addSubview:self.guideViewThree];
            [self.view sendSubviewToBack:self.guideViewThree];
        }
        else if(self.iCurStep == 4)
        {
            [self.guideViewFour removeFromSuperview];
            self.guideViewFour = nil;
            [self.view addSubview:self.guideViewFour];
            [self.view sendSubviewToBack:self.guideViewFour];
        }
        
        [self updateUI:NO];
        [self updateViewAnimation];
    }
}

- (void)next3s
{
    if(self.iCurStep == 4)
    {
        [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (2s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title6"]] forState:UIControlStateNormal];
    }
    else
    {
        [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (2s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
    }
    [self performSelector:@selector(next2s) withObject:nil afterDelay:1.0];
}
- (void)next2s
{
    if(self.iCurStep == 4)
    {
        [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (1s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title6"]] forState:UIControlStateNormal];
    }
    else
    {
        [self.btnNext setTitle:[NSString stringWithFormat:@"%@ (1s)", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
    }

    [self performSelector:@selector(next1s) withObject:nil afterDelay:1.0];
}
- (void)next1s
{
    switch (self.iCurStep)
    {
        case 1:
        {
            [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
            self.btnPrev.hidden = NO;
            self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
            
            self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
        }
            break;
            
        case 2:
        {
            [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
            self.btnPrev.hidden = NO;
            self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
            
            self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
        }
            break;
            
        case 3:
        {
            [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_title1"]] forState:UIControlStateNormal];
            self.btnPrev.hidden = NO;
            self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
            
            self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
        }
            break;
            
        case 4:
        {
            if([self isFirstGiude])
            {
                [[NSUserDefaults standardUserDefaults] setObject:@"firstGiude" forKey:FirstGiude];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
            [self.btnNext setTitle:[NSString stringWithFormat:@"%@", [DSLHKIDCardBundle IDCardBundleString:@"guide_four_title6"]] forState:UIControlStateNormal];
            self.btnPrev.hidden = NO;
            self.btnPrev.frame = CGRectMake((self.view.bounds.size.width-270)/2, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0+5, 42.0, 42.0);
            
            self.btnNext.frame = CGRectMake(self.btnPrev.frame.origin.x+self.btnPrev.frame.size.width+20, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+60.0, 270-60, 46);
        }
            break;
            
        default:
            break;
    }
    
    self.guidedStep = self.iCurStep;
    
    [self.btnNext setEnabled:YES];
    [self.btnNext setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x1FC7EC"]];
    [self.btnNext setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
}

- (BOOL)isFirstGiude
{
    NSString* firstGiude = [[NSUserDefaults standardUserDefaults] objectForKey:FirstGiude];
    return (firstGiude == nil || [firstGiude isEqualToString:@""]);
}
@end
