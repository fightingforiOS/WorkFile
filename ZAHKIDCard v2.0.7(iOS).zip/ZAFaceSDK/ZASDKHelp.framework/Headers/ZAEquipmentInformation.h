//
//  ZAEquipmentInformation.h
//  rxtd_bdd
//
//  Created by clq on 16/04/11.
//  Copyright © clq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZAEquipmentInformation : NSObject

/**
 *	@brief
 *
 *	@return
 */
/**
*  获取手机型号
*
*  @param isConvert 是否需要转换成具体的手机型号，如：iphone4,iphone5
*
*  @return 手机型号
*/
+ (NSString *)getPhoneModel:(BOOL) isConvert;

/**
 *  获取设备ID
 *
 *  @return 设备ID
 */
+ (NSString *)getDeviceID;

/**
 *	@brief	获取iOS系统版本号
 *
 *	@return	iOS系统版本号
 */
+ (NSString *)getIOSVersion;

/**
 *	@brief	获取当前运行商
 *
 *	@return	运行商
 */
+ (NSString *)getCurrentCarrier;

/**
 *  获取网络类型
 *
 *  @return 网络类型
 */
+ (NSString *)getNetworkType;


/**
 *	@brief	获取公网IP
 *
 *	@return	IP
 */
+ (NSString *)getWhatismyipdotcom;


/**
 *	@brief	获取定位的地址，具体到街道
 *
 *	@return	地址
 */
+ (NSString *)getLocationAddress;

/**
 *	@brief	获取经纬度
 *
 *	@return	经纬度 xxxxx,xxxx
 */
+ (NSString *)getLocationCoordinate;

/**
 *	@brief	获取连接的wifi名称
 *
 *	@return	名称
 */
+ (NSString *)getWifiName;

/**
 *  设备内存大小
 *
 *  @return 内存大小
 */
+ (long long)getTotalMemorySize;

/**
 *  获取手机硬盘总空间
 *
 *  @return 返回的是字节数
 */
+(long long)getTotalDiskSize;

/**
 *  获取CPU类型
 *
 *  @return cpu类型
 */
+ (NSString*) getCPUType;
/**
 *  获取地区和语言
 *
 *  @return 语言-地区(en-us)
 */
+ (NSString*) getLocaleCountry_Language_Code;
/**
 *  获取手机拥有者名字
 *
 *  @return 格式化名字
 */
+ (NSString*) getOwnerName;

/**
 *  获取屏幕分辨率
 *
 *  @return 格式化宽高
 */
+ (NSString*)getScreenResolution;

/**
 *  获取设备家族 如：iphone, ipad等
 *
 *  @return 具体家族成员
 */
+ (NSString*)getDeviceFamily;

/**
 *  是否越狱
 *
 *  @return 
 */
+(BOOL)isJailbroken;

/**
 *  计算大小
 *
 *  @param fileSize 以字节为单位
 *
 *  @return 大小
 */
+(NSString *)fileSizeToString:(unsigned long long)fileSize;

+ (NSString* )encryptoDeviceID:(NSString* ) uuid;

+ (NSString *)getAppBundleID;

+ (NSString *)getAppBundleShortVersion;

@end
