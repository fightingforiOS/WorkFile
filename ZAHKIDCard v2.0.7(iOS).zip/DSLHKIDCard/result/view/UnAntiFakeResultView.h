//
//  UnAntiFakeResultView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/23.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UnAntiFakeResultView : UIView

- (instancetype)initWithFrame:(CGRect)frame HeightRisk:(NSString* )strHeightRisk LowRisk:(NSString* )strLowRisk totalRisks:(int)totalRiskCount;

@end

NS_ASSUME_NONNULL_END
