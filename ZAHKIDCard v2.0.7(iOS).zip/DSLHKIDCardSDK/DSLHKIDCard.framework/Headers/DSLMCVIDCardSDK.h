//
//  DSLMCVIDCardSDK.h
//
//
//  Created by chenliqun13 on 2020/11/26.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol DSLMCVIDCardDetectObserverDelegate;

@interface DSLMCVIDCardSDK : NSObject

/**
初始化
*/
+(void)initMCVDetect;

/**
 开始检测
 */
+(void)startMCVDetect;

/**
 识别结束时重置状态
 注意:目前不需要外部调用重置状态,SDK内部会重置
 */
+(void)resetMCVStatus;

/**
 退出(离开页面的时候)时调用，把对象销毁
 */
+(void)destroyMCVOCR;

/**
 回调对象注册接口
 
 @param observer 回调对象
 */
+(void)registerMCVObserver:(id<DSLMCVIDCardDetectObserverDelegate>_Nonnull)observer;

/**
 回调对象注销接口
 
 @param observer 回调对象
 */
+(void)unregisterMCVObserver:(id<DSLMCVIDCardDetectObserverDelegate>_Nonnull)observer;

/**
 图片识别传入
 
 @param imageData imageData 图片
 @param orient 传入的图片方向
 @param step 当前进行到哪一步
 */
+(void)addMCVDetectBufferData:(NSData *_Nonnull)imageData Orient:(int)orient Step:(int)step;

/**
 获取当前SDK版本号
 
 @return 当前版本号
 */
+(NSString *_Nonnull)getMCVVersion;

/**
 设置识别超时时间;
 
 @param times 单位:秒, 默认是30s;
 */
+ (void)setMCVOverTimes:(int)times;

/**
 开始识别超时计时

 */
+ (void)startMCVOverTime;

/**
 停止识别超时计时
 
 */
+ (void)stopMCVOverTimer;

/**
 SDK日志是否需要输出
 默认值: Debug模式是YES; Release模式是NO
 @param enable YES: 输出; NO: 不输出
 */
+(void)printMCVLog:(BOOL)enable;

@end
