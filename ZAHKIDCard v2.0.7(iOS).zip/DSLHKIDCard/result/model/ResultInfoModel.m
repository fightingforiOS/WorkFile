//
//  ResultInfoModel.m
//  TestHKIDCard
//
//  Created by chenliqun on 2018/12/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import "ResultInfoModel.h"

@implementation ResultInfoModel

@end
