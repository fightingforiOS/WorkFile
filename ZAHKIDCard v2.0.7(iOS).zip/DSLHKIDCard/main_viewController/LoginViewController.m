//
//  LoginViewController.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/7.
//  Copyright © 2019 chentao. All rights reserved.
//

#import "LoginViewController.h"
#import "ViewController.h"
#import "AppDelegate.h"
#import "UIColor+DSLCHexColor.h"
#import "IRNetworkEngine.h"
#import "DSLHKIDCardConfig.h"
#import "MBProgressHUD.h"
#import "DSLHKIDCardBundle.h"

@interface LoginViewController ()<UITextFieldDelegate>

@property(nonatomic, strong) UITextField* txFieldAccount;
@property(nonatomic, strong) UITextField* txFieldPassword;

@property(nonatomic, strong) NSMutableDictionary* muDic;
@property(nonatomic, strong) UIImageView* imgViewBk;
@property(nonatomic, strong) UIImageView* imgViewLogo;
@property(nonatomic, strong) UIButton* btnLogin;
@property(nonatomic, strong)MBProgressHUD *hud;
@property(nonatomic, strong) UILabel* labelIP;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initData];
    [self.view addSubview:self.imgViewBk];
    [self.view sendSubviewToBack:self.imgViewBk];
    self.imgViewBk.frame = self.view.bounds;
    
    [self.view addSubview:self.imgViewLogo];
    self.imgViewLogo.frame = CGRectMake((self.view.bounds.size.width-164)/2, 100, 164, 97);
   
    [self.view addSubview:self.labelIP];
    self.labelIP.frame = CGRectMake(0.0, self.imgViewLogo.frame.origin.y-30, self.view.bounds.size.width, 20);
    self.labelIP.hidden = YES;
    
    [self.view addSubview:self.txFieldAccount];
    [self.view addSubview:self.txFieldPassword];
    
    self.txFieldAccount.layer.borderColor = [UIColor whiteColor].CGColor;
    self.txFieldAccount.layer.borderWidth = 1.0;
    self.txFieldAccount.layer.cornerRadius = 20.0;
    self.txFieldAccount.frame = CGRectMake((self.view.bounds.size.width-300)/2, self.imgViewLogo.frame.origin.y+self.imgViewLogo.frame.size.height+50.0, 300, 44);
    [self setTextFieldLeftPadding:self.txFieldAccount forWidth:24];
    self.txFieldAccount.delegate = self;
    self.txFieldAccount.returnKeyType = UIReturnKeyDone;
    
    self.txFieldPassword.layer.borderColor = [UIColor whiteColor].CGColor;
    self.txFieldPassword.layer.borderWidth = 1.0;
    self.txFieldPassword.layer.cornerRadius = 20.0;
    self.txFieldPassword.frame = CGRectMake((self.view.bounds.size.width-300)/2, self.txFieldAccount.frame.origin.y+self.txFieldAccount.frame.size.height+20.0, 300, 44);
    self.txFieldPassword.secureTextEntry = YES;
    [self setTextFieldLeftPadding:self.txFieldPassword forWidth:24];
    self.txFieldPassword.delegate = self;
    self.txFieldPassword.returnKeyType = UIReturnKeyDone;
    
    [self.view addSubview:self.btnLogin];
     self.btnLogin.frame = CGRectMake((self.view.bounds.size.width-300)/2, self.txFieldPassword.frame.origin.y+self.txFieldPassword.frame.size.height+50.0, 300, 44);
    
    NSString* userName = [[NSUserDefaults standardUserDefaults] objectForKey:USER_NAME];
    NSString* password = [[NSUserDefaults standardUserDefaults] objectForKey:PASSWORD];

    //[[AppDelegate sharedInstance] gotoMainVc];
    if(userName && password && ![userName isEqualToString:@""] && ![password isEqualToString:@""])
    {
        //[[AppDelegate sharedInstance] gotoMainVc];
        self.txFieldAccount.text = userName;
        self.txFieldPassword.text = password;
        [self login:userName Password:password];
    }
    
//    [self performSelector:@selector(delayGetSelfIP) withObject:nil afterDelay:2];
}

-(void)setTextFieldLeftPadding:(UITextField *)textField forWidth:(CGFloat)leftWidth
{
    CGRect frame = textField.frame;
    frame.size.width = leftWidth;
    UIView *leftview = [[UIView alloc] initWithFrame:frame];
    textField.leftViewMode = UITextFieldViewModeAlways;
    textField.leftView = leftview;
}

- (UILabel* )labelIP
{
    if(_labelIP == nil)
    {
        _labelIP = [[UILabel alloc] init];
        _labelIP.textColor = [UIColor whiteColor];
        _labelIP.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelIP.textAlignment = NSTextAlignmentCenter;
        _labelIP.text = @"手機IP地址 請稍等";
    }
    return  _labelIP;
}

- (UIButton* )btnLogin
{
    if(_btnLogin == nil)
    {
        _btnLogin = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnLogin.layer.cornerRadius = 20.0;
        [_btnLogin setTitle:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title1"] forState:UIControlStateNormal];
        [_btnLogin setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateNormal];
        [_btnLogin setBackgroundColor:[UIColor whiteColor]];
        [_btnLogin addTarget:self action:@selector(clickBtnOk:) forControlEvents:UIControlEventTouchUpInside];
        _btnLogin.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
    }
    return  _btnLogin;
}

- (UITextField* )txFieldAccount
{
    if(_txFieldAccount == nil)
    {
        _txFieldAccount = [[UITextField alloc] init];
        NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title2"] attributes:
                                            @{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:_txFieldAccount.font}];
        _txFieldAccount.attributedPlaceholder = attrString;
        
        _txFieldAccount.textColor = [UIColor whiteColor];
        _txFieldAccount.font = [UIFont fontWithName:@"PingFangSC-Medium" size:12];
        //_txFieldPhone.keyboardType = UIKeyboardTypeNumberPad;
    }
    
    return _txFieldAccount;
    
}

- (UITextField* )txFieldPassword
{
    if(_txFieldPassword == nil)
    {
        _txFieldPassword = [[UITextField alloc] init];
        NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title3"] attributes:
                                          @{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:_txFieldPassword.font}];
        _txFieldPassword.attributedPlaceholder = attrString;
        _txFieldPassword.textColor = [UIColor whiteColor];
        _txFieldPassword.font = [UIFont fontWithName:@"PingFangSC-Medium" size:12];
        //_txFieldPassword.keyboardType = UIKeyboardTypeNumberPad;
    }
    
    return _txFieldPassword;
    
}

- (UIImageView* )imgViewBk
{
    if(_imgViewBk == nil)
    {
        _imgViewBk = [[UIImageView alloc] init];
        _imgViewBk.image = [UIImage imageNamed:@"login_bk"];
    }
    return _imgViewBk;
}

- (UIImageView* )imgViewLogo
{
    if(_imgViewLogo == nil)
    {
        _imgViewLogo = [[UIImageView alloc] init];
        _imgViewLogo.image = [UIImage imageNamed:@"login_logo"];
    }
    return _imgViewLogo;
}

- (void)initData
{
    self.muDic = [NSMutableDictionary dictionaryWithCapacity:5];
    [self.muDic setObject:@"0" forKey:@"x"];
    [self.muDic setObject:@"1" forKey:@"m"];
    [self.muDic setObject:@"2" forKey:@"h"];
    [self.muDic setObject:@"3" forKey:@"c"];
    [self.muDic setObject:@"4" forKey:@"j"];
    [self.muDic setObject:@"5" forKey:@"a"];
    [self.muDic setObject:@"6" forKey:@"y"];
    [self.muDic setObject:@"7" forKey:@"r"];
    [self.muDic setObject:@"8" forKey:@"l"];
    [self.muDic setObject:@"9" forKey:@"w"];
}

- (void)login:(NSString* )userName Password:(NSString* )password
{
    [self showLoading];
    NSString* url = @"/login";
    NSDictionary* params = [NSDictionary dictionaryWithObjectsAndKeys:userName, @"user", password, @"pwd", nil];
    [IRNetworkEngine loginService:url parameters:params header:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideLoading];
            if(error)
            {
                if(error.code == -1009)
                {
                    [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title4"]];
                }
                else
                {
                    [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title5"]];
                }
            }
            else
            {
                if([result[@"success"] boolValue])
                {
                    [self saveUserInfo:self.txFieldAccount.text Password:self.txFieldPassword.text];
                    
                    [[AppDelegate sharedInstance] gotoHKIDCard_MCV];
                }
                else
                {
                    NSString* msg = [DSLHKIDCardBundle IDCardBundleString:@"login_vc_title5"];
                    if(result[@"message"] && ![result[@"message"] isEqualToString:@""])
                    {
                        msg = result[@"message"];
                        if([msg isEqualToString:@"找不到用户"])
                        {
                            msg = [DSLHKIDCardBundle IDCardBundleString:@"login_vc_title12"];
                        }
                        else if([msg containsString:@"密码错误"])
                        {
                             msg = [DSLHKIDCardBundle IDCardBundleString:@"login_vc_title13"];
                        }
                        
                    }
                    [self showAlterController:msg];
                }
            }
        });
        
    }];
}

- (void)saveUserInfo:(NSString* )userName Password:(NSString* )password
{
    if(userName && password)
    {
        [[NSUserDefaults standardUserDefaults] setObject:userName forKey:USER_NAME];
        [[NSUserDefaults standardUserDefaults] setObject:password forKey:PASSWORD];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }

}
 - (void)clickBtnOk:(id)sender
{
    if((self.txFieldAccount.text == nil || [self.txFieldAccount.text isEqualToString:@""]))
    {
        [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title6"]];
        return ;
    }
    
    if((self.txFieldPassword.text == nil || [self.txFieldPassword.text isEqualToString:@""]))
    {
        [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title7"]];
        return ;
    }
    
    [self login:self.txFieldAccount.text Password:self.txFieldPassword.text];
    return;
    
//    if([self checkAccount:self.txFieldAccount.text] && [self checkPw:self.txFieldPassword.text])
//    {
//        [[AppDelegate sharedInstance] gotoMainVc];
//    }
//    else
//    {
//        //[self showAlterController];
//    }
}

- (BOOL)checkAccount:(NSString* )account
{
    
    if((account == nil && [account isEqualToString:@""]))
    {
        [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title6"]];
        return NO;
    }
    if(account.length != 8)
    {
        [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title8"]];
        return NO;
    }
    
    NSString* accountStr = [NSString stringWithFormat:@"xmhcjayrlw"];
    for(int i = 0; i < account.length; ++i)
    {
        NSString* c = [account substringWithRange:NSMakeRange(i, 1)];
        if(![accountStr containsString:c])
        {
            [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title8"]];
            return NO;
        }
    }
    
    
    NSMutableString* mStr = [NSMutableString stringWithCapacity:8];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(6, 1)]]];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(3, 1)]]];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(7, 1)]]];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(1, 1)]]];
    
    if([mStr intValue] != 2019 )
    {
        [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title8"]];
        return NO;
    }
    
    [mStr appendString:@"-"];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(4, 1)]]];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(5, 1)]]];
    [mStr appendString:@"-"];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(0, 1)]]];
    [mStr appendString:[self getChart:[account substringWithRange:NSMakeRange(2, 1)]]];
    
    return ![self checkIsExpired:mStr];
        
}

- (NSString* )getChart:(NSString* )key
{
    if (key == nil || [key isEqualToString:@""])
    {
        return @"";
    }
    
    return [self.muDic objectForKey:key];
}

- (BOOL)checkPw:(NSString* )password
{
    if((password == nil || [password isEqualToString:@""]))
    {
        [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title7"]];
        return NO;
    }
    
    if(![password isEqualToString:@"123456"])
    {
        [self showAlterController:[DSLHKIDCardBundle IDCardBundleString:@"login_vc_title7"]];
        return NO;
    }
    return YES;
}


- (NSDate *)dateFromString:(NSString *)string withFormat:(NSString *)format {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    NSDate *date = [formatter dateFromString:string];
    return date;
}

- (BOOL)checkIsExpired:(NSString* )dateStr
{
    NSDate* expiredDate = [self dateFromString:dateStr withFormat:@"yyyy-MM-dd"];
    
    if(expiredDate == nil || [[NSDate date] compare:expiredDate] == NSOrderedDescending)
    {
        [self showAlterController:@"App使用已過期，請聯系供應商"];
        return YES;
    }
    
    return NO;
}

- (void)showAlterController:(NSString* )msg
{
    //@"App使用已過期，請聯系供應商"
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:msg message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [actionSheet addAction:action1];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

- (void)showLoading
{
    if (_hud == nil)
    {
        _hud = [[MBProgressHUD alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
        _hud.removeFromSuperViewOnHide = YES;
        _hud.userInteractionEnabled = NO;
        if(self.navigationController)
        {
            [_hud setCenter:self.navigationController.view.center];
            [self.navigationController.view addSubview:_hud];
        }
        else
        {
            [_hud setCenter:self.view.center];
            [self.view addSubview:_hud];
        }
        [_hud show:YES];
    }
}

- (void)hideLoading
{
    if ( _hud )
    {
        [_hud hide:YES];
        _hud = nil;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

- (void)deviceWANIPAddress
{
    NSLog(@"deviceWANIPAddress start...");
    
    NSURL *ipURL = [NSURL URLWithString:@"http://ip.taobao.com/service/getIpInfo.php?ip=myip"];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSData *data = [NSData dataWithContentsOfURL:ipURL];
            NSString *ipStr = nil;
            if(data == nil)
            {
                NSLog(@"data is nil");
                ipStr = [DSLHKIDCardBundle IDCardBundleString:@"login_vc_title10"];
            }
            else
            {
                NSDictionary *ipDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                if (ipDic && [ipDic[@"code"] integerValue] == 0) { //获取成功
                    ipStr = ipDic[@"data"][@"ip"];
                }
                NSLog(@"deviceWANIPAddress selfIP = %@", ipStr);
                
                if([ipStr isEqualToString:@""])
                {
                    ipStr = [DSLHKIDCardBundle IDCardBundleString:@"login_vc_title10"];
                }
                else
                {
                    ipStr = [NSString stringWithFormat:@"%@ %@", [DSLHKIDCardBundle IDCardBundleString:@"login_vc_title11"],ipStr];
                }
            }
            
            self.labelIP.text = ipStr;
        });
        
        
    });
    
}

- (void)delayGetSelfIP
{
    [self deviceWANIPAddress];
}

@end
