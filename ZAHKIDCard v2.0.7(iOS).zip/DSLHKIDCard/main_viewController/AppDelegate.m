//
//  AppDelegate.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/5/8.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "AppDelegate.h"
#import <ZASDKHelp/ZASDKHelp.h>
#import "ViewController.h"
#import "MainViewController.h"
#import "LoginViewController.h"
#import <Bugly/Bugly.h>
#import "DSLHKBaseIDCardViewController.h"
#import "DSLHKIDCardInDeskViewController.h"
#import "DSLHKIDCardViewController.h"

#import "DSLMCVIDCardViewController.h"
#import "DSLMCVMainViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

+(instancetype)sharedInstance
{
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [Bugly startWithAppId:@"7aace26366"];
    
    //SDK验权
    [[ZASDKAuthorization sharedInstance] zaSDKAuthorization:^(int result) {
        if(result == 0)
        {
            NSLog(@"验权成功");
        }
        else if(result == 1)
        {
            NSLog(@"验权失败");
        }
        else if(result == -1)
        {
            NSLog(@"网络错误");
        }
        else if(result == 3)
        {
            NSLog(@"当前使用的sdk版本过低");
        }
    }];
//    [[ZASDKAuthorization sharedInstance] zaSDKAuthorization:@"84a3dcb728d9450ba3a3483088b31c57"
//                                                     Secret:@"vvtONGt3JZcJfyMbEtqnDr4UtXCRCPPr" Completion:^(int result)
//     {
//         if(result == 0)
//         {
//             NSLog(@"验权成功");
//         }
//         else if(result == 1)
//         {
//             NSLog(@"验权失败");
//         }
//         else if(result == -1)
//         {
//             NSLog(@"网络错误");
//         }
//         else if(result == 3)
//         {
//             NSLog(@"当前使用的sdk版本过低");
//         }
//     }];
    
    return YES;
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (void)gotoMainVc
{
    //ViewController* vc = [[ViewController alloc] init];
    MainViewController* vc = [[MainViewController alloc] init];
    UINavigationController* naVC = [[UINavigationController alloc] initWithRootViewController:vc];
    [AppDelegate sharedInstance].window.rootViewController = naVC;
    [[AppDelegate sharedInstance].window makeKeyAndVisible];
    
}

- (void)gotoLoginVc
{
    LoginViewController* vc = [[LoginViewController alloc] init];
    
    [AppDelegate sharedInstance].window.rootViewController = vc;
    [[AppDelegate sharedInstance].window makeKeyAndVisible];
}

- (void)gotoIDCardVc:(DSLHKIDCardTypeApp)recType useLiteVersion:(BOOL)userLiteVersion
{
    DSLHKBaseIDCardViewController *vc;//[[DSLHKBaseIDCardViewController alloc] init];
    if(NO)
    {
        vc = [[DSLHKIDCardInDeskViewController alloc] init];
        vc.iOpType = 1;
    }
    else
    {
        vc = [[DSLHKIDCardViewController alloc] init];
        vc.isVideoDataOnlyCollectionMode = NO;
        vc.iOpType = 0;
    }
    
    //vc.isVideoDataOnlyCollectionMode = self.switchVideoDataOnlyCollection.on;
    vc.useLiteVersion = userLiteVersion;
    vc.recType = recType;
   
    UINavigationController* naVC = [[UINavigationController alloc] initWithRootViewController:vc];
    
    [AppDelegate sharedInstance].window.rootViewController = naVC;
    [[AppDelegate sharedInstance].window makeKeyAndVisible];
}

- (void)gotoMCVVc
{
    DSLMCVBaseIDCardViewController *vc;
    vc = [[DSLMCVIDCardViewController alloc] init];
   
    UINavigationController* naVC = [[UINavigationController alloc] initWithRootViewController:vc];
    
    [AppDelegate sharedInstance].window.rootViewController = naVC;
    [[AppDelegate sharedInstance].window makeKeyAndVisible];
}

- (void)gotoHKIDCard_MCV
{
    DSLMCVMainViewController *vc;
      vc = [[DSLMCVMainViewController alloc] init];
     
      UINavigationController* naVC = [[UINavigationController alloc] initWithRootViewController:vc];
      
      [AppDelegate sharedInstance].window.rootViewController = naVC;
      [[AppDelegate sharedInstance].window makeKeyAndVisible];
    
}
@end
