//
//  IRNetworkEngine.m
//  InterOCR
//
//  Created by Carl Fu on 2018/7/11.
//  Copyright © 2018 Carl Fu. All rights reserved.
//

#import "IRNetworkEngine.h"
#import "DSLHKIDCardConfig.h"

#define kBOUNDARY @"abc"
#define kEnvKey @"kIREnv"


@implementation IRNetworkEngine

+ (NSString* )baseUrl
{
    
    NSString* url = @"";
    switch (USE_TYPE_URL) {
        case 0:
            url = kShanghaiBaseUrl;
            break;
        case 1:
            url = kVBBaseUrl;
            break;
        case 2:
            url = kTUBaseUrl;
            break;
        default:
            url = kShanghaiBaseUrl;
            break;
    }
    return url;
}
+ (void)loginService:(NSString* _Nullable)path parameters:(NSDictionary* _Nullable)params header:(NSDictionary* _Nullable)header completionHandler:(IRNetCompletionHandler _Nullable)completionHandler
{
    // 1、创建URL资源地址
    
    NSString *urlPath = [NSString stringWithFormat:@"%@%@",  [[self class] baseUrl], path];
    NSURL *url = [NSURL URLWithString:urlPath];
    // 2、创建Reuest请求
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    // 文件上传使用post
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json; charset=utf8" forHTTPHeaderField:@"Content-Type"];
    
    // 设置请求超时
    [request setTimeoutInterval:20.0f];
    NSArray* arr = [header allKeys];
    for(int i = 0; i < [arr count]; ++i)
    {
        NSString* key = [arr objectAtIndex:i];
        [request setValue:[header objectForKey:key] forHTTPHeaderField:key];
    }
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:&error];
    if(jsonData)
    {
        request.HTTPBody = jsonData;
    }
    // 创建会话
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask* loginTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSDictionary *result = nil;
        if (error) {
            NSLog(@"loginService error:%@",error);
        } else {
            result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
            NSLog(@"loginService success：%@", result);
        }
        
        if (completionHandler) {
            completionHandler(result, error);
        }
        
    }];
    
    [loginTask resume];
}

+ (void)uploadTaskIRService:(NSString *)path
                      files:(NSArray *)files
                   filename:(NSString *)filename
                 header:(NSDictionary* _Nullable)header
                 parameters:(NSDictionary *)params
                     custom:(NSDictionary* )custom
          completionHandler:(IRNetCompletionHandler)completionHandler {
  // 以流的方式上传，大小理论上不受限制，但应注意时间
  // 1、创建URL资源地址
    NSString *urlPath = [NSString stringWithFormat:@"%@%@",  [[self class] baseUrl], path];
    NSLog(@"uploadTaskIRService url = %@", urlPath);
  NSURL *url = [NSURL URLWithString:urlPath];
  // 2、创建Reuest请求
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
  // 3、配置Request
  //设置Body值方法二，这种方法比较原始，不常用，不过可以用来上传参数和文件
//  NSString *BOUNDARY = @"boundary";//表单分界线 可以自定义任意值
  [request setValue:[@"multipart/form-data; boundary=" stringByAppendingString: kBOUNDARY] forHTTPHeaderField:@"Content-Type"];
  
  // 文件上传使用post
  [request setHTTPMethod:@"POST"];
  // 设置请求超时
  [request setTimeoutInterval:240.0f];
  
  NSString* userName = [[NSUserDefaults standardUserDefaults] objectForKey:USER_NAME];
  [request setValue:userName forHTTPHeaderField:@"user"];
  
    NSArray* arr = [header allKeys];
    for(int i = 0; i < [arr count]; ++i)
    {
        NSString* key = [arr objectAtIndex:i];
        [request setValue:[header objectForKey:key] forHTTPHeaderField:key];
    }
    
  NSData *body = [[self class] body:filename files:files params:params Custom:custom];
  
  // 创建会话
  NSURLSession *session = [NSURLSession sharedSession];
  
  // 3.开始上传   request的body data将被忽略，而由fromData提供
  NSURLSessionUploadTask *uploadTask= [session uploadTaskWithRequest:request fromData:body completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
    
    NSDictionary *result = nil;
    if (error) {
      NSLog(@"uploadTaskIRService error:%@",error);
    } else {
      result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
    }

    if (completionHandler) {
      completionHandler(result, error);
    }
  }];
  //执行任务
  [uploadTask resume];
}

+ (void)getServiceVersion:(NSString* _Nullable)path completionHandler:(IRNetCompletionHandler _Nullable)completionHandler
{
    // 1、创建URL资源地址

       NSString *urlPath = [NSString stringWithFormat:@"%@%@",  [[self class] baseUrl], path];
       NSURL *url = [NSURL URLWithString:urlPath];
       // 2、创建Reuest请求
       NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
       // 文件上传使用post
       [request setHTTPMethod:@"GET"];
       [request setValue:@"application/json; charset=utf8" forHTTPHeaderField:@"Content-Type"];
       
       // 设置请求超时
       [request setTimeoutInterval:20.0f];
       
       NSError *error;
       // 创建会话
       NSURLSession *session = [NSURLSession sharedSession];
       NSURLSessionDataTask* getVersionTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
           
           NSDictionary *result = nil;
           if (error) {
               NSLog(@"getServiceVersion error:%@",error);
           } else {
               result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
               NSLog(@"getServiceVersion success：%@", result);
           }
           
           if (completionHandler) {
               completionHandler(result, error);
           }
           
       }];
       
       [getVersionTask resume];
}
// 构建请求体
+ (NSData *)body:(NSString *)fieldName files:(NSArray *)files params:(NSDictionary *)params Custom:(NSDictionary* )custom{
  NSMutableData *mData = [NSMutableData data];
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="userfile[]"; filename="head1.png"
  //    Content-Type: image/png
  //
  //    文件二进制数据
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="userfile[]"; filename="head2.png"
  //    Content-Type: image/png
  //
  //    文件二进制数据
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="username"
  //
  //    mazaiting
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X--
  
  // 构建文件,遍历数组
  [files enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    //              ------WebKitFormBoundaryJa8BALfIc9saou2X
    //            Content-Disposition: form-data; name="userfile[]"; filename="head2.png"
    //            Content-Type: image/png
    //
    //            文件二进制数据
    
    NSMutableString *mString = [NSMutableString string];
    // 判断是否是第一个文件，如果是则不需要添加"\r\n"
    if (idx != 0) {
      [mString appendString:@"\r\n"];
    }
    [mString appendFormat:@"--%@\r\n", kBOUNDARY];
    [mString appendFormat:@"Content-Disposition: form-data; name=%@; filename=%@\r\n", fieldName, [NSString stringWithFormat:@"file%ld", idx]];
    [mString appendString:@"Content-Type: application/octet-stream\r\n"];
    [mString appendString:@"\r\n"];
    [mData appendData:[mString dataUsingEncoding:NSUTF8StringEncoding]];
    
    // 拼接文件的二进制数据
    NSData *data = (NSData *)obj;
    [mData appendData:data];
  }];
  
  // 构建数据
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="username"
  //
  //    mazaiting
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X--
  [params enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
    NSMutableString *mString = [NSMutableString string];
    [mString appendFormat:@"\r\n--%@\r\n", kBOUNDARY];
    [mString appendFormat:@"Content-Disposition: form-data; name=%@\r\n", key];
    [mString appendString:@"\r\n"];
    [mString appendFormat:@"%@", obj];
    [mData appendData:[mString dataUsingEncoding:NSUTF8StringEncoding]];
  }];
  
    if(custom)
    {
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:custom options:NSJSONWritingPrettyPrinted error:&error];
        NSString *jsonString;
        if (jsonData)
        {
            jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        }
        if(!(jsonString == nil || [jsonString isEqualToString:@""]))
        {
            NSMutableString *mString = [NSMutableString string];
            [mString appendFormat:@"\r\n--%@\r\n", kBOUNDARY];
            [mString appendFormat:@"Content-Disposition: form-data; name=custom\r\n"];
            [mString appendString:@"\r\n"];
            [mString appendFormat:@"%@", jsonString];
            [mData appendData:[mString dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }
    
  // 结束语句
  NSString *end = [NSString stringWithFormat:@"\r\n--%@--", kBOUNDARY];
  [mData appendData:[end dataUsingEncoding:NSUTF8StringEncoding]];
  
  return mData.copy;
}

// 构建请求体
+ (NSData *)bodyForMCV:(NSArray *_Nullable)fieldNames files:(NSArray *)files params:(NSDictionary *)params Custom:(NSDictionary* )custom {
  NSMutableData *mData = [NSMutableData data];
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="userfile[]"; filename="head1.png"
  //    Content-Type: image/png
  //
  //    文件二进制数据
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="userfile[]"; filename="head2.png"
  //    Content-Type: image/png
  //
  //    文件二进制数据
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="username"
  //
  //    mazaiting
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X--
  
  // 构建文件,遍历数组
  [files enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
    //              ------WebKitFormBoundaryJa8BALfIc9saou2X
    //            Content-Disposition: form-data; name="userfile[]"; filename="head2.png"
    //            Content-Type: image/png
    //
    //            文件二进制数据
    
    NSMutableString *mString = [NSMutableString string];
    // 判断是否是第一个文件，如果是则不需要添加"\r\n"
    if (idx != 0) {
      [mString appendString:@"\r\n"];
    }
    [mString appendFormat:@"--%@\r\n", kBOUNDARY];
    [mString appendFormat:@"Content-Disposition: form-data; name=%@; filename=%@.jpg\r\n", fieldNames[idx],fieldNames[idx]];
    [mString appendString:@"Content-Type: application/octet-stream\r\n"];
    [mString appendString:@"\r\n"];
    [mData appendData:[mString dataUsingEncoding:NSUTF8StringEncoding]];
    
    // 拼接文件的二进制数据
    NSData *data = (NSData *)obj;
    [mData appendData:data];
  }];
  
  // 构建数据
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X
  //    Content-Disposition: form-data; name="username"
  //
  //    mazaiting
  //    ------WebKitFormBoundaryJa8BALfIc9saou2X--
  [params enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
    NSMutableString *mString = [NSMutableString string];
    [mString appendFormat:@"\r\n--%@\r\n", kBOUNDARY];
    [mString appendFormat:@"Content-Disposition: form-data; name=%@\r\n", key];
    [mString appendString:@"\r\n"];
    [mString appendFormat:@"%@", obj];
    [mData appendData:[mString dataUsingEncoding:NSUTF8StringEncoding]];
  }];
  
    if(custom)
    {
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:custom options:NSJSONWritingPrettyPrinted error:&error];
        NSString *jsonString;
        if (jsonData)
        {
            jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        }
        if(!(jsonString == nil || [jsonString isEqualToString:@""]))
        {
            NSMutableString *mString = [NSMutableString string];
            [mString appendFormat:@"\r\n--%@\r\n", kBOUNDARY];
            [mString appendFormat:@"Content-Disposition: form-data; name=custom\r\n"];
            [mString appendString:@"\r\n"];
            [mString appendFormat:@"%@", jsonString];
            [mData appendData:[mString dataUsingEncoding:NSUTF8StringEncoding]];
        }
    }
    
  // 结束语句
  NSString *end = [NSString stringWithFormat:@"\r\n--%@--", kBOUNDARY];
  [mData appendData:[end dataUsingEncoding:NSUTF8StringEncoding]];
  
  return mData.copy;
}

/// filePath:要上传的文件路径   formName：表单控件名称  reName：上传后文件名
+ (NSData *)getHttpBodyWithFilePath:(NSString *)filePath formName:(NSString *)formName reName:(NSString *)reName
{
  NSMutableData *data = [NSMutableData data];
  NSURLResponse *response = [self getLocalFileResponse:filePath];
  // 文件类型：MIMEType  文件的大小：expectedContentLength  文件名字：suggestedFilename
  NSString *fileType = response.MIMEType;
  
  // 如果没有传入上传后文件名称,采用本地文件名!
  if (reName == nil) {
    reName = response.suggestedFilename;
  }
  
  // 表单拼接
  NSMutableString *headerStrM =[NSMutableString string];
  [headerStrM appendFormat:@"--%@\r\n",@"boundary"];
  // name：表单控件名称  filename：上传文件名
  [headerStrM appendFormat:@"Content-Disposition: form-data; name=%@; filename=%@\r\n", formName, reName];
  [headerStrM appendFormat:@"Content-Type: %@\r\n\r\n",fileType];
  [data appendData:[headerStrM dataUsingEncoding:NSUTF8StringEncoding]];
  
  // 文件内容
  NSData *fileData = [NSData dataWithContentsOfFile:filePath];
  [data appendData:fileData];
  
  NSMutableString *footerStrM = [NSMutableString stringWithFormat:@"\r\n--%@--\r\n",@"boundary"];
  [data appendData:[footerStrM  dataUsingEncoding:NSUTF8StringEncoding]];
  //    NSLog(@"dataStr=%@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
  return data;
}

/// 获取响应，主要是文件类型和文件名
+ (NSURLResponse *)getLocalFileResponse:(NSString *)urlString
{
  urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLFragmentAllowedCharacterSet]];
  // 本地文件请求
  NSURL *url = [NSURL fileURLWithPath:urlString];
  NSURLRequest *request = [NSURLRequest requestWithURL:url];
  
  __block NSURLResponse *localResponse = nil;
  // 使用信号量实现NSURLSession同步请求
  dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
  [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
    localResponse = response;
    dispatch_semaphore_signal(semaphore);
  }] resume];
  dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
  return  localResponse;
}

+ (void)uploadJsonFile:(NSString* _Nullable)path JsonStr:(NSString* _Nullable)jsonStr FileKey: (NSString* _Nullable) key completionHandler:(IRNetCompletionHandler _Nullable)completionHandler
{
    // 1、创建URL资源地址

    NSString *urlPath = [NSString stringWithFormat:@"%@%@",  [[self class] baseUrl], path];
    NSURL *url = [NSURL URLWithString:urlPath];
    // 2、创建Reuest请求
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    // 文件上传使用post
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json; charset=utf8" forHTTPHeaderField:@"Content-Type"];
    
    // 设置请求超时
    [request setTimeoutInterval:20.0f];
    NSData* jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
    if(jsonData)
    {
        request.HTTPBody = jsonData;
    }
    // 创建会话
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask* uploadTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSDictionary *result = nil;
        if (error) {
            NSLog(@"uploadJsonFile error:%@",error);
        } else {
            result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
            NSLog(@"uploadJsonFile success：%@", result);
        }
        
        if (completionHandler) {
            completionHandler(result, error);
        }
        
    }];
    
    [uploadTask resume];
}

+ (void)uploadStatistics:(NSString* _Nullable)path UploadData:(NSString* _Nullable)uploadData completionHandler:(IRNetCompletionHandler _Nullable)completionHandler
{
   NSString *urlPath = [NSString stringWithFormat:@"%@%@",  [[self class] baseUrl], path];
   NSURL *url = [NSURL URLWithString:urlPath];
   // 2、创建Reuest请求
   NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
   // 文件上传使用post
   [request setHTTPMethod:@"POST"];
   [request setValue:@"application/json; charset=utf8" forHTTPHeaderField:@"Content-Type"];
   
   // 设置请求超时
   [request setTimeoutInterval:30.0f];
   NSData* jsonData = [uploadData dataUsingEncoding:NSUTF8StringEncoding];
   if(jsonData)
   {
       request.HTTPBody = jsonData;
   }
   // 创建会话
   NSURLSession *session = [NSURLSession sharedSession];
   NSURLSessionDataTask* uploadTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
       
       NSDictionary *result = nil;
       if (error) {
           NSLog(@"uploadStatistics error:%@",error);
       } else {
           result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
           NSLog(@"uploadStatistics success：%@", result);
       }
       
       if (completionHandler) {
           completionHandler(result, error);
       }
       
   }];
   
   [uploadTask resume];
}

+ (void)uploadTaskIRServiceForMCV:(NSString *)path
                      files:(NSArray *)files
                   filenames:(NSArray *_Nullable)filenames
                 header:(NSDictionary* _Nullable)header
                 parameters:(NSDictionary *)params
                     custom:(NSDictionary* )custom
          completionHandler:(IRNetCompletionHandler)completionHandler {
  // 以流的方式上传，大小理论上不受限制，但应注意时间
  // 1、创建URL资源地址
    NSString *urlPath = [NSString stringWithFormat:@"%@/mcv/api/%@",  kShanghaiBaseUrl, path];
    NSLog(@"uploadTaskIRService url = %@", urlPath);
  NSURL *url = [NSURL URLWithString:urlPath];
  // 2、创建Reuest请求
  NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
  // 3、配置Request
  //设置Body值方法二，这种方法比较原始，不常用，不过可以用来上传参数和文件
//  NSString *BOUNDARY = @"boundary";//表单分界线 可以自定义任意值
  [request setValue:[@"multipart/form-data; boundary=" stringByAppendingString: kBOUNDARY] forHTTPHeaderField:@"Content-Type"];
  
  // 文件上传使用post
  [request setHTTPMethod:@"POST"];
  // 设置请求超时
  [request setTimeoutInterval:240.0f];
  
//  NSString* userName = [[NSUserDefaults standardUserDefaults] objectForKey:USER_NAME];
//  [request setValue:userName forHTTPHeaderField:@"user"];
  
    NSArray* arr = [header allKeys];
    for(int i = 0; i < [arr count]; ++i)
    {
        NSString* key = [arr objectAtIndex:i];
        [request setValue:[header objectForKey:key] forHTTPHeaderField:key];
    }
    
  NSData *body = [[self class] bodyForMCV:filenames files:files params:params Custom:custom];
  
  // 创建会话
  NSURLSession *session = [NSURLSession sharedSession];
  
  // 3.开始上传   request的body data将被忽略，而由fromData提供
  NSURLSessionUploadTask *uploadTask= [session uploadTaskWithRequest:request fromData:body completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
    
    NSDictionary *result = nil;
    if (error) {
      NSLog(@"uploadTaskIRService error:%@",error);
    } else {
        NSString* str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
      result = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:&error];
    }

    if (completionHandler) {
      completionHandler(result, error);
    }
  }];
  //执行任务
  [uploadTask resume];
}
@end
