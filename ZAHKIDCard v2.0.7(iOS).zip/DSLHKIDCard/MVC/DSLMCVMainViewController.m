//
//  DSLMCVMainViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun13 on 2020/11/27.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "DSLMCVMainViewController.h"
#import "DSLMCVIDCardBundle.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLMCVGuideViewController.h"
#import "MainViewController.h"

@interface DSLMCVMainViewController ()

@end

@implementation DSLMCVMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupView];
}

- (void)setupView
{
    UIImageView* imgViewBk =[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mcv_main_bk"]];
    imgViewBk.frame = self.view.bounds;
    imgViewBk.userInteractionEnabled = YES;
    [self.view addSubview:imgViewBk];
    
    UILabel* labelTitle1 = [[UILabel alloc] init];
    labelTitle1.textColor = [UIColor whiteColor];
    labelTitle1.font = [UIFont fontWithName:@"PingFangSC-Regular" size:24];
    labelTitle1.textAlignment = NSTextAlignmentCenter;
    labelTitle1.text = [DSLMCVIDCardBundle IDCardBundleString:@"mcv_main_title1"];
    labelTitle1.frame = CGRectMake(0.0, 216, self.view.bounds.size.width, 28.0);
    [imgViewBk addSubview:labelTitle1];
    
    UILabel* labelTitle2 = [[UILabel alloc] init];
    labelTitle2.textColor = [UIColor dslc_colorWithHexString:@"0xFFFFFF" alpha:0.5];
    labelTitle2.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
    labelTitle2.textAlignment = NSTextAlignmentCenter;
    labelTitle2.text = [DSLMCVIDCardBundle IDCardBundleString:@"mcv_main_title2"];
    labelTitle2.frame = CGRectMake(0.0, labelTitle1.frame.origin.y+labelTitle1.frame.size.height+10, self.view.bounds.size.width, 16.0);
    [imgViewBk addSubview:labelTitle2];
    
    UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_main_title3"] forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor dslc_colorWithHexString:@"#0266FF"] forState:UIControlStateNormal];
    //[btn setBackgroundColor:[UIColor dslc_colorWithHexString:@"#8CB9FF"]];
    [btn setBackgroundColor:[UIColor whiteColor]];
    btn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:18];
    [btn addTarget:self action:@selector(clickGoMCVBtn:) forControlEvents:UIControlEventTouchUpInside];
    btn.layer.cornerRadius = 25;
    
    btn.frame = CGRectMake((self.view.bounds.size.width-208)/2, labelTitle2.frame.origin.y+labelTitle2.frame.size.height+32, 208, 52);
    [imgViewBk addSubview:btn];
    
    //隐藏【mcv识别】按钮
    btn.hidden = NO;
    
    UIButton* btnHKIDCard = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnHKIDCard setTitle:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_main_title6"] forState:UIControlStateNormal];
    [btnHKIDCard setTitleColor:[UIColor dslc_colorWithHexString:@"#0266FF"] forState:UIControlStateNormal];
    [btnHKIDCard setBackgroundColor:[UIColor whiteColor]];
    btnHKIDCard.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:18];
    [btnHKIDCard addTarget:self action:@selector(clickGoHKIDCardBtn:) forControlEvents:UIControlEventTouchUpInside];
    btnHKIDCard.layer.cornerRadius = 25;
    
    btnHKIDCard.frame = CGRectMake((self.view.bounds.size.width-208)/2, btn.frame.origin.y+btn.frame.size.height+32, 208, 52);
    [imgViewBk addSubview:btnHKIDCard];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //self.navigationController.navigationBarHidden = NO;
}

- (void)clickGoMCVBtn:(id)sender
{
    DSLMCVGuideViewController* vc = [[DSLMCVGuideViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
//     vc.modalPresentationStyle = UIModalPresentationFullScreen;
//      [self presentViewController:vc animated:YES completion:^{
//          
//      }];
}
- (void)clickGoHKIDCardBtn:(id)sender
{
    MainViewController* vc = [[MainViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
    
//     vc.modalPresentationStyle = UIModalPresentationFullScreen;
//      [self presentViewController:vc animated:YES completion:^{
//
//      }];
}


@end
