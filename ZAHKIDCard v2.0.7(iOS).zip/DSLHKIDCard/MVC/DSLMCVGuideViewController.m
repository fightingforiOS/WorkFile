//
//  DSLMCVGuideViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun13 on 2020/11/27.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "DSLMCVGuideViewController.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLMCVIDCardBundle.h"
#import "AppDelegate.h"
#import "DSLHKIDCardConfig.h"

#define AllowClickBtnTimes 8

@interface DSLMCVGuideViewController ()

@property(nonatomic, strong) UIScrollView* myScrollView;

@property(nonatomic, strong) NSTimer* timerAllowClickBtn;
@property(nonatomic, assign) int timerAllowClickBtnCount;
@property(nonatomic, strong) UIButton* btnGo;
@end

@implementation DSLMCVGuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self setupView];
    [self initTimerAllowClickBtn];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self startTimerAllowClickBtn];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)setupView
{
    [self.view addSubview:self.myScrollView];
    UIImage* img = [UIImage imageNamed:@"mcv_guide_bk"];
    UIImageView* imgView = [[UIImageView alloc] initWithImage:img];
    imgView.frame = CGRectMake((self.view.bounds.size.width-320)/2, 0.0, 320, 1114);
    [self.myScrollView addSubview:imgView];
    
    [self.view addSubview:self.btnGo];
    self.btnGo.frame = CGRectMake((self.view.bounds.size.width-320)/2, self.view.bounds.size.height-90, 320, 70);
    
}

- (UIButton* )btnGo
{
    if(_btnGo == nil)
    {
        _btnGo = [UIButton buttonWithType:UIButtonTypeCustom];
         [_btnGo setTitle:[NSString stringWithFormat:@"%@: %i(s)", [DSLMCVIDCardBundle IDCardBundleString:@"mcv_main_title5"], self.timerAllowClickBtnCount] forState:UIControlStateNormal];
        
        if([self isFirstGiude])
        {
            _btnGo.userInteractionEnabled = NO;
            [_btnGo setTitleColor:[UIColor dslc_colorWithHexString:@"#828282"] forState:UIControlStateNormal];
            [_btnGo setBackgroundImage:[UIImage imageNamed:@"mcv_result_btn_disable"] forState:UIControlStateNormal];
        }
        else
        {
            [_btnGo setBackgroundImage:[UIImage imageNamed:@"mcv_result_btn_normal"] forState:UIControlStateNormal];
            _btnGo.userInteractionEnabled = YES;
            [_btnGo setTitleColor:[UIColor dslc_colorWithHexString:@"#FFFFFF"] forState:UIControlStateNormal];

        }
        
        [_btnGo addTarget:self action:@selector(clickGoBtn:) forControlEvents:UIControlEventTouchUpInside];
         _btnGo.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
         _btnGo.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
         _btnGo.contentEdgeInsets = UIEdgeInsetsMake(-24, 0, 0, 0);
    }
    
    return _btnGo;
}
- (UIScrollView* )myScrollView
{
    if(_myScrollView == nil)
    {
        _myScrollView = [UIScrollView new];
        _myScrollView.frame = CGRectMake(0.0, 0.0, self.view.bounds.size.width, self.view.bounds.size.height);
        _myScrollView.backgroundColor = [UIColor whiteColor];
    
        _myScrollView.contentSize = CGSizeMake(320, 1292-64);
        _myScrollView.showsVerticalScrollIndicator = NO;
        _myScrollView.showsHorizontalScrollIndicator = NO;
    }
    
    return _myScrollView;
}

- (void)clickGoBtn:(id)sender
{
    [self stopTimerAllowClickBtn];
    
    [[AppDelegate sharedInstance] gotoMCVVc];
}

- (void)initTimerAllowClickBtn
{
    if(self.timerAllowClickBtn == nil)
    {
        self.timerAllowClickBtnCount = AllowClickBtnTimes;
        self.timerAllowClickBtn = [NSTimer timerWithTimeInterval:1 target:self selector:@selector(timedimerAllowClickBtn:) userInfo:nil repeats:YES];
    }
}
- (void)timedimerAllowClickBtn:(NSTimer* )timer
{
    if(self.timerAllowClickBtnCount == 1)
    {
        if([self isFirstGiude])
        {
            [[NSUserDefaults standardUserDefaults] setObject:@"firstGiude" forKey:FirstGiude];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
         [self.btnGo setTitle:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_main_title4"] forState:UIControlStateNormal];
         [self.btnGo setBackgroundImage:[UIImage imageNamed:@"mcv_result_btn_normal"] forState:UIControlStateNormal];
        self.btnGo.userInteractionEnabled = YES;
        [self.btnGo setTitleColor:[UIColor dslc_colorWithHexString:@"#FFFFFF"] forState:UIControlStateNormal];
        [self stopTimerAllowClickBtn];
        
    }
    else
    {
        self.timerAllowClickBtnCount--;
        [self.btnGo setTitle:[NSString stringWithFormat:@"%@: %i(s)", [DSLMCVIDCardBundle IDCardBundleString:@"mcv_main_title5"], self.timerAllowClickBtnCount] forState:UIControlStateNormal];
    }
}

- (void)startTimerAllowClickBtn
{
    self.timerAllowClickBtnCount = AllowClickBtnTimes;
    [self stopTimerAllowClickBtn];
    [self.timerAllowClickBtn setFireDate:[NSDate distantPast]];
    [[NSRunLoop mainRunLoop] addTimer:self.timerAllowClickBtn forMode:NSDefaultRunLoopMode];
    
}
- (void)stopTimerAllowClickBtn
{
    [self.timerAllowClickBtn setFireDate: [NSDate distantFuture]];
}

- (BOOL)isFirstGiude
{
    NSString* firstGiude = [[NSUserDefaults standardUserDefaults] objectForKey:FirstGiude];
    return (firstGiude == nil || [firstGiude isEqualToString:@""]);
}

@end
