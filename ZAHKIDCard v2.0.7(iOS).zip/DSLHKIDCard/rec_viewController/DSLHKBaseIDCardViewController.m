//
//  DSLHKBaseIDCardViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/7/15.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "DSLHKBaseIDCardViewController.h"

#import <AssetsLibrary/AssetsLibrary.h>
#import <CoreImage/CoreImage.h>

#import <DSLHKIDCard/DSLHKIDCard.h>
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardConfig.h"
#import "DSLMovieRecorder.h"
#import <CoreMotion/CoreMotion.h>

#import "DSLHKBaseIDCardViewController+Statistics.h"

@interface DSLHKBaseIDCardViewController ()<AVCaptureVideoDataOutputSampleBufferDelegate, DSLMovieRecorderDelegate>

@property(nonatomic,strong)AVCaptureDeviceInput *captureInput;
@property(nonatomic,strong)AVCaptureVideoDataOutput *captureVideoDataOutput; // video output
@property(nonatomic, readwrite) AVCaptureVideoOrientation videoOrientation;

@property(nonatomic, strong) dispatch_queue_t videoProcessQueue;

//摄像头捕捉的显示层
@property(nonatomic,strong)AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;

//当前视频帧数据
@property(atomic, strong) NSData* curImgData;

@property(nonatomic, strong) DSLMovieRecorder* movieRecorder;

//视频存放路径
@property(nonatomic,strong)NSString *writeToVideoPath;

//半透明黑色遮罩
@property (nonatomic, strong) CAShapeLayer * maskLayer;
@property(nonatomic, strong) UIView* maskBgView;

//遮罩层颜色，默认黑色半透明
@property (nonatomic, strong) UIColor *maskColor;

@property(nonatomic, strong) NSTimer* timerPlayAnimation;    //播放动画定时器
@property(nonatomic, assign) BOOL bIDCardRotateAngleAdd;//动画角度变化方向，YES:表示增加；NO:表示减少
//当前操作动画类型
@property(nonatomic, assign) DSLHKIDCardPlayOpAnimation curPlayOpAnimationType;

@end

@implementation DSLHKBaseIDCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.videoProcessQueue = dispatch_queue_create("queue2019", NULL);
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.maskColor = [UIColor colorWithWhite: 0 alpha: 0.8];
    CGSize size = self.view.bounds.size;
    
    [self initIDCardToRect];
    
    //设置拍摄有效区域
    self.effectiveRect = CGRectMake(0, (size.height-size.width)/2, size.width, size.width);
    
    [self.view.layer insertSublayer:self.captureVideoPreviewLayer atIndex:0];
    
    [self.view addSubview:self.maskBgView];
    
    [self.view addSubview:self.imgViewRecStatus];
    self.imgViewRecStatus.hidden = NO;
    
    [self setupEffectiveRect];
    
    [self setupCamera];
    
    if(ALL_Save_Video)
    {
        self.movieRecorder = nil;
    }
    
    [self collectionStatisticsBaseInfo];
    
    self.bIDCardRotateAngleAdd = YES;
    self.curIDCardRotateAngle = 0;
    
    [self initPlayAnimationTimer];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)initIDCardToRect
{
    CGSize size = self.view.bounds.size;
    float x = size.width * 0.05;
    self.idCardToRect = CGRectMake(x,(size.height - 228)/2.0, size.width-2*x, 228);
}
-(AVCaptureDevice *)inputDevice{
    if (_inputDevice == nil) {
        _inputDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        NSError *error = nil;
        if([_inputDevice lockForConfiguration:&error])
        {
            //设置自动连续对焦
            if([_inputDevice isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus])
            {
                [_inputDevice setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
            }
            //设置近距离焦距模式
            if([_inputDevice isAutoFocusRangeRestrictionSupported])
            {
                _inputDevice.autoFocusRangeRestriction = AVCaptureAutoFocusRangeRestrictionNear;
            }
            
            [_inputDevice unlockForConfiguration];
        }
    }
    return _inputDevice;
}

-(AVCaptureDeviceInput *)captureInput{
    if (_captureInput == nil) {
        _captureInput = [AVCaptureDeviceInput deviceInputWithDevice:self.inputDevice error:nil];
    }
    return _captureInput;
}
-(AVCaptureVideoDataOutput *)captureVideoDataOutput{
    if (_captureVideoDataOutput == nil) {
        _captureVideoDataOutput = [[AVCaptureVideoDataOutput alloc] init];
        _captureVideoDataOutput.alwaysDiscardsLateVideoFrames = YES;
        [_captureVideoDataOutput setSampleBufferDelegate:self queue:dispatch_queue_create("catch.serial.queue", DISPATCH_QUEUE_SERIAL)];
        
        NSString* key = (NSString*)kCVPixelBufferPixelFormatTypeKey;
        NSNumber* value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA];
        NSDictionary* videoSettings = [NSDictionary dictionaryWithObject:value forKey:key];
        [_captureVideoDataOutput setVideoSettings:videoSettings];
        
        AVCaptureConnection *conn = [_captureVideoDataOutput connectionWithMediaType:AVMediaTypeVideo];

        [conn setVideoOrientation:AVCaptureVideoOrientationLandscapeLeft];
        
        _videoOrientation = [_captureVideoDataOutput connectionWithMediaType:AVMediaTypeVideo].videoOrientation;
    }
    return _captureVideoDataOutput;
}

-(AVCaptureVideoPreviewLayer *)captureVideoPreviewLayer{
    if (_captureVideoPreviewLayer == nil) {
        _captureVideoPreviewLayer = [AVCaptureVideoPreviewLayer layerWithSession:self.captureSession];
        _captureVideoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        _captureVideoPreviewLayer.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    }
    return _captureVideoPreviewLayer;
}

-(AVCaptureSession *)captureSession{
    if (_captureSession == nil) {
        _captureSession = [[AVCaptureSession alloc] init];
        [_captureSession setSessionPreset:AVCaptureSessionPresetHigh];//AVCaptureSessionPreset1920x1080
        //[_captureSession setSessionPreset:AVCaptureSessionPreset1920x1080];AVCaptureSessionPreset3840x2160
        //[_captureSession setSessionPreset:AVCaptureSessionPreset3840x2160];
    }
    return _captureSession;
}

- (UIImageView* )imgViewRecStatus
{
    if(_imgViewRecStatus == nil)
    {
        _imgViewRecStatus = [[FLAnimatedImageView alloc] init];
        _imgViewRecStatus.contentMode = UIViewContentModeScaleAspectFill;
        _imgViewRecStatus.clipsToBounds = YES;
        //_imgViewRecStatus.frame = CGRectMake((self.view.frame.size.width-375)/2, self.view.bounds.size.height-80-225, 375, 225);
        _imgViewRecStatus.frame = CGRectMake((self.view.frame.size.width-375/2)/2, self.view.bounds.size.height-80-225/2, 375/2, 225/2);
    }
    return _imgViewRecStatus;
}

- (void)setRecStatusGif:(DSLHKIDCardRecStatus)opType
{
    NSString* gifName = @"rightOp";
    switch (opType)
    {
        case DSLHKIDCardRecStatus_UpOrRight:
            gifName = (self.recType == DSLHKIDCardTypeApp_2003 ? @"upOp" : @"rightOp");
            break;
        case DSLHKIDCardRecStatus_DownOrLeft:
            gifName = (self.recType == DSLHKIDCardTypeApp_2003 ? @"downOp" : @"leftOp");
            break;
        default:
            break;
    }
    
    NSURL *gifUrl = [[NSBundle mainBundle] URLForResource:gifName withExtension:@"gif"];
    NSData *gifData = [NSData dataWithContentsOfURL:gifUrl];
    FLAnimatedImage *animatedImageGif = [FLAnimatedImage animatedImageWithGIFData:gifData];
    self.imgViewRecStatus.animatedImage = animatedImageGif;
}

- (UIView* )maskBgView
{
    if(_maskBgView == nil)
    {
        _maskBgView = [[UIView alloc] init];
        _maskBgView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    }
    return _maskBgView;
}

- (UIImageView* )idCardToRectImgView
{
    if(_idCardToRectImgView == nil)
    {
        _idCardToRectImgView = [[UIImageView alloc] init];
        if(self.recType == DSLHKIDCardTypeApp_2018)
        {
            _idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_un_bk"];
        }
        else
        {
            _idCardToRectImgView.image = [UIImage imageNamed:@"rec_old_card_un_bk"];
        }

        _idCardToRectImgView.frame = CGRectMake(self.idCardToRect.origin.x, (self.maskBgView.frame.size.height-self.idCardToRect.size.height)/2, self.idCardToRect.size.width, self.idCardToRect.size.height);
    }
    
    return _idCardToRectImgView;
}

/**黑色半透明遮掩层*/
- (CAShapeLayer *)maskLayer {
    if (!_maskLayer) {
        _maskLayer = [CAShapeLayer layer];
        _maskLayer.path = [self getMaskPathWithRect:self.view.bounds exceptRect:CGRectZero].CGPath;
        _maskLayer.fillColor = self.maskColor.CGColor;
    }
    return _maskLayer;
}

- (void)updateEffectiveRect:(BOOL)needDraw
{
    if(needDraw)
    {
        _maskLayer.path = [self getMaskPathWithRect:self.view.bounds exceptRect:self.effectiveRect].CGPath;
    }
    else
    {
        _maskLayer.path = [self getMaskPathWithRect:self.view.bounds exceptRect:CGRectZero].CGPath;
    }
    
    _maskLayer.fillColor = self.maskColor.CGColor;
}

/**生成空缺部分rect的layer*/
- (UIBezierPath *)getMaskPathWithRect: (CGRect)rect exceptRect: (CGRect)exceptRect
{
    if (!CGRectContainsRect(rect, exceptRect)) {
        return nil;
    }
    else if (CGRectEqualToRect(rect, CGRectZero)) {
        return nil;
    }
    
    CGFloat boundsInitX = CGRectGetMinX(rect);
    CGFloat boundsInitY = CGRectGetMinY(rect);
    CGFloat boundsWidth = CGRectGetWidth(rect);
    CGFloat boundsHeight = CGRectGetHeight(rect);
    
    CGFloat minX = CGRectGetMinX(exceptRect);
    CGFloat maxX = CGRectGetMaxX(exceptRect);
    CGFloat minY = CGRectGetMinY(exceptRect);
    CGFloat maxY = CGRectGetMaxY(exceptRect);
    CGFloat width = CGRectGetWidth(exceptRect);
    
    /** 添加路径*/
    UIBezierPath * path = [UIBezierPath bezierPathWithRect: CGRectMake(boundsInitX, boundsInitY, minX, boundsHeight)];
    [path appendPath: [UIBezierPath bezierPathWithRect: CGRectMake(minX, boundsInitY, width, minY)]];
    [path appendPath: [UIBezierPath bezierPathWithRect: CGRectMake(maxX, boundsInitY, boundsWidth - maxX, boundsHeight)]];
    [path appendPath: [UIBezierPath bezierPathWithRect: CGRectMake(minX, maxY, width, boundsHeight - maxY)]];
    
    return path;
}

/**配置拍摄范围*/
- (void)setupEffectiveRect{
    [self.maskBgView.layer addSublayer: self.maskLayer];
    
    [self.maskBgView addSubview:self.idCardToRectImgView];
    
}

- (void)resetVideoUI
{
    [self updateEffectiveRect:YES];
    
    self.maskLayer.hidden = NO;
    
    //证件背景框设置为未识别状态
    if(self.recType == DSLHKIDCardTypeApp_2018)
    {
        NSString* imgName = @"rec_new_card_un_bk";
        if(self.iOpType == 1)
        {
            imgName = @"in_desk_rec_new_card_un_bk";
        }
        self.idCardToRectImgView.image = [UIImage imageNamed:imgName];
    }
    else
    {
        NSString* imgName = @"rec_old_card_un_bk";
        if(self.iOpType == 1)
        {
            imgName = @"in_desk_rec_old_card_un_bk";
        }
        self.idCardToRectImgView.image = [UIImage imageNamed:imgName];
    }
}
#pragma mark -- 视频相关操作

-(void)setupCamera{
    if ([self.captureSession canAddInput:self.captureInput]) {
        [self.captureSession addInput:self.captureInput];
    }
    if ([self.captureSession canAddOutput:self.captureVideoDataOutput]) {
        [self.captureSession addOutput:self.captureVideoDataOutput];
    }
}

- (CGFloat)fileSize:(NSURL *)path
{
    return [[NSData dataWithContentsOfURL:path] length]/1024.00 /1024.00;
}

- (void)proccessRecordVideo
{
    
}
- (void)saveVideoToAlbum:(NSURL *)fileUrl {
    
    if(!Is_Save_Video_Picture && !Is_Local_Save && !ALL_Save_Video)
    {
        return;
    }
    
    NSLog(@"saveVideoToAlbum 当前视频文件大小 %f MB", [self fileSize:fileUrl]);
    __block ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    
    [library writeVideoAtPathToSavedPhotosAlbum:fileUrl
                                completionBlock:^(NSURL *assetURL, NSError *error) {
                                    if (error)
                                    {
                                        NSLog(@"Save video fail:%@",error);
                                    }
                                    else
                                    {
                                        NSLog(@"Save video succeed.");
                                        
                                        if(Is_Local_Save)
                                        {
                                            ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *imageAsset)
                                            {
                                                ALAssetRepresentation *imageRep = [imageAsset defaultRepresentation];
                                                //self.imageName = [NSString stringWithFormat:@"%@",[imageRep filename]];
                                                self.videoSaveAlbumFileName = [imageRep filename];
                                                NSLog(@"文件视频地址 : %@", [imageRep filename]);
                                            };
                                            
                                            ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
                                            [assetslibrary assetForURL:assetURL resultBlock:resultblock failureBlock:nil];
                                            
                                            NSLog(@"save video assetURL = %@, error = %@", assetURL, error);
                                            library = nil;
                                        }
                                    }
                                }];
}

//获得视频存放地址
- (NSString *)getVideoCachePath {
    NSString *videoCache = [NSTemporaryDirectory() stringByAppendingPathComponent:@"videos"] ;
    BOOL isDir = NO;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    BOOL existed = [fileManager fileExistsAtPath:videoCache isDirectory:&isDir];
    if ( !(isDir == YES && existed == YES) ) {
        [fileManager createDirectoryAtPath:videoCache withIntermediateDirectories:YES attributes:nil error:nil];
    };
    return videoCache;
}

- (NSString *)getUploadFile_type:(NSString *)type fileType:(NSString *)fileType {
    NSTimeInterval now = [[NSDate date] timeIntervalSince1970];
    NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"HHmmss"];
    NSDate * NowDate = [NSDate dateWithTimeIntervalSince1970:now];
    ;
    NSString * timeStr = [formatter stringFromDate:NowDate];
    NSString *fileName = [NSString stringWithFormat:@"%@_%@.%@",type,timeStr,fileType];
    return fileName;
}

- (NSString *)videoPath {
    if (!self.writeToVideoPath) {
        NSString *videoName = [self getUploadFile_type:@"video" fileType:@"mp4"];
        self.writeToVideoPath = [[self getVideoCachePath] stringByAppendingPathComponent:videoName];
    }
    
    return self.writeToVideoPath;
}

- (void)setNewVideoPath:(NSString *)newPath {
    if (!newPath) {
        self.writeToVideoPath = newPath;
    }
}

- (void)stopMovieRecorder
{
    if(self.movieRecorder)
    {
        NSLog(@"stopMovieRecorder stopRecording...");
        [self.movieRecorder stopRecording];
        self.movieRecorder = nil;
    }
}

//完成录像
- (void)finishVideoWriter{

    [self.movieRecorder finishRecording];
    NSLog(@"--------------------finishVideoWriter--------------------------");
}

- (CGAffineTransform)transformFromVideoBufferOrientationToOrientation:(AVCaptureVideoOrientation)orientation withAutoMirroring:(BOOL)mirror
{
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    CGFloat orientationAngleOffset = MGAngleOffsetFromPortraitOrientationToOrientation(orientation);
    CGFloat videoOrientationAngleOffset = MGAngleOffsetFromPortraitOrientationToOrientation(self.videoOrientation);
    
    CGFloat angleOffset = orientationAngleOffset - videoOrientationAngleOffset;
    transform = CGAffineTransformMakeRotation(angleOffset);
    transform = CGAffineTransformRotate(transform, -M_PI);
    
    return transform;
}

CGFloat MGAngleOffsetFromPortraitOrientationToOrientation(AVCaptureVideoOrientation orientation)
{
    CGFloat angle = 0.0;
    switch ( orientation )
    {
        case AVCaptureVideoOrientationPortrait:
            angle = 0.0;
            break;
        case AVCaptureVideoOrientationPortraitUpsideDown:
            angle = M_PI;
            break;
        case AVCaptureVideoOrientationLandscapeRight:
            angle = -M_PI_2;
            break;
        case AVCaptureVideoOrientationLandscapeLeft:
            angle = M_PI_2;
            break;
        default:
            break;
    }
    return angle;
}

-(NSData *)imageFromSampleBuffer:(CMSampleBufferRef) sampleBuffer // Create a CGImageRef from sample buffer data
{
    // Get a CMSampleBuffer's Core Video image buffer for the media data
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    
    // Lock the base address of the pixel buffer
    CVPixelBufferLockBaseAddress(imageBuffer, 0);
    
    // Get the number of bytes per row for the pixel buffer
    void *baseAddress = CVPixelBufferGetBaseAddress(imageBuffer);
    
    // Get the number of bytes per row for the pixel buffer
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer);
    
    // Get the pixel buffer width and height
    size_t width = CVPixelBufferGetWidth(imageBuffer);
    size_t height = CVPixelBufferGetHeight(imageBuffer);
    
    //    NSLog(@"w: %zu h: %zu bytesPerRow:%zu", width, height, bytesPerRow);
    
    // Create a device-dependent RGB color space
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    // Create a bitmap graphics context with the sample buffer data
    CGContextRef context = CGBitmapContextCreate(baseAddress,
                                                 width,
                                                 height,
                                                 8,
                                                 bytesPerRow,
                                                 colorSpace,
                                                 kCGBitmapByteOrder32Little
                                                 | kCGImageAlphaPremultipliedFirst);
    // Create a Quartz image from the pixel data in the bitmap graphics context
    CGImageRef quartzImage = CGBitmapContextCreateImage(context);
    
    // Unlock the pixel buffer
    CVPixelBufferUnlockBaseAddress(imageBuffer,0);
    
    // Free up the context and color space
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    
    UIImage *image = [UIImage imageWithCGImage:quartzImage
                                         scale:1.0f
                                   orientation:UIImageOrientationUp];
    
    // Release the Quartz image
    CGImageRelease(quartzImage);
    
//    UIImage* img = [self yp_imagecutWithOriginalImage:image withCutRect:self.effectiveRect];
//    return UIImageJPEGRepresentation(img, 1.0);
    
    return UIImageJPEGRepresentation(image, 1.0);
    
}

/** originalImage：原图片   rect：需要剪切的位置*/
- (UIImage *)yp_imagecutWithOriginalImage:(UIImage *)originalImage withCutRect:(CGRect)rect {
    CGImageRef subImageRef = CGImageCreateWithImageInRect(originalImage.CGImage, rect);
    CGRect smallRect = CGRectMake(0, 0, CGImageGetWidth(subImageRef), CGImageGetHeight(subImageRef));
    // 开启图形上下文
    UIGraphicsBeginImageContext(smallRect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextDrawImage(context, smallRect, subImageRef);
    UIImage * image = [UIImage imageWithCGImage:subImageRef];
    // 关闭图形上下文
    UIGraphicsEndImageContext();
    
    CGImageRelease(subImageRef);
    
    return image;
}

//录像功能
- (void)recordingCompressionSession:(CMSampleBufferRef )pixelBuffer
{
    @synchronized(self){
        
        if (!self.movieRecorder)
        {
            NSURL *url = [[NSURL alloc] initFileURLWithPath:[self videoPath]];
            
            self.movieRecorder = [[DSLMovieRecorder alloc] initWithURL:url];
            
            CMFormatDescriptionRef formatDescription = CMSampleBufferGetFormatDescription( pixelBuffer );
            
            CGAffineTransform videoTransform = [self transformFromVideoBufferOrientationToOrientation:(AVCaptureVideoOrientation)UIDeviceOrientationLandscapeLeft withAutoMirroring:NO];
            [self.movieRecorder addVideoTrackWithSourceFormatDescription:formatDescription transform:videoTransform settings:nil];
            
            dispatch_queue_t callbackQueue = dispatch_queue_create( "com.megvii.sample.capturepipeline.recordercallback", DISPATCH_QUEUE_SERIAL );
            [self.movieRecorder setDelegate:self callbackQueue:callbackQueue];
            
            //目前视频录制开始时间和第一个动作完成时间是一致的
            self.dRecStartTimeStamp = [[NSDate date] timeIntervalSince1970] * 1000;
            self.dORTHTimeStamp =self.dRecStartTimeStamp;
            //每次开始录制视频的时候启动超时计时
            [DSLHKIDCardSDK startOverTime];
            
#if RECORD_AUDIO
            [self.movieRecorder addAudioTrackWithSourceFormatDescription:self.outputAudioFormatDescription settings:_audioCompressionSettings];
#endif
            [self.movieRecorder prepareToRecord];
        }
        
        [self.movieRecorder appendVideoSampleBuffer:pixelBuffer];
        
    }
}
- (void)addVideo:(CMSampleBufferRef)sampleBuffer{
    @synchronized(self){
        if (!self.movieRecorder) {
            return;
        }
        [self.movieRecorder appendAudioSampleBuffer:sampleBuffer];
    }
}

#pragma mark -- Delegate protocols

#pragma mark -- AVCaptureVideoDataOutputSampleBufferDelegate
- (void)captureOutput:(AVCaptureOutput *)output didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    
    static NSInteger nRecFrameCount = 0;
    
    if(ALL_Save_Video)
    {
        [self recordingCompressionSession:sampleBuffer];
        
        if(self.bStopRecording || !self.bStartRec)
        {
            return;
        }
    }
    else
    {
        if(self.bStopRecording || !self.bStartRec)
        {
            return;
        }
        
        if(self.bRecStaticImgOk)
        {
            [self recordingCompressionSession:sampleBuffer];
            nRecFrameCount++;
            //NSLog(@"当前帧： %li", (long)nRecFrameCount);
        }
    }
    
    self.curImgData = [self imageFromSampleBuffer:sampleBuffer];
    
    dispatch_async(self.videoProcessQueue, ^{
        
        //进行数据分析
        
        static NSInteger nProcessFrame = 0;
        if (nProcessFrame > 0 || !self.bStartRec) {
            return;    //last frame not finished
        }
        nProcessFrame ++;

        //必需, 把视频帧传给SDK方法(addDetectBufferData)，供SDK分析识别;
        //注意:需要在inputDevice对象初始化时设置为【连续自动对焦】模式,如下:
        /**
         //设置自动连续对焦
         if([_inputDevice isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus])
         {
         [_inputDevice setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
         }
         */
        //NSLog(@"处理帧： %li", (long)nProcessFrame);
        [DSLHKIDCardSDK addDetectBufferData:self.curImgData Orient:1 LensPosition:self.inputDevice.lensPosition Frame:nRecFrameCount];
        nProcessFrame--;
        
    });
    
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error == nil) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"已存入手机相册" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
        
    }else{
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"保存失败" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
    }
    
}

#pragma mark --DSLMovieRecorderDelegate
- (void)movieRecorder:(DSLMovieRecorder *)recorder didFailWithError:(NSError *)error{
    NSLog(@"record error:%@", error);
}
- (void)movieRecorderDidFinishPreparing:(DSLMovieRecorder *)recorder{
    NSLog(@"record Preparing");
}
-(void)movieRecorderDidFinishRecording:(DSLMovieRecorder *)recorder{
    
    NSLog(@"Record finish");
    
    dispatch_main_safe(^{
        
            [self proccessRecordVideo];
    });

    
}

- (void)finishWriting
{
    self.bStopRecording = YES;
}

#pragma mark-- 闪光灯相关
- (void)turnTorchOn:(BOOL)on
{
    if ([self.inputDevice hasTorch]
        &&
        [self.inputDevice hasFlash]
        )
    {
        
        [self.inputDevice lockForConfiguration:nil];
        if (on)
        {
            [self.inputDevice setTorchMode:AVCaptureTorchModeOn];
            [self.inputDevice setFlashMode:AVCaptureFlashModeOn];
        }
        else
        {
            [self.inputDevice setTorchMode:AVCaptureTorchModeOff];
            [self.inputDevice setFlashMode:AVCaptureFlashModeOff];
        }
        [self.inputDevice unlockForConfiguration];
    }
    else
    {
    }
}

#pragma mark-- 翻转动画相关

/**
 根据返回的提示改变翻转动画
 @param recStatus 0:恢复正常；1:老证件上翻，新证件右翻；2:老证件下翻，新证件左翻；3:识别过程中的复位(恢复正常)
 */
- (void)setRecStatus:(DSLHKIDCardRecStatus)recStatus
{
    
    self.imgViewRecStatus.hidden = YES;
    
    switch (recStatus)
    {
        case DSLHKIDCardRecStatus_Default:
        {
            [self playOpAnimation:DSLHKIDCardPlayOpAnimation_Defualt];
            self.imgViewRecStatus.image = [UIImage imageNamed:@"rec_status_normal"];
            break;
        }
        case DSLHKIDCardRecStatus_UpOrRight:
        {
            [self playOpAnimation:self.recType == DSLHKIDCardTypeApp_2003 ? DSLHKIDCardPlayOpAnimation_Up: DSLHKIDCardPlayOpAnimation_Right];
            break;
        }
        case DSLHKIDCardRecStatus_DownOrLeft:
        {
            
            [self playOpAnimation:self.recType == DSLHKIDCardTypeApp_2003 ? DSLHKIDCardPlayOpAnimation_Down: DSLHKIDCardPlayOpAnimation_Left];
            break;
        }
        case DSLHKIDCardRecStatus_Reset:
        {
            if(self.recType == DSLHKIDCardType_2003)
            {
                [self playOpAnimation:DSLHKIDCardPlayOpAnimation_Up_Reset];
            }
            else
            {
                [self playOpAnimation:DSLHKIDCardPlayOpAnimation_Right_Reset];
            }
            
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self turnTorchOn:YES];
            }
            
            break;
        }
        default:
            
            break;
    }
}

- (void)setDefaultAnchorPointForView:(UIView *)view
{
    [self setAnchorPoint:CGPointMake(0.5f, 0.5f) forView:view];
}

- (void)setAnchorPoint:(CGPoint)anchorPoint forView:(UIView *)view
{
    CGRect oldFrame = view.frame;
    
    view.layer.anchorPoint = anchorPoint;
    
    view.frame = oldFrame;
    
}

/**
 翻转动画
 
 @param type 0:上；1：下；2：右；3：左；4：恢复默认
 */
- (void)playOpAnimation:(DSLHKIDCardPlayOpAnimation)type
{
    NSLog(@"--------------------playOpAnimation type = %li", (long)type);
    
    //暂停动画
    [self stopTimerAnimation];
    
    self.curPlayOpAnimationType = type;
    
    //复位，则不需要重新初始旋转向量
    if(type == DSLHKIDCardPlayOpAnimation_Right_Reset || type == DSLHKIDCardPlayOpAnimation_Up_Reset)
    {
        self.bIDCardRotateAngleAdd = NO;
        [self startTimerAnimation];
        return;
    }
    else
    {
        CATransform3D myTransform = CATransform3DIdentity;
        myTransform.m34 = 0;
        if(type == DSLHKIDCardPlayOpAnimation_Up || type == DSLHKIDCardPlayOpAnimation_Down)
        {
            myTransform = CATransform3DRotate(myTransform,M_PI/180, 1, 0, 0);
        }
        else
        {
            myTransform = CATransform3DRotate(myTransform,M_PI/180, 0, 1, 0);
        }
        
        self.idCardToRectImgView.layer.transform = myTransform;
        
        [self setDefaultAnchorPointForView:self.idCardToRectImgView];
        
        //非默认情况下需要开启动画
        if(type != DSLHKIDCardPlayOpAnimation_Defualt)
        {
            CGPoint point;
            switch (type)
            {
                case DSLHKIDCardPlayOpAnimation_Up:
                {
                    [self startTimerAnimation];
                    point = CGPointMake(0.5, 1.0);
                    break;
                }
                case DSLHKIDCardPlayOpAnimation_Down:
                {
                    self.curIDCardRotateAngle = 0;
                    self.bIDCardRotateAngleAdd = YES;
                    [self startTimerAnimation];
                    point = CGPointMake(0.5, 0.0);
                    break;
                }
                case DSLHKIDCardPlayOpAnimation_Right:
                {
                    [self startTimerAnimation];
                    // point = CGPointMake(0.0, 0.5);
                    point = CGPointMake(0.25, 0.5);
                    break;
                }
                case DSLHKIDCardPlayOpAnimation_Left:
                {
                    self.curIDCardRotateAngle = 0;
                    self.bIDCardRotateAngleAdd = YES;
                    
                    [self startTimerAnimation];
                    //point = CGPointMake(1.0, 0.5);
                    point = CGPointMake(0.75, 0.5);
                    break;
                }
                default:
                {
                    self.bIDCardRotateAngleAdd = YES;
                    [self stopTimerAnimation];
                    point = CGPointMake(1.0, 0.5);
                    //point = CGPointMake(0.5, 0.5);
                    break;
                }
            }
            [self setAnchorPoint:point forView:self.idCardToRectImgView];
        }
    }
}

- (void)updateIDCardRotate:(DSLHKIDCardPlayOpAnimation)type
{
    CGFloat angle;
    switch (type)
    {
        case DSLHKIDCardPlayOpAnimation_Up:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Down:
        {
            angle = -M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Right:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Left:
        {
            angle = -M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Right_Reset:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        case DSLHKIDCardPlayOpAnimation_Up_Reset:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
        default:
        {
            angle = M_PI / 180 *self.curIDCardRotateAngle;
            break;
        }
            
    }
    
    CATransform3D myTransform = CATransform3DIdentity;
    myTransform.m34 = -0.01;
    
    //沿（0，1，0）这个向量旋转
    if(type == DSLHKIDCardPlayOpAnimation_Up || type == DSLHKIDCardPlayOpAnimation_Up_Reset || type == DSLHKIDCardPlayOpAnimation_Down)
    {
        myTransform = CATransform3DRotate(myTransform,angle, 1, 0, 0);
    }
    else
    {
        myTransform = CATransform3DRotate(myTransform,angle, 0, 1, 0);
    }
    
    self.idCardToRectImgView.layer.transform = myTransform;
}

- (void)initPlayAnimationTimer
{
    if(self.timerPlayAnimation != nil)
    {
        return;
    }
    self.timerPlayAnimation = [NSTimer timerWithTimeInterval:0.02 target:self selector:@selector(timeredAnimation:) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timerPlayAnimation forMode:NSDefaultRunLoopMode];
    [self stopTimerAnimation];
}

- (void)timeredAnimation:(NSTimer* )timer
{
    if(self.bIDCardRotateAngleAdd)
    {
        self.curIDCardRotateAngle += 0.04;
        if(self.curIDCardRotateAngle >= Max_Rotate_Angle)
        {
            self.bIDCardRotateAngleAdd = NO;
            //动画只需要播放一次
            [self stopTimerAnimation];
        }
    }
    else if (!self.bIDCardRotateAngleAdd)
    {
        self.curIDCardRotateAngle -= 0.04;
        if(self.curIDCardRotateAngle < 0)
        {
            self.curIDCardRotateAngle = 0;
            self.bIDCardRotateAngleAdd = YES;
            if(self.curPlayOpAnimationType == DSLHKIDCardPlayOpAnimation_Right_Reset
               ||
               self.curPlayOpAnimationType  == DSLHKIDCardPlayOpAnimation_Up_Reset
               )
            {
                //复位动画已经播放一遍回到正面则停止
                [self stopTimerAnimation];
            }
        }
    }

    [self updateIDCardRotate:self.curPlayOpAnimationType];
}

- (void)initPlayOpAnimation
{
    
    [self stopTimerAnimation];
    self.curIDCardRotateAngle = 0.0;
    self.bIDCardRotateAngleAdd = YES;
    
}
- (void)startTimerAnimation
{
    [self stopTimerAnimation];
    
    [self.timerPlayAnimation setFireDate:[NSDate distantPast]];
}

- (void)stopTimerAnimation
{
    [self.timerPlayAnimation setFireDate:[NSDate distantFuture]];
}

@end
