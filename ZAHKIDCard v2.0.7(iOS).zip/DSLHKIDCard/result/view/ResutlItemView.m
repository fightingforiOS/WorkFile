//
//  ResutlItemView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/22.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "ResutlItemView.h"
#import "UIColor+DSLCHexColor.h"

#define showTimeGap 1
@interface ResutlItemView()

@property(nonatomic, strong) UIImageView* imgViewHead;  //左图
@property(nonatomic, strong) UILabel* labelContent; //内容
@property(nonatomic, strong) NSString* imgName;
@property(nonatomic, strong) NSString* content;
@property(nonatomic, assign) BOOL bNormalStatus;
@property(nonatomic, assign) BOOL bAllowClick;
@end

@implementation ResutlItemView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    return self;
}

- (void)setupView
{
    
    [self addSubview:self.imgViewHead];
    [self addSubview:self.labelContent];
    
    UITapGestureRecognizer *recognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    recognizer.numberOfTapsRequired = 1;
    recognizer.numberOfTouchesRequired = 1;
    [self addGestureRecognizer:recognizer];
}

- (UIImageView* )imgViewHead
{
    if(_imgViewHead == nil)
    {
        float viewH = self.bounds.size.height;
        
        _imgViewHead = [[UIImageView alloc] init];
        _imgViewHead.frame = CGRectMake(20.0, (viewH-14)/2, 14, 14);
    }
    
    return _imgViewHead;
}

- (UILabel* )labelContent
{
    if(_labelContent == nil)
    {
        float viewH = self.bounds.size.height;
        float viewW = self.bounds.size.width;
        _labelContent = [[UILabel alloc] init];
        _labelContent.textColor = [UIColor blackColor];
        _labelContent.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        _labelContent.textAlignment = NSTextAlignmentLeft;
        _labelContent.text = @"鐳射花標: 未識別成功";
        _labelContent.frame = CGRectMake(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20, (viewH-20)/2, viewW-(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20), 20);
    }
    return  _labelContent;
}

- (void)handleTap:(UITapGestureRecognizer *)recognizer
{
    
    if(self.bNormalStatus && self.bAllowClick)
    {
        [self resetStatus:@"NO"];
        [self performSelector:@selector(resetStatus:) withObject:@"YES" afterDelay:showTimeGap];
        
        if(self.myDelegate)
        {
            if([self.myDelegate respondsToSelector:@selector(clickResultItem:Tag:)])
            {
                [self.myDelegate clickResultItem:self Tag:(int)self.tag];
            }
        }
    }
}

- (void)setResutlItem:(NSString* ) imgName Content:(NSString* )content AllowClick:(BOOL)allowClick ContentLines:(int)lines
{
    self.imgName = imgName;
    self.content = content;
    self.bAllowClick = allowClick;
    
    self.labelContent.numberOfLines = lines;
    
    if(lines == 2)
    {
        float viewH = self.bounds.size.height;
        float viewW = self.bounds.size.width;
        self.labelContent.frame = CGRectMake(self.imgViewHead.frame.origin.x+self.imgViewHead.frame.size.width+20, (viewH-20)/2, viewW-(self.imgViewHead.frame.origin.x+self.imgViewHead.frame.size.width+20), 50);
    }
    
    self.imgViewHead.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@", imgName]];
    self.labelContent.text = content;
    
    if(allowClick)
    {
        [self resetStatus:@"NO"];
        [self performSelector:@selector(resetStatus:) withObject:@"YES" afterDelay:showTimeGap];
    }
}

- (void)resetStatus:(NSString*) isNormal
{
   self.bNormalStatus = [isNormal boolValue];
    
    float viewH = self.bounds.size.height;
    float viewW = self.bounds.size.width;
    
    if(self.bNormalStatus)
    {
        self.imgViewHead.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@", self.imgName]];
        self.imgViewHead.frame = CGRectMake(20.0, (viewH-14)/2, 14, 14);
        
        self.labelContent.textColor = [UIColor blackColor];
        self.labelContent.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        
        self.labelContent.frame = CGRectMake(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20, (viewH-20)/2, viewW-(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20), 20);
    }
    else
    {
        self.imgViewHead.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@", self.imgName]];
        self.imgViewHead.frame = CGRectMake(20.0, (viewH-14)/2, 14, 14);
        
        self.labelContent.textColor = [UIColor dslc_colorWithHexString:@"0x02A6CA"];
        self.labelContent.font = [UIFont fontWithName:@"PingFangSC-Regular" size:18];
        
        self.labelContent.frame = CGRectMake(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20, (viewH-30)/2, viewW-(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20), 30);
    }
}

@end
