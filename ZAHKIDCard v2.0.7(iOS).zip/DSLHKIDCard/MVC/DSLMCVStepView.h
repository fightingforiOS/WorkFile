//
//  DSLMCVStepView.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2021/4/22.
//  Copyright © 2021 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DSLMCVStepView : UIView

- (instancetype)initWithFrame:(CGRect)frame Step:(int)step;

- (void)initData:(int)step;

- (void)updateData:(int)step;
- (void)stepFinished:(UIImage* )img;

@end

NS_ASSUME_NONNULL_END
