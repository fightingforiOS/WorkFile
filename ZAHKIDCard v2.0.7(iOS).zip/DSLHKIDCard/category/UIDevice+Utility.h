//
//  UIDevice+Utility.h
//  XLMovieKit
//
//  Created by liuhu on 2017/6/23.
//  Copyright © 2017年 xunlei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface UIDevice(Utility)

- (NSString *)ir_deviceModel;

- (BOOL)highPerformanceDevice ;
@end
