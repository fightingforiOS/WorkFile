//
//  DSLHKIDCardInDeskViewController.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/4/15.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "DSLHKIDCardInDeskViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <DSLHKIDCard/DSLHKIDCard.h>
#import <ZAFaceSDK/ZAFaceSDK.h>

#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/PHImageManager.h>
#import <Photos/PHPhotoLibrary.h>
#import <Photos/PHAssetChangeRequest.h>
#import <Photos/PHAsset.h>
#import <Photos/PHAssetResource.h>

#import <CoreMotion/CoreMotion.h>

#import <CoreImage/CoreImage.h>

#import "UIColor+DSLCHexColor.h"
#import "HandIDCardTipView.h"
#import "DSLMovieRecorder.h"
#import "ResultFailView.h"
#import "UIView+Toast.h"
#import "UIDevice+Utility.h"

#import "DSLHKIDCardResultController.h"
#import "DSLHKIDCardResultFailViewController.h"
#import "LoadingRecView.h"

#import "IRNetworkEngine.h"
#import "ResultInfoModel.h"
#import "NextOperationView.h"
#import "DSLHKIDCardConfig.h"
#import "DSLHKIDCardBundle.h"
#import "SelectTypeForSaveLocal.h"
#import "DSLRecStepFinishView.h"
#import "DSLPlayAudio.h"
#import "DSLIDCardInDeskOpStatusView.h"
#import "DSLHKBaseIDCardViewController+Statistics.h"

@interface DSLHKIDCardInDeskViewController ()  <DSLHKIDCardDetectObserverDelegate,HandIDCardTipViewDelegate, ResultFailViewDelegate, DSLHKIDCardResultFailVcDelegate, SelectTypeForSaveLocalDelegate>

@property(nonatomic,strong)UIButton *backButton;
    
@property(nonatomic,strong)NextOperationView *nextOperationView;

//识别过程中，每个阶段识别成功提示
@property(nonatomic,strong)DSLRecStepFinishView *recStepFinishView;

//在识别过程中出现的操作错误提示
@property(nonatomic,strong)UILabel *labelOpErrorTip;

//当前识别到哪一步显示
@property(nonatomic,strong)UIImageView *imgViewCurRecStep;

//视频录制结束等待进入人脸识别
@property(nonatomic, strong) UIImageView* imgViewRecIDCardOkTip;

//在识别过程中遇到的失败提示(比如，超时，旋转速度过快等)
@property(nonatomic, strong) ResultFailView* resultFailView;


@property(nonatomic, copy) NSString* ocrResultId;

//识别Session ID,方便后台定位
@property(nonatomic, copy) NSString* contextId;

@property(nonatomic, strong) HandIDCardTipView* handIDCardTipView;

@property(nonatomic, strong) DSLHKIDCardResult* curIDCardResult;

@property(nonatomic, strong) UIImage* curImgFaceData;

//保存验真结果和OCR结果数据
@property(nonatomic, strong) ResultInfoModel* resultInfoModel;

@property(nonatomic, strong) LoadingRecView* loadingRecView;

//上传人脸识别图片成功
@property(nonatomic, assign) BOOL bUploadFaceRecognitionSuccess;

//上传视频成功
@property(nonatomic, assign) BOOL bUploadVideoDataSuccess;

//当前流程操作动作提示语
@property(nonatomic, strong) NSString* strCurOpTip;

//图片保存到相册的文件名
@property(nonatomic, strong) NSString* imgSaveAlbumFileName;

@property(nonatomic, strong) NSMutableArray* muArrSaveRequestDatas;

//加速度计
@property(nonatomic, strong) CMMotionManager*motionManager;

//证件在桌面上摆放的顶部朝向
@property(nonatomic, assign) DSLHKIDCardOperationStatus idCardInDeskDirection;

//证件在放在桌面上操作动作指引
@property(nonatomic, strong) DSLIDCardInDeskOpStatusView* idCardInDeskOpStatusView;

@property(nonatomic, assign) BOOL bIDCardPostionInDeskError;  //证件放置错误

@end

@implementation DSLHKIDCardInDeskViewController


/**
 初始化SDK
 */
- (void)initHKIDCardSDK:(BOOL)useLiteVersion
{
    //必需, 设置证件类型2018版或者2003版
    [DSLHKIDCardSDK setIDCardType:self.recType == DSLHKIDCardTypeApp_2018 UseLietVersion:useLiteVersion Occlusion_check:YES Exposure_t:0.2 Dark_t:0.9 Stop_t1_03:0.9 Stop_t2_03:0.95 Stop_t1_2018:0.9 Stop_t2_2018:0.95 Lost_cnt:3];
    //必需, 注册回调对象
    [DSLHKIDCardSDK registerObserver:self];
    
    //可选, 设置识别超时时间
    [DSLHKIDCardSDK setOverTimes:Rec_Over_Time];
    [DSLHKIDCardSDK setAppId:@"zhongan_demo"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self configBackButton];

    //SDK初始化
    [self initHKIDCardSDK:self.useLiteVersion];
    
    [self.view addSubview:self.imgViewCurRecStep];
    [self.view addSubview:self.nextOperationView];
    self.nextOperationView.hidden = YES;
    
    [self.view addSubview:self.resultFailView];
    self.resultFailView.hidden = YES;
    
    [self.view addSubview:self.loadingRecView];
    
    [self.view addSubview:self.imgViewRecIDCardOkTip];
    
    [self.view addSubview:self.labelOpErrorTip];
    
    [self.view addSubview:self.recStepFinishView];
    
    if(SHOW_HAND_IDCARD_TIP_VIEW)
    {
        [self.view addSubview:self.handIDCardTipView];
    }
    else
    {
        //开始启动识别
        [self startRecognize];
    }
    
    [self.view addSubview:self.idCardInDeskOpStatusView];
    
    [self initNotification];
}

- (void)initNotification
{
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
      [notificationCenter addObserver:self
                               selector:@selector(applicationWillEnterForeground:)
                                   name:UIApplicationWillEnterForegroundNotification
                                 object:nil];
    
    [notificationCenter addObserver:self
                             selector:@selector(applicationDidBecomeActive:)
                                 name:UIApplicationDidBecomeActiveNotification
                               object:nil];
      [notificationCenter addObserver:self
                               selector:@selector(applicationDidEnterBackground:)
                                   name:UIApplicationDidEnterBackgroundNotification
                                 object:nil];
}

- (void)applicationDidBecomeActive:(NSNotification *)notification
{
    if(self.bAppRelaunched)
    {
        self.bAppRelaunched = NO;
        [self startMotionManager];
        //SDK初始化
        [self initHKIDCardSDK:self.useLiteVersion];
         [self startRecognize];
    }
}

- (void)applicationWillEnterForeground:(NSNotification *)notification
{
    NSLog(@"applicationWillEnterForeground....");
    self.bAppRelaunched = YES;
}

- (void)applicationDidEnterBackground:(NSNotification *)notification
{
    NSLog(@"applicationDidEnterBackground....");

    [self.motionManager stopAccelerometerUpdates];
    self.idCardInDeskOpStatusView.hidden = YES;
    
    self.recStepFinishView.hidden = YES;
    [self hideOpErrorTip];
    //取消所有延时处理任务
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    //必需, 注销回调设置的对象
    [DSLHKIDCardSDK unregisterObserver:self];
    [self clearData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [UIApplication sharedApplication].idleTimerDisabled = YES;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    NSLog(@"%@ viewWillDisappear!",NSStringFromClass([self class]));
    
    [UIApplication sharedApplication].idleTimerDisabled = NO;
    
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter removeObserver:self];
    
    //必需, 注销回调设置的对象
    [DSLHKIDCardSDK unregisterObserver:self];
    
    [self clearData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    NSLog(@"%@ dealloc!",NSStringFromClass([self class]));
    
    self.resultFailView.myDelegate = nil;
    self.handIDCardTipView.myDelegate = nil;
}
    
#pragma mark -- 退出识别按钮
-(void)configBackButton{
    _backButton = [[UIButton alloc] initWithFrame:CGRectMake(self.view.bounds.size.width-70, 40, 50, 50)];
    
    UIImage* image =  [UIImage imageNamed:@"closeVideo"];
    
    [_backButton setImage:image forState:UIControlStateNormal];
    [_backButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.view addSubview:_backButton];
    [_backButton addTarget:self action:@selector(doPopBack:) forControlEvents:UIControlEventTouchUpInside];
    
    double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
    [self recordFail:5 DurationTime:d SessionID:[self getUUID]];
}
    
-(void)doPopBack:(id)sender{

    self.bExited = YES;
    
    [self clearData];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)clearData
{
    [self.motionManager stopAccelerometerUpdates];
    
    if ([self.captureSession isRunning])
    {
        [self.captureSession stopRunning];
    }
    //识别停止
    self.bStartRec = NO;
    //停止录制视频
    if(!ALL_Save_Video)
    {
        [self stopMovieRecorder];
    }
    
    //必需, 当页面消失的时候，需要调用destroyOCR把SDK内部的资源销毁
    [DSLHKIDCardSDK destroyOCR];
}

- (void)resetInitUseLiteVersion
{
    [DSLHKIDCardSDK destroyOCR];
    
    [self initHKIDCardSDK:YES];

}

- (void)startRecognize
{
    [self resetVideoUI];
    
    if(!ALL_Save_Video)
    {
        [self stopMovieRecorder];
    }
    
    self.dRecOpStartTimeStamp = [[NSDate date] timeIntervalSince1970] * 1000;
    [self initStatisticsData];
    
    [self resetUUID];
    
    self.bStartRec = YES;
    self.bStopRecording = NO;
    
    self.nextOperationView.hidden = NO;
    self.curIDCardResult = nil;
    self.resultInfoModel = nil;
    self.bUploadVideoDataSuccess = NO;
    self.bUploadFaceRecognitionSuccess = NO;
    self.bRecStaticImgOk = NO;
    
    self.bIDCardPostionInDeskError = NO;
    
    self.imgViewRecStatus.hidden = YES;
    
    self.imgSaveAlbumFileName = @"";
    self.videoSaveAlbumFileName = @"";
    
    [self.captureSession startRunning];
    [DSLHKIDCardSDK startDetect];
}

-(ResultInfoModel* )resultInfoModel
{
    if(_resultInfoModel == nil)
    {
        _resultInfoModel = [[ResultInfoModel alloc] init];
    }
    
    return _resultInfoModel;
}


#pragma mark -- UI相关
- (LoadingRecView* )loadingRecView
{
    if(_loadingRecView == nil)
    {
        _loadingRecView = [[LoadingRecView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-190)/2, 304, 190)];
        _loadingRecView.hidden = YES;
    }
    
    return _loadingRecView;
}

- (HandIDCardTipView* )handIDCardTipView
{
    if(_handIDCardTipView == nil)
    {
        _handIDCardTipView = [[HandIDCardTipView alloc] initWithFrame:CGRectMake(0.0, 0.0, self.view.bounds.size.width, self.view.bounds.size.height) IDCardType:(self.recType == DSLHKIDCardTypeApp_2018 ? NO : YES)];
        _handIDCardTipView.myDelegate = self;
        
    }
    return _handIDCardTipView;
}

- (UIImageView* )imgViewRecIDCardOkTip
{
    if(_imgViewRecIDCardOkTip == nil)
    {
        _imgViewRecIDCardOkTip = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-190)/2, 304, 190)];
        NSString* imgName = @"rec_IDCardOkTip";
        if([self isCurrentLanguageEn])
        {
            imgName = @"rec_IDCardOkTip_english";
        }
        _imgViewRecIDCardOkTip.image = [UIImage imageNamed:imgName];
        _imgViewRecIDCardOkTip.hidden = YES;
    }
    return _imgViewRecIDCardOkTip;
}

- (ResultFailView* )resultFailView
{
    if(_resultFailView == nil)
    {
        _resultFailView = [[ResultFailView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-265)/2, 304, 265)];
        _resultFailView.myDelegate = self;
    }
    return _resultFailView;
}

- (UIImageView* )imgViewCurRecStep
{
    if(_imgViewCurRecStep == nil)
    {
        _imgViewCurRecStep = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-244)/2, self.nextOperationView.frame.origin.y-60.0, 244, 22.0)];
        _imgViewCurRecStep.image = [UIImage imageNamed:@"rec_step1_bk"];
    }
    return _imgViewCurRecStep;
}

- (UIView* )nextOperationView
{
    if(_nextOperationView == nil)
    {
        _nextOperationView = [[NextOperationView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-260)/2, self.idCardToRect.origin.y-42.0-23, 260, 42.0)];
    }
    return _nextOperationView;
}

- (DSLRecStepFinishView* )recStepFinishView
{
    if(_recStepFinishView == nil)
    {
        _recStepFinishView = [[DSLRecStepFinishView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-116.0)/2, self.idCardToRect.origin.y+50.0, 116.0, 116.0)];
        _recStepFinishView.hidden = YES;
    }
    
    return _recStepFinishView;
}

- (UILabel* )labelOpErrorTip
{
    if (_labelOpErrorTip == nil) {
        _labelOpErrorTip = [[UILabel alloc] init];
        _labelOpErrorTip.frame = CGRectMake((self.view.bounds.size.width-180.0)/2, self.idCardToRect.origin.y+90.0, 180.0, 42.0);
        _labelOpErrorTip.textAlignment = NSTextAlignmentCenter;
        _labelOpErrorTip.textColor = [UIColor whiteColor];
        _labelOpErrorTip.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelOpErrorTip.text = @"证件超出识别框外";
        _labelOpErrorTip.backgroundColor = [UIColor dslc_colorWithHexString:@"0xF60000"];
        _labelOpErrorTip.alpha = 0.5;
        _labelOpErrorTip.layer.masksToBounds = YES;
        _labelOpErrorTip.layer.cornerRadius = 4.0;
        _labelOpErrorTip.hidden = YES;
    }
    return _labelOpErrorTip;
}

-(DSLIDCardInDeskOpStatusView* )idCardInDeskOpStatusView
{
    if(_idCardInDeskOpStatusView == nil)
    {
        _idCardInDeskOpStatusView = [[DSLIDCardInDeskOpStatusView alloc] initWithFrame:CGRectMake(30.0, self.idCardToRect.origin.y+self.idCardToRect.size.height+10.0, self.view.frame.size.width-60, 30.0)];
        _idCardInDeskOpStatusView.hidden = YES;
    }
    
    return _idCardInDeskOpStatusView;
}
- (void)setCurRecStep:(DSLHKIDCardOperationStatus) opStatus
{
    NSString* strImgName = @"rec_step1_bk";
    switch (opStatus) {
        case DSLHKIDCardOperation_BEGIN:
            break;
        case DSLHKIDCardOperation_ORTH:
            strImgName = @"rec_step2_bk";
            break;
        case DSLHKIDCardOperation_RESET:
            strImgName = @"rec_step3_bk";
            break;
        case DSLHKIDCardOperation_LEFTDOWN:
            strImgName = @"rec_step4_bk";
            break;
        case DSLHKIDCardOperation_COMPLETE:
            strImgName = @"rec_step5_bk";
            break;
        default:
            break;
    }
    
    self.imgViewCurRecStep.image = [UIImage imageNamed:strImgName];
}

- (void)setOpErrorTip:(NSString* )errorTip
{
    //如果识别阶段成功标志显示，则不显示操作错误提示
    if([self.recStepFinishView isHidden])
    {
        if(![self.labelOpErrorTip.text isEqualToString:errorTip] || [self.labelOpErrorTip.text isEqualToString:@""] || self.labelOpErrorTip.text == nil)
        {
            self.labelOpErrorTip.hidden = NO;
            self.labelOpErrorTip.text = errorTip;
        }
    }
    else
    {
        self.labelOpErrorTip.hidden = YES;
        self.labelOpErrorTip.text = @"";
    }
    
}
- (void)hideOpErrorTip
{
    self.labelOpErrorTip.hidden = YES;
    self.labelOpErrorTip.text = @"";
}

- (void)setShowRecStepFinish:(NSString* )stepFinishTip
{
    [[DSLPlayAudio sharedAudioPlayer] playWithFileName:@"op_success" continueNext:NO];
    self.labelOpErrorTip.hidden = YES;
    self.labelOpErrorTip.text = @"";
    [self.recStepFinishView setRecStepFinishTip:stepFinishTip];
    self.recStepFinishView.hidden = NO;
}

- (void)updateOpTip:(DSLHKIDCardNextOperation *)command
{
    switch (command.currentStatus) {
        case DSLHKIDCardOperation_BEGIN:
        {
            [self setCurRecStep:command.currentStatus];
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title1"] IDCardType:self.recType];
            break;
        }

        case DSLHKIDCardOperation_ORTH:
        {
            [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title17"]];
            [self setCurRecStep:command.currentStatus];
            if(self.recType == DSLHKIDCardTypeApp_2018)   //新证件
            {
                [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title1"] IDCardType:self.recType];
            }
            else
            {
                NSString* strTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title1"];
                
                if(self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_LEFT)
                {
                    strTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title2"];
                }
                
                [self.nextOperationView setNextOpStatus:command.currentStatus Text:strTip IDCardType:self.recType];
            }

            break;
        }
        case DSLHKIDCardOperation_RESET:
        {
            [self setCurRecStep:command.currentStatus];
            
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title3"] IDCardType:self.recType];
            break;
        }
        case DSLHKIDCardOperation_LEFTDOWN:
        {
            //[self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title12"]];
            [self setCurRecStep:command.currentStatus];
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title2"] IDCardType:self.recType];
            }
            else
            {
                 NSString* strTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title2"];
                 
                 if(self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_LEFT)
                 {
                     strTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title1"];
                 }
                 
                 [self.nextOperationView setNextOpStatus:command.currentStatus Text:strTip IDCardType:self.recType];
            }
           
            break;
        }
        case DSLHKIDCardOperation_STOP1:
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title4"]];
            }
            else
            {
                NSString* strTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title4"];
                               
                if(self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_LEFT)
                {
                    strTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_in_desk_operation_title5"];
                }
                
                [self setShowRecStepFinish:strTip];
            }
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title22"] IDCardType:self.recType];
            break;
        }
        case DSLHKIDCardOperation_STOP2:
        {
            [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title12"]];
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title22"] IDCardType:self.recType];
            break;
        }
        case DSLHKIDCardOperation_STOP3:
        {
            [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title7"]];
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title22"] IDCardType:self.recType];
            break;
        }
         case DSLHKIDCardOperation_COMPLETE:
        {
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title7"] IDCardType:self.recType];
            [self setCurRecStep:command.currentStatus];
            [[DSLPlayAudio sharedAudioPlayer] playWithFileName:@"op_success" continueNext:NO];
            self.labelOpErrorTip.hidden = YES;
            self.labelOpErrorTip.text = @"";
            break;
        }
        case DSLHKIDCardOperation_FAR:
        {
            self.iFarCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title13"]];
            break;
        }
        case DSLHKIDCardOperation_NEAR:
        {
            self.iNearCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title14"]];
            break;
        }
        case DSLHKIDCardOperation_BLUR:
        {
            self.iBlurCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title15"]];
            break;
        }
        case DSLHKIDCardOperation_OUT_OF_RANGE:
        {
            self.iOutOfRangeCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title19"]];
            break;
        }
        case DSLHKIDCardOperation_NO_PARALLEL_TO_MOBILEPHONE:
        {
            self.iNoParallelToMobilePhoneCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title20"]];
            break;
        }
        case DSLHKIDCardOperation_DIRECTION_TILT:
        {
            self.iTiltCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title21"]];
            break;
        }
            
        case DSLHKIDCardOperation_INVALID:
        {
            self.iInvalidCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title16"]];
            break;
        }
        case DSLHKIDCardOperation_VALID:
        {
            [self hideOpErrorTip];
            break;
        }
        default:
            break;
    }
   
}

#pragma mark-- faceSDK
- (void)start
{
    ZAFaceManager *faceSdk = [ZAFaceManager sharedInstance];
    faceSdk.times = 3;
    faceSdk.duration = 10;
    faceSdk.randomAction = YES;
    faceSdk.tipsText = @"开始人脸识别";
    __weak __typeof(self)weakSelf = self;
    
    
    [faceSdk startDetectInViewController:self successHandle:^(NSString *imageData, NSDictionary *otherImgs) {
            
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        
        NSData *faceData = [[NSData alloc]initWithBase64EncodedString:imageData options:NSDataBase64DecodingIgnoreUnknownCharacters];
        UIImage *img = [[UIImage alloc]initWithData:faceData];
        strongSelf.curImgFaceData = img;
        [strongSelf updateEffectiveRect:NO];
        
        [strongSelf uploadFaceRecognition:strongSelf.curIDCardResult.imageDataArray.lastObject ImgFace:faceData];
        
        }
    errorHandler:^(ZAFaceDetectErrorResult errorType) {
            
        }];
    
//    [faceSdk startDetectInViewController:self successHandle:^(NSString *imageData) {
//        
//        __strong __typeof(weakSelf) strongSelf = weakSelf;
//        
//        NSData *faceData = [[NSData alloc]initWithBase64EncodedString:imageData options:NSDataBase64DecodingIgnoreUnknownCharacters];
//        UIImage *img = [[UIImage alloc]initWithData:faceData];
//        strongSelf.curImgFaceData = img;
//        [strongSelf updateEffectiveRect:NO];
//        
//        [strongSelf uploadFaceRecognition:strongSelf.curIDCardResult.imageDataArray.lastObject ImgFace:faceData];
//        
//    } errorHandler:^(ZAFaceDetectErrorResult errorType) {
//        // __strong __typeof(weakSelf)strongSelf = weakSelf;
//        //[strongSelf.view makeToast:@"活检失败" duration:2.0 position:CSToastPositionCenter];
//        
//    }];
}

#pragma mark -- Delegate protocols

#pragma mark -- DSLHKIDCardDetectObserverDelegate
-(void)didUpdateOperationCommand:(DSLHKIDCardNextOperation *)command {
    
    NSLog(@"operation command = %@, 操作: %@",@(command.currentStatus), command.nextOperationHint);
    dispatch_main_safe(^{
        
        
        if(self.bIDCardPostionInDeskError)
        {
            //证件位置放置错误，不处理
            return ;
        }
        
        [self updateOpTip:command];
        
        if(command.currentStatus == DSLHKIDCardOperation_BEGIN)
        {
            //证件背景框设置为未识别状态
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                self.idCardToRectImgView.image = [UIImage imageNamed:@"in_desk_rec_new_card_un_bk"];
            }
            else
            {
                self.idCardToRectImgView.image = [UIImage imageNamed:@"in_desk_rec_old_card_un_bk"];
            }
            
            [self setRecStatus:DSLHKIDCardRecStatus_Default];
            
        }
        else if(command.currentStatus == DSLHKIDCardOperation_ORTH)
        {
            [self.idCardInDeskOpStatusView initData];
            self.idCardInDeskOpStatusView.hidden = NO;
            [self.idCardInDeskOpStatusView setIDCardOperationStatus:DSLHKIDCardOperation_ORTH];
            [self startMotionManager];
            
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {

                self.idCardToRectImgView.image = [UIImage imageNamed:@"idcard_in_desk_new_card_left_bk"];
            }
            else
            {
                if(self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_RIGHT)
                {
                    self.idCardToRectImgView.image = [UIImage imageNamed:@"idcard_in_desk_old_card_left_bk"];
                }
                else  if(self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_LEFT)
                {
                    self.idCardToRectImgView.image = [UIImage imageNamed:@"idcard_in_desk_old_card_right_bk"];
                }

            }
            
            [self setRecStatus:DSLHKIDCardRecStatus_UpOrRight];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_ORTH_HALF)
        {
        }
        else if(command.currentStatus == DSLHKIDCardOperation_LEFTDOWN)
        {
            [self.idCardInDeskOpStatusView setIDCardOperationStatus:DSLHKIDCardOperation_LEFTDOWN];
            
            [self setRecStatus:DSLHKIDCardRecStatus_DownOrLeft];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_LEFTDOWN_HALF)
        {
        }
        else if(command.currentStatus == DSLHKIDCardOperation_RESET)
        {
            [self.idCardInDeskOpStatusView setIDCardOperationStatus:DSLHKIDCardOperation_RESET];
            
            if(self.recType == DSLHKIDCardTypeApp_2018)
           {

               self.idCardToRectImgView.image = [UIImage imageNamed:@"idcard_in_desk_new_card_right_bk"];
           }
           else
           {
               if(self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_RIGHT)
               {
                   self.idCardToRectImgView.image = [UIImage imageNamed:@"idcard_in_desk_old_card_right_bk"];
               }
               else  if(self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_LEFT)
               {
                   self.idCardToRectImgView.image = [UIImage imageNamed:@"idcard_in_desk_old_card_left_bk"];
               }
           }
            
            //在收到reset状态时打开闪光灯
            if(self.dRecStartExposureTimeStamp < 0.01)
            {
                self.dRecStartExposureTimeStamp = [[NSDate date] timeIntervalSince1970] * 1000;
            }
            
            [self setRecStatus:DSLHKIDCardRecStatus_Reset];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_COMPLETE)
        {
            [self.idCardInDeskOpStatusView setIDCardOperationStatus:DSLHKIDCardOperation_COMPLETE];
            [self setRecStatus:DSLHKIDCardRecStatus_Default];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_DIRECTION_LEFT
                ||
                command.currentStatus == DSLHKIDCardOperation_DIRECTION_RIGHT
                ||
                command.currentStatus == DSLHKIDCardOperation_DIRECTION_BOTTOM
                ||
                command.currentStatus == DSLHKIDCardOperation_DIRECTION_UP
                )
        {
            self.idCardInDeskDirection = command.currentStatus;
            if(command.currentStatus == DSLHKIDCardOperation_DIRECTION_UP)
            {
                [self.idCardInDeskOpStatusView setBarOriginalDirctionLeft:YES IDCardType2018:self.recType == DSLHKIDCardTypeApp_2018];
            }
            else if(command.currentStatus == DSLHKIDCardOperation_DIRECTION_RIGHT)
            {
                [self.idCardInDeskOpStatusView setBarOriginalDirctionLeft:YES IDCardType2018:self.recType == DSLHKIDCardTypeApp_2018];
            }
            else if(command.currentStatus == DSLHKIDCardOperation_DIRECTION_LEFT)
            {
                [self.idCardInDeskOpStatusView setBarOriginalDirctionLeft:NO IDCardType2018:self.recType == DSLHKIDCardTypeApp_2018];
            }
            
        }

    });
}

-(void)didDetectResult:(DSLHKIDCardResult *)result
{
    
    NSLog(@"didDetectResult, retCode=%li idcardType = %li", (long)result.idCardResultStatus, (long)result.idCardType);
    
    
    dispatch_main_safe((^{
        
        if(result.idCardResultStatus == DSLHKIDCardResultStatus_FirstActionOver)
        {
            self.recType = result.idCardType == DSLHKIDCardType_2003 ? DSLHKIDCardTypeApp_2003 : DSLHKIDCardTypeApp_2018;
            
            if((self.recType == DSLHKIDCardType_2003 && self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_UP)
               ||
               (self.recType == DSLHKIDCardType_2003 && self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_BOTTOM)
               ||
               (self.recType == DSLHKIDCardType_2018 && self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_BOTTOM)
               ||
               (self.recType == DSLHKIDCardType_2018 && self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_LEFT)
               ||
               (self.recType == DSLHKIDCardType_2018 && self.idCardInDeskDirection == DSLHKIDCardOperation_DIRECTION_RIGHT)
               )
           {
               self.bStopRecording = YES;
               
               self.bIDCardPostionInDeskError = YES;
               
               if(!ALL_Save_Video)
               {
                   if ([self.captureSession isRunning])
                   {
                       [self.captureSession stopRunning];
                   }
               }
               
               //错误的放置方向
               [self recFail];
               
               if(self.recType == DSLHKIDCardType_2003)
               {
                   self.bStartRec = NO;
                   [self showRecFailResult:DSLHKIDCardRecFailType_IDCard2003_Postion];
               }
               else
               {
                   self.bStartRec = NO;
                   [self showRecFailResult:DSLHKIDCardRecFailType_IDCard2018_Postion];
               }
               
               if(!ALL_Save_Video)
               {
                  [self finishVideoWriter];
               }
               return ;
           }
            
            self.bRecStaticImgOk = YES;
            
            //已经识别到证件正面，设置拍摄有效区域证件背景框为识别状态
            //获取第一个动作的静态图片
            //可以在这向服务器请求静态图片信息
//            if(!Is_Local_Save)
//            {
//                [self uploadStaticImg:[result.imageDataArray firstObject]];
//            }
        }
        else
        {
            self.bStopRecording = YES;
            
            if(!ALL_Save_Video)
            {
                if ([self.captureSession isRunning])
                {
                    [self.captureSession stopRunning];
                }
            }

            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self turnTorchOn:NO];
            }
            
            if (result.idCardResultStatus != DSLHKIDCardResultStatus_Success)
            {
                
                [self recFail];
                [self proccessRecFail:result];
 
                //识别失败次数统计
               self.iFailCount++;
               int ifailReason = -1;
               switch (result.idCardResultStatus)
               {
                   case DSLHKIDCardResultStatus_Exposure:
                       ifailReason = 0;
                       break;
                   case DSLHKIDCardResultStatus_Lost:
                       ifailReason = 1;
                       break;
                   case DSLHKIDCardResultStatus_Overtime:
                       ifailReason = 2;
                       break;
                   case DSLHKIDCardResultStatus_Dark:
                       ifailReason = 4;
                       break;
                   default:
                       break;
               }
               
               double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
               [self recordFail:ifailReason DurationTime:d SessionID:[self getUUID]];
                
                if(!self.useLiteVersion)
                {
                    self.useLiteVersion = YES;
                    [self resetInitUseLiteVersion];
                }
            }
            else
            {
                [self.motionManager stopAccelerometerUpdates];
                self.idCardInDeskOpStatusView.hidden = YES;
                
                //识别成功关闭视频流
                if(ALL_Save_Video)
                {
                    if ([self.captureSession isRunning])
                    {
                        [self.captureSession stopRunning];
                    }
                }
                
                self.dRecEndTimeStamp = [[NSDate date] timeIntervalSince1970] * 1000;
                
                self.curIDCardResult = result;
                
                //识别成功才关闭视频录制
                if(ALL_Save_Video)
                {
                    [self finishVideoWriter];
                }
            }

            if(!ALL_Save_Video)
            {
               [self finishVideoWriter];
            }
            
            if(result.idCardResultStatus == DSLHKIDCardResultStatus_Success)
            {
                //save图片
                if(Is_Save_Video_Picture)
                {
                    for(int i = 0; i < (int)[result.imageDataArray count]; ++i)
                    {
                        UIImage *image = [UIImage imageWithData:[result.imageDataArray objectAtIndex:i]];
                        UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
                    }
                }
                else if(Is_Local_Save)
                {
                     UIImage *image = [UIImage imageWithData:[result.imageDataArray firstObject]];
                    __block ALAssetsLibrary *lib = [[ALAssetsLibrary alloc] init];
                    [lib writeImageToSavedPhotosAlbum:image.CGImage metadata:nil completionBlock:^(NSURL *assetURL,NSError *error) {
                        
                        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *imageAsset)
                        {
                            ALAssetRepresentation *imageRep = [imageAsset defaultRepresentation];
                            self.imgSaveAlbumFileName = [imageRep filename];
                           if(![self.imgSaveAlbumFileName isEqualToString:@""] && ![self.videoSaveAlbumFileName isEqualToString:@""])
                            {
                                //[self saveRequestData];
                                [self selectIDCardTypeForSaveLocal];
                            }
                            NSLog(@"[imageRep filename ] : %@", [imageRep filename]);
                            
                        };
                        
                        ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
                        [assetslibrary assetForURL:assetURL resultBlock:resultblock failureBlock:nil];
                        
                        NSLog(@"save image assetURL = %@, error = %@", assetURL, error);
                        lib = nil;
                        
                    }];
                }
            }
        }

    }));
}

- (void)recFail
{
    //识别失败
    [self.motionManager stopAccelerometerUpdates];
    self.idCardInDeskOpStatusView.hidden = YES;
    
    self.recStepFinishView.hidden = YES;
    [self hideOpErrorTip];
    self.curIDCardResult = nil;
    
    //取消所有延时处理任务
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

- (void)proccessRecFail:(DSLHKIDCardResult *)result
{
    switch (result.idCardResultStatus)
    {
        case DSLHKIDCardResultStatus_Exposure:
        {
            //exposure:表示当前返回反光过强，重新开始识别;
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_Slices];
        }
            break;
        case DSLHKIDCardResultStatus_Lost:
        {
            //lost:目标(证件)丢失,在识别证件过程中，发现某些证件特征持续捕获不到导致识别失败
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_LostObject];
        }
            break;
        case DSLHKIDCardResultStatus_Overtime:
        {
            //overtime:识别超时,超时时间可以设置
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_OverTime];
        }
            break;
        case DSLHKIDCardResultStatus_Dark:
        {
            //dark:光线过暗，重新开始识别
            
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_Dark];
        }
            break;
        case DSLHKIDCardResultStatus_Invalid:
        {
            //invalid:不正确的操作动作，重新开始识别，重新开始识别
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_Invalid];
        }
            break;
        default:
            //异常的情况
            [self showRecFailResult:DSLHKIDCardRecFailType_Default];
            break;
    }
}

- (void)selectIDCardTypeForSaveLocal
{
    SelectTypeForSaveLocal* selectTypeForSaveLocal = [[SelectTypeForSaveLocal alloc] initWithFrame:CGRectMake(20.0, (self.view.bounds.size.height-500)/2, self.view.bounds.size.width-20*2, 500)];
    selectTypeForSaveLocal.myDelegate = self;
    [self.view addSubview:selectTypeForSaveLocal];
    
}

- (void)selectTypeForSaveLocalOk:(NSString* )env IDCardType:(NSString* )idCardType
{
    [self stopMovieRecorder];
    
    [self saveRequestData:env IDCardType:idCardType];
}

- (void)saveRequestData:(NSString* )env IDCardType:(NSString* )idCardType
{
    NSString* videoTimeStamp = [NSString stringWithFormat:@"%f|%f|%f|%f", self.dRecStartTimeStamp, self.dORTHTimeStamp, self.dRecStartExposureTimeStamp, self.dRecEndTimeStamp];
    
    NSDate *date = [NSDate date];
    NSTimeInterval timeIn = [date timeIntervalSince1970];
    
    NSString *videoPath = [self videoPath];
    NSURL *urlLocl = [NSURL fileURLWithPath:videoPath];
    NSData *videoData = [NSData dataWithContentsOfURL:urlLocl];

    NSDictionary *params = @{@"contextId": [self getUUID],
                             @"timestamp": [NSString stringWithFormat:@"%.0f", timeIn],
                             @"fileSize":[NSString stringWithFormat:@"%lu", (unsigned long)videoData.length],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",  //新老版本标志
                             @"return_illustraon": @"1",
                             @"imgSaveAlbumFileName" : self.imgSaveAlbumFileName,
                             @"videoSaveAlbumFileName" : self.videoSaveAlbumFileName,
                             @"videoTimeStamp":videoTimeStamp,
                             @"env":env,
                             @"idCardType":idCardType
                             };
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString;
    if (jsonData)
    {
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSLog(@"\n%@\n", jsonString);
        NSString* path = [self pathForSaveRequestData];
        
        NSMutableArray* muArrTmp = [self getSaveRequestData];
        if(muArrTmp == nil)
        {
            muArrTmp = [NSMutableArray arrayWithCapacity:5];
        }
        [muArrTmp addObject:jsonString];
        
        [NSKeyedArchiver archiveRootObject:muArrTmp toFile:path];
        
        [self showFinishedSaveAlert];
    }
    
    self.videoSaveAlbumFileName = @"";
    self.imgSaveAlbumFileName = @"";
}

- (void)showFinishedSaveAlert
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"保存成功!" preferredStyle:UIAlertControllerStyleAlert];
    
    //增加确定按钮；
    [alertController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self startRecognize];
        
    }]];
    
    [self presentViewController:alertController animated:true completion:nil];
}
    
- (void)removeSaveRequestData
{
    NSMutableArray* muArr = [NSMutableArray arrayWithCapacity:5];
    NSString* path = [self pathForSaveRequestData];
    [NSKeyedArchiver archiveRootObject:muArr toFile:path];
}
- (NSMutableArray* )getSaveRequestData
{
    NSString* path = [self pathForSaveRequestData];
    
    if(path == nil || [path isEqualToString:@""])
    {
        return [NSMutableArray arrayWithCapacity:5];
    }
    
    return [NSKeyedUnarchiver unarchiveObjectWithFile:path];
}
    
- (NSString* ) pathForSaveRequestData
{
    NSString* path = nil;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    if ([paths count] > 0)
    {
        path = [paths objectAtIndex:0];
    }
    path = [path stringByAppendingString:@"/saveRequestData.za"];
    
    return path;
}

    - (NSString* ) pathForSaveRequestDataTxt
    {
        NSString* path = nil;
        
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        if ([paths count] > 0)
        {
            path = [paths objectAtIndex:0];
        }
        path = [path stringByAppendingString:@"/zaData.txt"];
        
        return path;
    }

- (void)proccessRecordVideo
{
    [super proccessRecordVideo];
    
    //如果curIDCardResult为nil,则说明是识别失败的，需要删除当前录制的视频
    if(self.curIDCardResult)
    {
          self.imgViewRecStatus.hidden = YES;
        if(Is_Local_Save)
        {
            [self saveVideoToAlbumForLocalVersion:[NSURL fileURLWithPath:[self videoPath]]];
        }
        else
        {
            if(Is_Save_Video_Picture)
            {
                [self saveVideoToAlbum:[NSURL fileURLWithPath:[self videoPath]]];
            }
            
            [self hideRecIDCardOkTip:@"NO"];
            [self performSelector:@selector(hideRecIDCardOkTip:) withObject:@"YES" afterDelay:2];
            [self uploadVideoData];
        }
      
    }
    else
    {
        if(ALL_Save_Video)
        {
            //该模式下，识别失败也不删除视频，在识别成功后删除
            return;
        }
        
        BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:[self videoPath]];
        if(blHave)
        {
            BOOL b = [[NSFileManager defaultManager] removeItemAtPath:[self videoPath] error:nil];
            NSLog(@"movieRecorderDidFinishRecording 删除视频: %@", [NSString stringWithFormat:@"%i", b]);
        }
    }

}

- (void)saveVideoToAlbumForLocalVersion:(NSURL *)fileUrl {
    
    if(!Is_Save_Video_Picture && !Is_Local_Save)
    {
        return;
    }

    NSLog(@"saveVideoToAlbumForLocalVersion 当前视频文件大小 %f MB", [self fileSize:fileUrl]);
    __block ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    
    [library writeVideoAtPathToSavedPhotosAlbum:fileUrl
                                completionBlock:^(NSURL *assetURL, NSError *error) {
                                    if (error)
                                    {
                                        NSLog(@"Save video fail:%@",error);
                                    }
                                    else
                                    {
                                        NSLog(@"Save video succeed.");
                                        
                                        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *imageAsset)
                                        {
                                            ALAssetRepresentation *imageRep = [imageAsset defaultRepresentation];
                                            self.videoSaveAlbumFileName = [imageRep filename];
                                            if(![self.imgSaveAlbumFileName isEqualToString:@""] && ![self.videoSaveAlbumFileName isEqualToString:@""])
                                            {
                                                //[self saveRequestData];
                                                [self selectIDCardTypeForSaveLocal];
                                            }
                                         
                                            NSLog(@"文件视频地址 : %@", [imageRep filename]);
                                        };
                                        
                                        ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
                                        [assetslibrary assetForURL:assetURL resultBlock:resultblock failureBlock:nil];
                                        NSLog(@"save video assetURL = %@, error = %@", assetURL, error);
                                        library = nil;
                                    }
                                }];
}

- (void)showRecFailResult:(DSLHKIDCardRecFailType)failType
{
    [self.resultFailView showResultFailView:failType];
    }

- (void)hideRecIDCardOkTip:(NSString* ) strHidden
{
    BOOL hidden = [strHidden boolValue];
    self.imgViewRecIDCardOkTip.hidden = hidden;
    if(hidden)
    {
        if(Is_Local_Save)
        {
            [self uploadVideoData];
        }
        else
        {
            //进入人脸识别
            [self start];
        }

    }
}

- (void)clickFailOK
{
#warning 当用户点击退出按钮后，由于一些网络请求的原因，该viewcontroller并不会立即dealloc,加了个判断
    if(!self.bExited && [UIApplication sharedApplication].applicationState == UIApplicationStateActive)
    {
        [self startRecognize];
    }
}

- (void)clickHandIDCardTipViewOK
{
    self.handIDCardTipView.hidden = YES;
    [self startRecognize];
}

#pragma mark -- help methods
- (NSString* )getUUID
{
    if(self.contextId == nil || [self.contextId isEqualToString:@""])
    {
        self.contextId = [[NSUUID UUID] UUIDString];
        
        
    }
    
    return self.contextId;
}

- (void)resetUUID
{
    
    self.contextId = @"";
    self.dRecStartTimeStamp = 0;
    self.dRecEndTimeStamp = 0;
    self.dRecStartExposureTimeStamp = 0;
    self.dORTHTimeStamp = 0;
}

#pragma mark -- 加速度计获取手机屏幕旋转角度
- (void)startMotionManager
{
    if(self.motionManager == nil)
    {
        self.motionManager = [[CMMotionManager alloc] init];
    }

    if(self.motionManager.accelerometerAvailable)
    {

    self.motionManager.accelerometerUpdateInterval=0.2;
    [self.motionManager startAccelerometerUpdatesToQueue:[NSOperationQueue mainQueue] withHandler:^(CMAccelerometerData * _Nullable accelerometerData, NSError * _Nullable error) {
        if(error)
        {
            NSLog(@"加速度计异常");
        }
        else
        {
             double zTheta =atan2(accelerometerData.acceleration.z,sqrtf(accelerometerData.acceleration.x*accelerometerData.acceleration.x+accelerometerData.acceleration.y*accelerometerData.acceleration.y))/M_PI*(-90.0)*2-90;
            
            if((fabs(accelerometerData.acceleration.y)) < 0.2)
            {
                if(accelerometerData.acceleration.x > 0)//向右
                {
                    [self.idCardInDeskOpStatusView updateRotationAngle:-zTheta RotationDirctionLeft:NO];
                    
                    //NSLog(@"夹角是%.2f 向右, x:%.2f, y:%.2f, z:%.2f",-zTheta, accelerometerData.acceleration.x, accelerometerData.acceleration.y, accelerometerData.acceleration.z);
                }
                else
                {
                    [self.idCardInDeskOpStatusView updateRotationAngle:-zTheta RotationDirctionLeft:YES];
                    //NSLog(@"夹角是%.2f 向左, x:%.2f, y:%.2f, z:%.2f",-zTheta, accelerometerData.acceleration.x, accelerometerData.acceleration.y, accelerometerData.acceleration.z);
                }
                if([self.labelOpErrorTip.text isEqualToString:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title20"]])
                {
                    //如果当前的错误提示内容是:证件没有与手机平行放置，则clear
                    [self hideOpErrorTip];
                }
            }
            else
            {
                [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title20"]];
                NSLog(@"手机与桌面不平行 y:%.2f,",accelerometerData.acceleration.y);
                self.iNoParallelToMobilePhoneCount++;
            }
        }
    }];
    }
    else
    {
        NSLog(@"This device has no accelerometer");
    }
}

#pragma mark -- 上传相关

/**
 静态图片上传接口

 @param img 静态图片
 */
- (void)uploadStaticImg:(NSData* )img
{

    if(img == nil)
    {
        [self.view makeToast:@"静态图片空" duration:30.0 position:CSToastPositionCenter];
        return;
    }
    
    //UIImage *image = [UIImage imageWithData:img];
    //UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
    
    NSArray* arrImg = [NSArray arrayWithObjects:img, nil];
    
    __weak typeof(self) weakSelf = self;
    
    NSString* url = @"/kyc/api/drei/ocr";
   
    NSMutableDictionary* dicCustom = [DSLHKIDCardSDK signatureWithImg:img];
    NSString* signature = [dicCustom objectForKey:@"signature"];
    NSString* custom = [dicCustom objectForKey:@"custom"];
    
    NSDictionary* params = @{@"contextId": [self getUUID],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",//新老版本标志
                             @"rectifyTemplate": [DSLHKIDCardSDK getVersion],
                             @"signature":signature,
                             @"custom":custom
                             };
    [IRNetworkEngine uploadTaskIRService:url files:arrImg filename:@"files" header:nil parameters:params custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog(@"uploadStaticImg end...");
            if (error) {
                NSLog(@"静态图上传失败: %@", [error localizedDescription]);
                [weakSelf.view makeToast:@"静态图上传失败" duration:30.0 position:CSToastPositionCenter];
                
            } else {
                NSLog(@"静态图上传结果: %@", [NSString stringWithFormat:@"%@", result]);
                
                NSDictionary* dicOCRResult = result[@"result"];
                if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]] &&  [result[@"resultCode"] intValue] == 0)
                {
                    self.bOCRCheckCodeFail = NO;
                    self.resultInfoModel.gender = dicOCRResult[@"sex"];
                    if([self isCurrentLanguageEn])
                    {
                        self.resultInfoModel.firstName = dicOCRResult[@"name_en"];
                        self.resultInfoModel.certiType = dicOCRResult[@"title_en"];
                    }
                    else
                    {
                        self.resultInfoModel.firstName = dicOCRResult[@"name_cn"];
                        self.resultInfoModel.certiType = dicOCRResult[@"title_cn"];
                    }
                    self.resultInfoModel.certiNo = dicOCRResult[@"card_number"];
                    self.resultInfoModel.birthday = dicOCRResult[@"date_birth"];

                    NSLog(@"OCR info: gender:%@, certiType:%@, certiNo:%@, birthday:%@, firstName:%@", self.resultInfoModel.gender, self.resultInfoModel.certiType, self.resultInfoModel.certiNo, self.resultInfoModel.birthday, self.resultInfoModel.firstName);
                    
                    if(self.bUploadVideoDataSuccess && self.bUploadFaceRecognitionSuccess)
                    {
                        [self gotoResultVc:self.resultInfoModel];
                    }
                    
                }
                else if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]] &&  [result[@"resultCode"] intValue] == 100)
                {
                    //OCR校验码错误
                    self.bOCRCheckCodeFail = YES;
                    self.resultInfoModel.gender = dicOCRResult[@"sex"];
                    if([self isCurrentLanguageEn])
                    {
                        self.resultInfoModel.firstName = dicOCRResult[@"name_en"];
                        self.resultInfoModel.certiType = dicOCRResult[@"title_en"];
                    }
                    else
                    {
                        self.resultInfoModel.firstName = dicOCRResult[@"name_cn"];
                        self.resultInfoModel.certiType = dicOCRResult[@"title_cn"];
                    }
                    self.resultInfoModel.certiNo = dicOCRResult[@"card_number"];
                    self.resultInfoModel.birthday = dicOCRResult[@"date_birth"];

                    NSLog(@"OCR info: gender:%@, certiType:%@, certiNo:%@, birthday:%@, firstName:%@", self.resultInfoModel.gender, self.resultInfoModel.certiType, self.resultInfoModel.certiNo, self.resultInfoModel.birthday, self.resultInfoModel.firstName);
                    
                    if(self.bUploadVideoDataSuccess && self.bUploadFaceRecognitionSuccess)
                    {
                        [self gotoResultVc:self.resultInfoModel];
                    }
                }
                else
                {
                    if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]])
                    {
                        [weakSelf.view makeToast:[NSString stringWithFormat:@"静态图上传错误resultCode=%i", [result[@"resultCode"] intValue]] duration:30.0 position:CSToastPositionCenter];
                    }
                }
                
            }
        });
    }];
    
}


/**
 视频上传接口
 */
- (void)uploadVideoData11 {
    // [self.view makeToastActivity:CSToastPositionCenter];
    //[self.view makeToast:@"视频上传中..."];
    NSLog(@"uploadVideoData start...");
    //[self.view makeToast:@"视频上传中..." duration:1000 position:CSToastPositionCenter];
    
    self.bUploadVideoDataSuccess = NO;
    
    NSDate *date = [NSDate date];
    NSTimeInterval timeIn = [date timeIntervalSince1970];

    NSString *videoPath = [self videoPath];
    NSURL *urlLocl = [NSURL fileURLWithPath:videoPath];
    NSData *videoData = [NSData dataWithContentsOfURL:urlLocl];
    
    double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
       
    [self recordSuccess:self.iFailCount DurationTime:d VideoSize:(unsigned long)videoData.length VideoTimeLenght:(self.dRecEndTimeStamp-self.dRecStartTimeStamp) SessionID:[self getUUID]];
    
    if(videoData.length == 0)
    {
        //[self.view makeToast:@"视频是空的" duration:6.0 position:CSToastPositionCenter];
        return;
    }
    
    NSLog(@"uploadVideoData 当前视频文件大小 %f MB", [self fileSize:urlLocl]);
    
    NSString* url = @"/kyc/api/drei/da";
    
    NSString* videoTimeStamp = [NSString stringWithFormat:@"%f|%f|%f|%f", self.dRecStartTimeStamp, self.dORTHTimeStamp, self.dRecStartExposureTimeStamp, self.dRecEndTimeStamp];
    
    NSData* imgData = [self.curIDCardResult.imageDataArray firstObject];
    NSString* base64Str = [imgData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSLog(@"videoTimeStamp = %@", videoTimeStamp);
    __weak typeof(self) weakSelf = self;
    NSMutableDictionary* dicCustom = [DSLHKIDCardSDK signatureWithVideoFile:[self videoPath] TemplateImage:base64Str VideoTimeStamp:videoTimeStamp];
    
    NSString* signature = [dicCustom objectForKey:@"signature"];
    NSString* custom = [dicCustom objectForKey:@"custom"];
    
    NSDictionary *params = @{@"contextId": [self getUUID],
                             @"equipmentModel": [[UIDevice currentDevice] ir_deviceModel],
                             @"timestamp": [NSString stringWithFormat:@"%.0f", timeIn],
                             @"pushresult": @"",
                             @"delta": @"",
                             @"fileSize":[NSString stringWithFormat:@"%lu", (unsigned long)videoData.length],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",  //新老版本标志
                             @"return_illustraon": @"1",
                             @"signature":signature,
                             @"custom":custom
                             };
    

    [IRNetworkEngine uploadTaskIRService:url files:@[videoData] filename:@"files" header:nil parameters:params custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //[weakSelf.view hideToastActivity];
            
            self.bUploadVideoDataSuccess = YES;
            
            NSLog(@"uploadVideoData end...");
            if (error) {
                NSLog(@"视频上传失败: %@", [error localizedDescription]);
                [weakSelf.view makeToast:@"视频上传失败" duration:30.0 position:CSToastPositionCenter];
                
            } else {
                NSLog(@"视频上传结果: %@", [NSString stringWithFormat:@"%@", result]);
                
                if(![result isKindOfClass:[NSNull class]] && [result[@"resultCode"] intValue] == 0)   //成功
                {
                    
                    NSDictionary* dicDetail =  result[@"result"][@"detail"];
                    if(self.recType == DSLHKIDCardTypeApp_2018)
                    {
                        if(![dicDetail[@"face_similarity"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"face_similarity"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                 self.resultInfoModel.bFaceSimilarity = [dicDetail[@"face_similarity"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDetail[@"color_printing"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"color_printing"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bColorPrinting = [dicDetail[@"color_printing"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDetail[@"image_quality"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"image_quality"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bImageQuality = [dicDetail[@"image_quality"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDetail[@"laser_face"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"laser_face"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bLaserFace = [dicDetail[@"laser_face"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDetail[@"laser_redbud"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"laser_redbud"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bLaserRedbud = [dicDetail[@"laser_redbud"][@"is_accept"] boolValue];
                                self.resultInfoModel.laserRedbudScore = [dicDetail[@"laser_redbud"][@"score"] doubleValue];
                            }
                        }
                        
                        
                        if(![dicDetail[@"highlight"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"highlight"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bHighlight = [dicDetail[@"highlight"][@"is_accept"] boolValue];
                            }
                        }
                 
                        //证件是否被篡改
                        if(![dicDetail[@"tampered"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"tampered"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bTampered = [dicDetail[@"tampered"][@"is_accept"] boolValue];
                            }
                        }
                        
                        //材质检测
                        if(![dicDetail[@"deep_rtriangle"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"deep_rtriangle"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bDeep_rtriangle = [dicDetail[@"deep_rtriangle"][@"is_accept"] boolValue];
                            }
                        }
                    }
                    else
                    {
                        //动感印刷HK字母是否通过
                        if(![dicDetail[@"H_K"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"H_K"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bHkOld = [dicDetail[@"H_K"][@"is_accept"] boolValue];
                            }
                        }
                        //变色油墨是否通过
                        if(![dicDetail[@"optical_variable"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"optical_variable"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bTriColorOld = [dicDetail[@"optical_variable"][@"is_accept"] boolValue];
                            }
                        }
                        
                        //动感印刷人脸变化是否通过
                        if(![dicDetail[@"smallface"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"smallface"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bSmallFace = [dicDetail[@"smallface"][@"is_accept"] boolValue];
                            }
                        }
                        //证件人脸对比是否通过
                        if(![dicDetail[@"face_similarity"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"face_similarity"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bFaceSimilarity = [dicDetail[@"face_similarity"][@"is_accept"] boolValue];
                            }
                        }
                        //芯片匹配是否通过
                        if(![dicDetail[@"chip_match"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"chip_match"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bChipOld = [dicDetail[@"chip_match"][@"is_accept"] boolValue];
                            }
                        }
                        //图像亮度是否通过
                        if(![dicDetail[@"reflection"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"reflection"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bHighlight = [dicDetail[@"reflection"][@"is_accept"] boolValue];
                            }
                        }
                        //渐变色特征是否通过
                        if(![dicDetail[@"gradual_color"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"gradual_color"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bGradualOld = [dicDetail[@"gradual_color"][@"is_accept"] boolValue];
                            }
                        }
                 
                        //证件是否被篡改
                        if(![dicDetail[@"tampered"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDetail[@"tampered"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.bTampered = [dicDetail[@"tampered"][@"is_accept"] boolValue];
                            }
                        }
                        
                    }
                    
                    //验真结果分数
                    if(![result[@"result"][@"authenticity"] isKindOfClass:[NSNull class]])
                    {
                        if(![result[@"result"][@"authenticity"][@"score"] isKindOfClass:[NSNull class]])
                        {
                            self.resultInfoModel.authenticity = [result[@"result"][@"authenticity"][@"score"] doubleValue];
                        }
                        
                        if(![result[@"result"][@"authenticity"][@"thresholds"] isKindOfClass:[NSNull class]])
                        {
                            
                             if(![result[@"result"][@"authenticity"][@"thresholds"][@"high_risk"] isKindOfClass:[NSNull class]])
                             {
                                 self.resultInfoModel.low_threshold = [result[@"result"][@"authenticity"][@"thresholds"][@"high_risk"] doubleValue];
                             }
                            
                            if(![result[@"result"][@"authenticity"][@"thresholds"][@"low_risk"] isKindOfClass:[NSNull class]])
                            {
                                self.resultInfoModel.high_threshold = [result[@"result"][@"authenticity"][@"thresholds"][@"low_risk"] doubleValue];
                            }
                        }
                        
                    }
                    
                    //视频质量分数
                    if(![result[@"result"][@"quality"] isKindOfClass:[NSNull class]])
                    {
                        if(![result[@"result"][@"quality"][@"score"] isKindOfClass:[NSNull class]])
                        {
                            self.resultInfoModel.qualityScore = [result[@"result"][@"quality"][@"score"] doubleValue];
                        }
                        
                        if(![result[@"result"][@"quality"][@"threshold"] isKindOfClass:[NSNull class]])
                        {
                            self.resultInfoModel.qualitythreshold = [result[@"result"][@"quality"][@"threshold"] doubleValue];
                        }
                    }
                    

                    NSData * idImageData = nil;
                    if([result[@"result"][@"image"] isKindOfClass:[NSNull class]])
                    {
                        NSString* imgStr = result[@"result"][@"image"];
                        idImageData   = [[NSData alloc] initWithBase64EncodedString:imgStr options:NSDataBase64DecodingIgnoreUnknownCharacters];
                    }
                    else
                    {
                        idImageData = [self.curIDCardResult.imageDataArray firstObject];
                    }
                    self.resultInfoModel.imgIdCard = idImageData;
                    if(self.bUploadFaceRecognitionSuccess)
                    {
                        self.loadingRecView.hidden = YES;
                        [self gotoResultVc:self.resultInfoModel];
                    }
                }
                else
                {
                    //失败
                    if(self.bUploadFaceRecognitionSuccess)
                    {
                        
                         if(![result isKindOfClass:[NSNull class]])   //成功
                         {
                            [weakSelf.view makeToast:[NSString stringWithFormat:@"resultCode=%i", [result[@"resultCode"] intValue]] duration:30.0 position:CSToastPositionCenter];
                         }

                        self.loadingRecView.hidden = YES;
                        [self gotoResultFailVc];
                    }
                }
                
                
                BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:[weakSelf videoPath]];
                if(blHave)
                {
                    BOOL b = [[NSFileManager defaultManager] removeItemAtPath:[weakSelf videoPath] error:nil];
                    NSLog(@"删除视频: %@", [NSString stringWithFormat:@"%i", b]);
                }
                
            }
        });
    }];
}

/**
 视频上传接口
 */
- (void)uploadVideoData {
    // [self.view makeToastActivity:CSToastPositionCenter];
    //[self.view makeToast:@"视频上传中..."];
    NSLog(@"uploadVideoData start...");
    //[self.view makeToast:@"视频上传中..." duration:1000 position:CSToastPositionCenter];
    
    self.bUploadVideoDataSuccess = NO;
    
    NSDate *date = [NSDate date];
    NSTimeInterval timeIn = [date timeIntervalSince1970];

    NSString *videoPath = [self videoPath];
    NSURL *urlLocl = [NSURL fileURLWithPath:videoPath];
    NSData *videoData = [NSData dataWithContentsOfURL:urlLocl];
    
    double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
    
    [self recordSuccess:self.iFailCount DurationTime:d VideoSize:(unsigned long)videoData.length VideoTimeLenght:(self.dRecEndTimeStamp-self.dRecStartTimeStamp) SessionID:[self getUUID]];
    
    if(videoData.length == 0)
    {
        //[self.view makeToast:@"视频是空的" duration:6.0 position:CSToastPositionCenter];
        return;
    }
    
    NSLog(@"uploadVideoData 当前视频文件大小 %f MB", [self fileSize:urlLocl]);
    
    NSString* url = @"/kyc/api/vier/da";//@"/kyc/api/drei/da";
    
    NSString* videoTimeStamp = [NSString stringWithFormat:@"%f|%f|%f|%f", self.dRecStartTimeStamp, self.dORTHTimeStamp, self.dRecStartExposureTimeStamp, self.dRecEndTimeStamp];
    
    NSData* imgData = [self.curIDCardResult.imageDataArray firstObject];
    NSString* base64Str = [imgData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSLog(@"videoTimeStamp = %@", videoTimeStamp);
    __weak typeof(self) weakSelf = self;
    NSMutableDictionary* dicCustom = [DSLHKIDCardSDK signatureWithVideoFile:[self videoPath] TemplateImage:base64Str VideoTimeStamp:videoTimeStamp];
    
    NSString* signature = [dicCustom objectForKey:@"signature"];
    NSString* custom = [dicCustom objectForKey:@"custom"];
    
    NSDictionary *params = @{@"contextId": [self getUUID],
                             @"equipmentModel": [[UIDevice currentDevice] ir_deviceModel],
                             @"timestamp": [NSString stringWithFormat:@"%.0f", timeIn],
                             @"pushresult": @"",
                             @"delta": @"",
                             @"fileSize":[NSString stringWithFormat:@"%lu", (unsigned long)videoData.length],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",  //新老版本标志
                             @"return_illustraon": @"1",
                             @"signature":signature,
                             @"custom":custom
                             };
    

    [IRNetworkEngine uploadTaskIRService:url files:@[videoData] filename:@"files" header:nil parameters:params custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //[weakSelf.view hideToastActivity];
            
            weakSelf.bUploadVideoDataSuccess = YES;
            
            NSLog(@"uploadVideoData end...");
            if (error) {
                NSLog(@"视频上传失败: %@", [error localizedDescription]);
                [weakSelf.view makeToast:@"视频上传失败" duration:30.0 position:CSToastPositionCenter];
                
            } else {
                NSLog(@"视频上传结果: %@", [NSString stringWithFormat:@"%@", result]);
                
                if(![result isKindOfClass:[NSNull class]] && [result[@"resultCode"] intValue] == 200)   //成功
                {
                    
                    NSDictionary* dicOCRResult = result[@"result"][@"ocr"];
                    if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]])
                    {
                        weakSelf.resultInfoModel.gender = dicOCRResult[@"sex"];
                        if([weakSelf isCurrentLanguageEn])
                        {
                            weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_en"];
                            weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_en"];
                        }
                        else
                        {
                            weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_cn"];
                            weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_cn"];
                        }
                        weakSelf.resultInfoModel.certiNo = dicOCRResult[@"card_number"];
                        weakSelf.resultInfoModel.birthday = dicOCRResult[@"date_birth"];

                        NSLog(@"OCR info: gender:%@, certiType:%@, certiNo:%@, birthday:%@, firstName:%@", weakSelf.resultInfoModel.gender, weakSelf.resultInfoModel.certiType, weakSelf.resultInfoModel.certiNo, weakSelf.resultInfoModel.birthday, weakSelf.resultInfoModel.firstName);
                    }
                
                    NSDictionary* dicDaResult =  result[@"result"][@"da"][@"detail"];
                    if(weakSelf.recType == DSLHKIDCardTypeApp_2018)
                    {
                        if(![dicDaResult[@"face_similarity"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"face_similarity"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                 weakSelf.resultInfoModel.bFaceSimilarity = [dicDaResult[@"face_similarity"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"color_printing"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"color_printing"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bColorPrinting = [dicDaResult[@"color_printing"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"image_quality"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"image_quality"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bImageQuality = [dicDaResult[@"image_quality"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"laser_face"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"laser_face"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bLaserFace = [dicDaResult[@"laser_face"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"laser_redbud"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"laser_redbud"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bLaserRedbud = [dicDaResult[@"laser_redbud"][@"is_accept"] boolValue];
                                weakSelf.resultInfoModel.laserRedbudScore = [dicDaResult[@"laser_redbud"][@"score"] doubleValue];
                            }
                        }
                        
                        
                        if(![dicDaResult[@"highlight"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"highlight"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bHighlight = [dicDaResult[@"highlight"][@"is_accept"] boolValue];
                            }
                        }
                 
                        //证件是否被篡改
                        if(![dicDaResult[@"tampered"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"tampered"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bTampered = [dicDaResult[@"tampered"][@"is_accept"] boolValue];
                            }
                        }
                        //材质检测
                        if(![dicDaResult[@"deep_rtriangle"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"deep_rtriangle"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bDeep_rtriangle = [dicDaResult[@"deep_rtriangle"][@"is_accept"] boolValue];
                            }
                        }
                        
                    }
                    else
                    {
                        //动感印刷HK字母是否通过
                        if(![dicDaResult[@"H_K"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"H_K"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bHkOld = [dicDaResult[@"H_K"][@"is_accept"] boolValue];
                            }
                        }
                        //变色油墨是否通过
                        if(![dicDaResult[@"optical_variable"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"optical_variable"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bTriColorOld = [dicDaResult[@"optical_variable"][@"is_accept"] boolValue];
                            }
                        }
                        
                        //动感印刷人脸变化是否通过
                        if(![dicDaResult[@"smallface"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"smallface"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bSmallFace = [dicDaResult[@"smallface"][@"is_accept"] boolValue];
                            }
                        }
                        //证件人脸对比是否通过
                        if(![dicDaResult[@"face_similarity"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"face_similarity"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bFaceSimilarity = [dicDaResult[@"face_similarity"][@"is_accept"] boolValue];
                            }
                        }
                        //芯片匹配是否通过
                        if(![dicDaResult[@"chip_match"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"chip_match"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bChipOld = [dicDaResult[@"chip_match"][@"is_accept"] boolValue];
                            }
                        }
                        //图像亮度是否通过
                        if(![dicDaResult[@"reflection"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"reflection"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bHighlight = [dicDaResult[@"reflection"][@"is_accept"] boolValue];
                            }
                        }
                        //渐变色特征是否通过
                        if(![dicDaResult[@"gradual_color"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"gradual_color"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bGradualOld = [dicDaResult[@"gradual_color"][@"is_accept"] boolValue];
                            }
                        }
                 
                        //证件是否被篡改
                        if(![dicDaResult[@"tampered"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"tampered"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bTampered = [dicDaResult[@"tampered"][@"is_accept"] boolValue];
                            }
                        }
                        
                    }
                    
                    //验真结果分数
                    if(![result[@"result"][@"da"][@"authenticity"] isKindOfClass:[NSNull class]])
                    {
                        if(![result[@"result"][@"da"][@"authenticity"][@"score"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.authenticity = [result[@"result"][@"da"][@"authenticity"][@"score"] doubleValue];
                        }
                        
                        if(![result[@"result"][@"da"][@"authenticity"][@"thresholds"] isKindOfClass:[NSNull class]])
                        {
                            
                             if(![result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"high_risk"] isKindOfClass:[NSNull class]])
                             {
                                 weakSelf.resultInfoModel.low_threshold = [result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"high_risk"] doubleValue];
                             }
                            
                            if(![result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"low_risk"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.high_threshold = [result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"low_risk"] doubleValue];
                            }
                        }
                        
                    }
                    
                    //视频质量分数
                    if(![result[@"result"][@"da"][@"quality"] isKindOfClass:[NSNull class]])
                    {
                        if(![result[@"result"][@"da"][@"quality"][@"score"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.qualityScore = [result[@"result"][@"da"][@"quality"][@"score"] doubleValue];
                        }
                        
                        if(![result[@"result"][@"da"][@"quality"][@"threshold"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.qualitythreshold = [result[@"result"][@"da"][@"quality"][@"threshold"] doubleValue];
                        }
                    }
                    
                    //是否翻拍
                    
                    if(![dicDaResult[@"reproduction"] isKindOfClass:[NSNull class]])
                    {
                        if(![dicDaResult[@"reproduction"][@"is_reproduction"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.bReproduction = [dicDaResult[@"reproduction"][@"is_reproduction"] boolValue];
                        }
                    }
                    
                    NSData * idImageData = nil;
                    if(![result[@"result"][@"da"][@"image"] isKindOfClass:[NSNull class]])
                    {
                        NSString* imgStr = result[@"result"][@"da"][@"image"];
                        idImageData   = [[NSData alloc] initWithBase64EncodedString:imgStr options:NSDataBase64DecodingIgnoreUnknownCharacters];
                    }
                    else
                    {
                        idImageData = [weakSelf.curIDCardResult.imageDataArray firstObject];
                    }
                    weakSelf.resultInfoModel.imgIdCard = idImageData;
                    if(weakSelf.bUploadFaceRecognitionSuccess)
                    {
                        weakSelf.loadingRecView.hidden = YES;
                        [weakSelf gotoResultVc:weakSelf.resultInfoModel];
                    }
                }
                else
                {
                    //失败
                    if(weakSelf.bUploadFaceRecognitionSuccess)
                    {
                        
                         if(![result isKindOfClass:[NSNull class]])   //成功
                         {
                            [weakSelf.view makeToast:[NSString stringWithFormat:@"resultCode=%i", [result[@"resultCode"] intValue]] duration:30.0 position:CSToastPositionCenter];
                         }

                        weakSelf.loadingRecView.hidden = YES;
                        [weakSelf gotoResultFailVc];
                    }
                }
                
                
                BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:[weakSelf videoPath]];
                if(blHave)
                {
                    BOOL b = [[NSFileManager defaultManager] removeItemAtPath:[weakSelf videoPath] error:nil];
                    NSLog(@"删除视频: %@", [NSString stringWithFormat:@"%i", b]);
                }
                
            }
        });
    }];
}

/**
 人脸比对上传接口
 
 @param imgRec 证件图片
 @param imgFace 人脸图片
 */
- (void)uploadFaceRecognition:(NSData* )imgRec ImgFace:(NSData* )imgFace
{
    
    if(imgRec == nil)
    {
        [self.view makeToast:@"证件图片空" duration:30.0 position:CSToastPositionCenter];
        return;
    }
    if(imgFace == nil)
    {
        [self.view makeToast:@"人脸图片空" duration:30.0 position:CSToastPositionCenter];
        return;
    }
    
    self.bUploadFaceRecognitionSuccess = NO;
    self.loadingRecView.hidden = NO;
    
    NSString* url = @"/kyc/api/drei/face";
 
    __weak typeof(self) weakSelf = self;
    NSArray* arr = [NSArray arrayWithObjects:imgRec, imgFace, nil];
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    
    [IRNetworkEngine uploadTaskIRService:url files:arr filename:@"files" header:nil  parameters:@{@"contextId":[self getUUID]} custom:@{@"appVersion": [NSString stringWithFormat:@"%@", app_Version]} completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
          
            self.bUploadFaceRecognitionSuccess = YES;
            
            NSLog(@"uploadFaceRecognition end...");
            
            NSDictionary* dicFaceResult = result[@"result"];

            if([result isKindOfClass:[NSNull class]]
               ||
               ([result[@"success"] intValue] == 0)
               ||
               (dicFaceResult == nil || [dicFaceResult isKindOfClass:[NSNull class]])
               )
            {
                self.loadingRecView.hidden = YES;
                [weakSelf.view makeToast:@"人脸比对结果返回错误" duration:30.0 position:CSToastPositionCenter];
                [weakSelf gotoResultFailVc];
            }
            else
            {
                if(![result[@"result"][@"verifySimilarity"] isKindOfClass:[NSNull class]])
                {
                    self.resultInfoModel.similarity = [result[@"result"][@"verifySimilarity"] doubleValue];
                    
                }
                if(![result[@"result"][@"resultCode"] isKindOfClass:[NSNull class]])
                {
                    self.resultInfoModel.bFaceVerifyValid = [result[@"result"][@"resultCode"] intValue] == 0 ? YES : NO;
                    
                }
                
                if(self.bUploadVideoDataSuccess)
                {
                    self.loadingRecView.hidden = YES;
                    [weakSelf gotoResultVc:self.resultInfoModel];
                }
                
            }
            
            
            
        });
    }];
}

- (void)gotoResultVc:(ResultInfoModel* )model
{
    DSLHKIDCardResultController* vc = [[DSLHKIDCardResultController alloc] init];
    vc.imgFaceRec = self.curImgFaceData;
    vc.imgSmallHead = [UIImage imageWithData:[self.curIDCardResult.imageDataArray lastObject]];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    vc.imgIDCard =  [UIImage imageWithData:model.imgIdCard];
    vc.resultInfoModel = model;
    if(self.bOCRCheckCodeFail)
    {
        vc.resultInfoModel.authenticity = 0.0;
    }
    vc.recType = self.recType;
    
    if(self.contextId != nil &&  ![self.contextId isEqualToString:@""])
    {
        vc.recID = [self.contextId substringWithRange:NSMakeRange(self.contextId.length-8, 8)];
    }
    else
    {
        vc.recID = @"ABCDEFGH";
    }
    
    self.bUploadVideoDataSuccess = NO;
    self.bUploadFaceRecognitionSuccess = NO;
    
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)gotoResultFailVc
{
    DSLHKIDCardResultFailViewController* vc = [[DSLHKIDCardResultFailViewController alloc] init];
    vc.myDelegate = self;
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:nil];
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

#pragma mark-- DSLHKIDCardResultFailVcDelegate methods
- (void)resultFailDismissVc
{
    [self.presentingViewController dismissViewControllerAnimated:NO completion:nil];
}


#pragma mark-- 重写基类方法

- (void)initIDCardToRect
{
    CGSize size = self.view.bounds.size;
    if(self.recType == DSLHKIDCardTypeApp_2003)
    {
        self.idCardToRect = CGRectMake((size.width-228)/2,(size.height - 358)/2, 228, 358);
    }
    else
    {
        float x = size.width * 0.05;
        self.idCardToRect = CGRectMake(x,(size.height - 228)/2.0, size.width-2*x, 228);
    }

}

- (void)setRecStatus:(DSLHKIDCardRecStatus)recStatus
{

    self.imgViewRecStatus.hidden = YES;
    switch (recStatus)
    {
        case DSLHKIDCardRecStatus_Reset:
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self turnTorchOn:YES];
            }
            
            break;
        }
        default:
            
            break;
    }
}

@end

