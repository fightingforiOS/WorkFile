//
//  SelectTypeForSaveLocal.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/8/26.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "SelectTypeForSaveLocal.h"
#import "UIColor+DSLCHexColor.h"

@interface SelectTypeForSaveLocal()

@property(nonatomic, strong) UILabel* labelEnv;
@property(nonatomic, strong) UIButton* btnEnv1;
@property(nonatomic, strong) UIButton* btnEnv2;
@property(nonatomic, strong) UIButton* btnEnv3;
@property(nonatomic, strong) UIButton* btnEnv4;
@property(nonatomic, strong) UIButton* btnEnv5;
@property(nonatomic, strong) UIButton* btnEnv6;
@property(nonatomic, strong) UIButton* btnEnv7;
@property(nonatomic, strong) UIButton* btnEnv8;

@property(nonatomic, strong) UILabel* labelIDCardType;
@property(nonatomic, strong) UIButton* btnIDCardType1;
@property(nonatomic, strong) UIButton* btnIDCardType2;
@property(nonatomic, strong) UIButton* btnIDCardType3;
@property(nonatomic, strong) UIButton* btnIDCardType4;
@property(nonatomic, strong) UIButton* btnIDCardType5;

@property(nonatomic, strong) UIButton* btnOK;

@property(nonatomic, copy) NSString* selectedEnv;
@property(nonatomic, copy) NSString* selectedIDCardType;

@end

@implementation SelectTypeForSaveLocal

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        self.selectedIDCardType = @"";
        self.selectedEnv = @"";
        
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    self.backgroundColor = [UIColor whiteColor];
    self.layer.cornerRadius = 5.0;
    
    float w = self.bounds.size.width;
    float btnW = 120.0;
    
    [self addSubview:self.labelEnv];
    self.labelEnv.frame = CGRectMake(20.0, 10.0, 200.0, 20.0);
    
    [self addSubview:self.btnEnv1];
    self.btnEnv1.frame = CGRectMake(20.0, self.labelEnv.frame.origin.y+self.labelEnv.frame.size.height+10.0, btnW, 37.0);
    
    [self addSubview:self.btnEnv2];
    self.btnEnv2.frame = CGRectMake(w-btnW-20.0, self.labelEnv.frame.origin.y+self.labelEnv.frame.size.height+10.0, btnW, 37.0);
    
    [self addSubview:self.btnEnv3];
    self.btnEnv3.frame = CGRectMake(20.0, self.btnEnv2.frame.origin.y+self.btnEnv2.frame.size.height+20.0, btnW, 37.0);
    
    [self addSubview:self.btnEnv4];
    self.btnEnv4.frame = CGRectMake(w-btnW-20.0, self.btnEnv2.frame.origin.y+self.btnEnv2.frame.size.height+20.0, btnW, 37.0);
    
    [self addSubview:self.btnEnv5];
    self.btnEnv5.frame = CGRectMake(20.0, self.btnEnv4.frame.origin.y+self.btnEnv4.frame.size.height+20.0, btnW, 37.0);
    
    [self addSubview:self.btnEnv6];
    self.btnEnv6.frame = CGRectMake(w-btnW-20.0, self.btnEnv4.frame.origin.y+self.btnEnv4.frame.size.height+20.0, btnW, 37.0);
    
    [self addSubview:self.btnEnv7];
    self.btnEnv7.frame = CGRectMake(20.0, self.btnEnv6.frame.origin.y+self.btnEnv6.frame.size.height+20.0, btnW, 37.0);
    
    [self addSubview:self.btnEnv8];
    self.btnEnv8.frame = CGRectMake(w-btnW-20.0, self.btnEnv6.frame.origin.y+self.btnEnv6.frame.size.height+20.0, btnW, 37.0);
    
    [self addSubview:self.labelIDCardType];
    self.labelIDCardType.frame = CGRectMake(20.0, self.btnEnv8.frame.origin.y+self.btnEnv8.frame.size.height+10.0, 200.0, 20.0);
    
    [self addSubview:self.btnIDCardType1];
    self.btnIDCardType1.frame = CGRectMake(20.0, self.labelIDCardType.frame.origin.y+self.labelIDCardType.frame.size.height+10.0, btnW, 37.0);
    
    [self addSubview:self.btnIDCardType2];
    self.btnIDCardType2.frame = CGRectMake(w-btnW-20.0, self.labelIDCardType.frame.origin.y+self.labelIDCardType.frame.size.height+10.0, btnW, 37.0);
    
    [self addSubview:self.btnIDCardType3];
    self.btnIDCardType3.frame = CGRectMake(20.0, self.btnIDCardType2.frame.origin.y+self.btnIDCardType2.frame.size.height+10.0, btnW, 37.0);
    
    [self addSubview:self.btnIDCardType4];
    self.btnIDCardType4.frame = CGRectMake(w-btnW-20.0, self.btnIDCardType2.frame.origin.y+self.btnIDCardType2.frame.size.height+10.0, btnW, 37.0);
    
    [self addSubview:self.btnIDCardType5];
    self.btnIDCardType5.frame = CGRectMake(20, self.btnIDCardType4.frame.origin.y+self.btnIDCardType4.frame.size.height+10.0, btnW, 37.0);
    
    [self addSubview:self.btnOK];
    self.btnOK.frame = CGRectMake((w-100)/2, self.btnIDCardType5.frame.origin.y+self.btnIDCardType5.frame.size.height+30.0, btnW, 44.0);
    
}

- (UILabel* )labelEnv
{
    if(_labelEnv == nil)
    {
        _labelEnv = [[UILabel alloc] init];
        _labelEnv.textColor = [UIColor blackColor];
        _labelEnv.numberOfLines = 1;
        _labelEnv.font = [UIFont fontWithName:@"PingFangSC-Regular" size:15];
        _labelEnv.textAlignment = NSTextAlignmentLeft;
        _labelEnv.text = @"环境类型";
    }
    return  _labelEnv;
}

- (UIButton* )btnEnv1
{
    if(_btnEnv1 == nil)
    {
        _btnEnv1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv1 setTitle:@"会议室带光" forState:UIControlStateNormal];
        [_btnEnv1 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv1.layer.cornerRadius = 5.0;
        _btnEnv1.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv1.layer.borderWidth = 1.0;
        _btnEnv1.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv1 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv1;
}

- (UIButton* )btnEnv2
{
    if(_btnEnv2 == nil)
    {
        _btnEnv2 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv2 setTitle:@"会议室不带光" forState:UIControlStateNormal];
        [_btnEnv2 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv2.layer.cornerRadius = 5.0;
        _btnEnv2.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv2.layer.borderWidth = 1.0;
        _btnEnv2.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv2 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv2;
}

- (UIButton* )btnEnv3
{
    if(_btnEnv3 == nil)
    {
        _btnEnv3 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv3 setTitle:@"走廊" forState:UIControlStateNormal];
        [_btnEnv3 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv3.layer.cornerRadius = 5.0;
        _btnEnv3.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv3.layer.borderWidth = 1.0;
        _btnEnv3.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv3 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv3;
}

- (UIButton* )btnEnv4
{
    if(_btnEnv4 == nil)
    {
        _btnEnv4 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv4 setTitle:@"楼梯间" forState:UIControlStateNormal];
        [_btnEnv4 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv4.layer.cornerRadius = 5.0;
        _btnEnv4.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv4.layer.borderWidth = 1.0;
        _btnEnv4.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv4 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv4;
}

- (UIButton* )btnEnv5
{
    if(_btnEnv5 == nil)
    {
        _btnEnv5 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv5 setTitle:@"1号楼1楼" forState:UIControlStateNormal];
        [_btnEnv5 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv5.layer.cornerRadius = 5.0;
        _btnEnv5.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv5.layer.borderWidth = 1.0;
        _btnEnv5.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv5 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv5;
}

- (UIButton* )btnEnv6
{
    if(_btnEnv6 == nil)
    {
        _btnEnv6 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv6 setTitle:@"户外" forState:UIControlStateNormal];
        [_btnEnv6 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv6.layer.cornerRadius = 5.0;
        _btnEnv6.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv6.layer.borderWidth = 1.0;
        _btnEnv6.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv6 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv6;
}

- (UIButton* )btnEnv7
{
    if(_btnEnv7 == nil)
    {
        _btnEnv7 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv7 setTitle:@"百分号咖啡厅" forState:UIControlStateNormal];
        [_btnEnv7 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv7.layer.cornerRadius = 5.0;
        _btnEnv7.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv7.layer.borderWidth = 1.0;
        _btnEnv7.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv7 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv7;
}

- (UIButton* )btnEnv8
{
    if(_btnEnv8 == nil)
    {
        _btnEnv8 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnEnv8 setTitle:@"星巴克甄选" forState:UIControlStateNormal];
        [_btnEnv8 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnEnv8.layer.cornerRadius = 5.0;
        _btnEnv8.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnEnv8.layer.borderWidth = 1.0;
        _btnEnv8.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnEnv8 addTarget:self action:@selector(clickSelectEnv:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnEnv8;
}

- (UILabel* )labelIDCardType
{
    if(_labelIDCardType == nil)
    {
        _labelIDCardType = [[UILabel alloc] init];
        _labelIDCardType.textColor = [UIColor blackColor];
        _labelIDCardType.numberOfLines = 1;
        _labelIDCardType.font = [UIFont fontWithName:@"PingFangSC-Regular" size:15];
        _labelIDCardType.textAlignment = NSTextAlignmentLeft;
        _labelIDCardType.text = @"证件类型";
    }
    return  _labelIDCardType;
}

- (UIButton* )btnIDCardType1
{
    if(_btnIDCardType1 == nil)
    {
        _btnIDCardType1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnIDCardType1 setTitle:@"黑白" forState:UIControlStateNormal];
        [_btnIDCardType1 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnIDCardType1.layer.cornerRadius = 5.0;
        _btnIDCardType1.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnIDCardType1.layer.borderWidth = 1.0;
        _btnIDCardType1.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnIDCardType1 addTarget:self action:@selector(clickSelectIDCardType:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnIDCardType1;
}

- (UIButton* )btnIDCardType2
{
    if(_btnIDCardType2 == nil)
    {
        _btnIDCardType2 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnIDCardType2 setTitle:@"彩色" forState:UIControlStateNormal];
        [_btnIDCardType2 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnIDCardType2.layer.cornerRadius = 5.0;
        _btnIDCardType2.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnIDCardType2.layer.borderWidth = 1.0;
        _btnIDCardType2.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnIDCardType2 addTarget:self action:@selector(clickSelectIDCardType:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnIDCardType2;
}

- (UIButton* )btnIDCardType3
{
    if(_btnIDCardType3 == nil)
    {
        _btnIDCardType3 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnIDCardType3 setTitle:@"黑白膜" forState:UIControlStateNormal];
        [_btnIDCardType3 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnIDCardType3.layer.cornerRadius = 5.0;
        _btnIDCardType3.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnIDCardType3.layer.borderWidth = 1.0;
        _btnIDCardType3.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnIDCardType3 addTarget:self action:@selector(clickSelectIDCardType:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnIDCardType3;
}

- (UIButton* )btnIDCardType4
{
    if(_btnIDCardType4 == nil)
    {
        _btnIDCardType4 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnIDCardType4 setTitle:@"彩色膜" forState:UIControlStateNormal];
        [_btnIDCardType4 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnIDCardType4.layer.cornerRadius = 5.0;
        _btnIDCardType4.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnIDCardType4.layer.borderWidth = 1.0;
        _btnIDCardType4.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnIDCardType4 addTarget:self action:@selector(clickSelectIDCardType:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnIDCardType4;
}

- (UIButton* )btnIDCardType5
{
    if(_btnIDCardType5 == nil)
    {
        _btnIDCardType5 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnIDCardType5 setTitle:@"翻拍" forState:UIControlStateNormal];
        [_btnIDCardType5 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnIDCardType5.layer.cornerRadius = 5.0;
        _btnIDCardType5.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnIDCardType5.layer.borderWidth = 1.0;
        _btnIDCardType5.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        [_btnIDCardType5 addTarget:self action:@selector(clickSelectIDCardType:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnIDCardType5;
}
- (UIButton* )btnOK
{
    if(_btnOK == nil)
    {
        _btnOK = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOK setTitle:@"保存" forState:UIControlStateNormal];
        [_btnOK setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
        _btnOK.layer.cornerRadius = 5.0;
        _btnOK.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x0297CA"].CGColor;
        _btnOK.layer.borderWidth = 1.0;
        _btnOK.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:15];
        [_btnOK addTarget:self action:@selector(clickOk:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnOK;
}

-(void)clickSelectEnv:(id)sender
{
    [self initBtnEnvData];
    UIButton* btn = (UIButton* )sender;
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    self.selectedEnv = btn.titleLabel.text;
}


-(void)clickSelectIDCardType:(id)sender
{
    [self initBtnIDCardData];
    UIButton* btn = (UIButton* )sender;
    [btn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    self.selectedIDCardType = btn.titleLabel.text;
}

-(void)initBtnEnvData
{
    [self.btnEnv1 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnEnv2 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnEnv3 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnEnv4 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnEnv5 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnEnv6 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnEnv7 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnEnv8 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
}

-(void)initBtnIDCardData
{
    [self.btnIDCardType1 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnIDCardType2 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnIDCardType3 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnIDCardType4 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
    [self.btnIDCardType5 setTitleColor:[UIColor dslc_colorWithHexString:@"0x0297CA"] forState:UIControlStateNormal];
}

-(void)clickOk:(id)sender
{
    if([self.selectedEnv isEqualToString:@""] || [self.selectedIDCardType isEqualToString:@""])
    {
        return;
    }
    
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(selectTypeForSaveLocalOk: IDCardType:)])
        {
            [self.myDelegate selectTypeForSaveLocalOk:self.selectedEnv IDCardType:self.selectedIDCardType];
            [self removeFromSuperview];
        }
    }
}

@end
