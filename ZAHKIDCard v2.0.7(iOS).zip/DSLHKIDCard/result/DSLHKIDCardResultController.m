//
//  DSLHKIDCardResultController.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/21.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "DSLHKIDCardResultController.h"
#import "ResutlItemView.h"
#import "ResultFaceView.h"
#import "UnAntiFakeResultView.h"
#import "UIColor+DSLCHexColor.h"
#import "TotalResultView.h"
#import "ScoreDefineView.h"
#import "DSLHKIDCardBundle.h"
#import "AppDelegate.h"

#define kiPhoneXAll ([UIScreen mainScreen].bounds.size.height == 812 || [UIScreen mainScreen].bounds.size.height == 896)


#define OldVersion_HK_CN    [DSLHKIDCardBundle IDCardBundleString:@"result_title1"]     //高风险
#define OldVersion_TriColor_CN    [DSLHKIDCardBundle IDCardBundleString:@"result_title2"]   //高风险
#define OldVersion_Chip_CN   [DSLHKIDCardBundle IDCardBundleString:@"result_title3"]
#define OldVersion_Highlight_CN   [DSLHKIDCardBundle IDCardBundleString:@"result_title4"]
#define OldVersion_Gradual_CN    [DSLHKIDCardBundle IDCardBundleString:@"result_title5"]
#define OldVersion_SmallFace_CN [DSLHKIDCardBundle IDCardBundleString:@"result_title6"]

#define Tampered_CN [DSLHKIDCardBundle IDCardBundleString:@"result_title7"]
#define FaceSimilarity_CN [DSLHKIDCardBundle IDCardBundleString:@"result_title9"]

#define NewVersion_ImageQuality_CN [DSLHKIDCardBundle IDCardBundleString:@"result_title10"]
#define NewVersion_ColorPrinting_CN [DSLHKIDCardBundle IDCardBundleString:@"result_title11"]
#define NewVersion_LaserFace_CN [DSLHKIDCardBundle IDCardBundleString:@"result_title12"]
#define NewVersion_LaserRedbud_CN [DSLHKIDCardBundle IDCardBundleString:@"result_title13"]

#define Reproduction_CN    [DSLHKIDCardBundle IDCardBundleString:@"result_title64"]

@interface DSLHKIDCardResultController ()<ResutlItemViewDelegate, TotalResultViewDelegate>

@property(nonatomic, strong) UIScrollView* myScrollView;
@property(nonatomic, strong) ResultFaceView* resultFaceView;
@property(nonatomic, strong) UIImageView* imgViewFaceRec;
@property(nonatomic, strong) UILabel* labelAntiFakeResultTip;
@property(nonatomic, strong) UnAntiFakeResultView* unAntiFakeResultView;

@property(nonatomic, strong) UILabel* labelTotalResultTip;
@property(nonatomic, strong) TotalResultView* totalResultView;

@property(nonatomic, strong) UIImageView* imgViewAntiFakePart1Result;
@property(nonatomic, strong) UIImageView* imgViewAntiFakePart2Result;
@property(nonatomic, strong) UILabel* labelOCRResultTip;
@property(nonatomic, strong) UIImageView* imgViewOCRResult;

@property(nonatomic, strong) UIView* viewBk;

@property(nonatomic, strong) UIView* viewMark;
@property(nonatomic, strong) UIView* viewMarkBig;
@property(nonatomic, strong) UIButton* btnOk;
@property(nonatomic, strong) UILabel* labelRecID;

@property(nonatomic, strong) UILabel* labelScore;   //总数分显示

@property(nonatomic, assign) int totalRisks;

@property(nonatomic, strong) NSMutableArray* muArrItems;

@end

@implementation DSLHKIDCardResultController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.muArrItems = [NSMutableArray arrayWithCapacity:5];
    
    //[self testViews];

    [self initViews];
    
}

- (void)testViews
{
    self.recType = DSLHKIDCardTypeApp_2003;
    self.resultInfoModel = [[ResultInfoModel alloc] init];
    self.resultInfoModel.bFaceVerifyValid = NO;
    self.resultInfoModel.bColorPrinting = YES;
    self.resultInfoModel.bFaceSimilarity = YES;
    self.resultInfoModel.bImageQuality = YES;
    self.resultInfoModel.bLaserFace = NO;
    self.resultInfoModel.bLaserRedbud = YES;
    UIImage* img = [UIImage imageNamed:@"test_img_head"];
    self.imgSmallHead = img;
    self.imgFaceRec = img;
    if(self.recType == DSLHKIDCardTypeApp_2003)
    {
       self.imgIDCard = [UIImage imageNamed:@"result_idcardOld_test"];
    }
    else
    {
        self.imgIDCard = [UIImage imageNamed:@"result_idcardOld_test"];
        
    }
    
    self.resultInfoModel.certiType = @"香港身份证";
    self.resultInfoModel.firstName = @"zhang";
    self.resultInfoModel.lastName = @"san";
    self.resultInfoModel.gender = @"男";
    self.resultInfoModel.certiNo = @"134234xdfsdfsd";
    self.resultInfoModel.birthday = @"1023-11-11";
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self performSelector:@selector(delayShowResultFace) withObject:nil afterDelay:1];
    
    [self performSelector:@selector(delayShowImgViewFaceRec) withObject:nil afterDelay:4];
    
    [self performSelector:@selector(delayShowUnAntiFakeResultView) withObject:nil afterDelay:6];
    
    [self performSelector:@selector(showResultItems) withObject:nil afterDelay:8];
    
    [self performSelector:@selector(delayShowOCRResult) withObject:nil afterDelay:self.recType == DSLHKIDCardTypeApp_2018 ? 17+2 : (19+4+2)];
    
}

- (void)delayShowOCRResult
{
    self.labelOCRResultTip.hidden = NO;
    self.viewBk.hidden = NO;
    self.imgViewOCRResult.hidden = NO;
    self.btnOk.hidden = NO;
    self.labelRecID.hidden = NO;
    self.labelScore.hidden = NO;
    
}
- (void)delayShowImgViewFaceRec
{
    self.imgViewFaceRec.hidden = NO;
    float offset = self.imgViewFaceRec.frame.origin.y-50;
    [self.myScrollView setContentOffset:CGPointMake(0.0, offset) animated:YES];
}

- (void)delayShowUnAntiFakeResultView
{
    self.labelTotalResultTip.hidden = NO;
    self.totalResultView.hidden = NO;
}

- (void)delayShowResultFace
{
     [self.resultFaceView delayShowFaceSimilarity];
}
- (void)showResultItems
{
    self.unAntiFakeResultView.hidden = NO;
    
    int count = self.recType == DSLHKIDCardTypeApp_2018 ? 7 : 9;
    for(int i = 0; i < count; ++i)
    {
        ResutlItemView* itmeView = [self.muArrItems objectAtIndex:i];
        [self performSelector:@selector(delayResultItem:) withObject:itmeView afterDelay:i*2];
    }
}

- (void)delayResultItem:(ResutlItemView* )resultItem
{
    resultItem.hidden = NO;
    switch ((int)resultItem.tag) {
        case 0:
            self.imgViewAntiFakePart1Result.hidden = NO;
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [resultItem setResutlItem:self.resultInfoModel.bLaserFace ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:NewVersion_LaserFace_CN Value:self.resultInfoModel.bLaserFace] AllowClick:YES ContentLines:1];
            }
            else
            {
                [resultItem setResutlItem:self.resultInfoModel.bHkOld ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:OldVersion_HK_CN Value:self.resultInfoModel.bHkOld] AllowClick:YES ContentLines:1];
            }
            
            break;
        case 1:
            
            [resultItem setResutlItem:self.resultInfoModel.bFaceSimilarity ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:FaceSimilarity_CN Value:self.resultInfoModel.bFaceSimilarity] AllowClick:YES ContentLines:1];
            
            break;
            
        case 2:
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [resultItem setResutlItem:(self.resultInfoModel.bLaserRedbud || self.resultInfoModel.laserRedbudScore >= 0.5) ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:NewVersion_LaserRedbud_CN Value:(self.resultInfoModel.bLaserRedbud || self.resultInfoModel.laserRedbudScore >= 0.5)] AllowClick:YES ContentLines:1];
            }
            else
            {
                [resultItem setResutlItem:self.resultInfoModel.bChipOld ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:OldVersion_Chip_CN Value:self.resultInfoModel.bChipOld] AllowClick:YES ContentLines:1];
            }
            
            break;
            
        case 3:
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [resultItem setResutlItem:self.resultInfoModel.bColorPrinting ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:NewVersion_ColorPrinting_CN Value:self.resultInfoModel.bColorPrinting] AllowClick:YES ContentLines:1];
            }
            else
            {
                [resultItem setResutlItem:self.resultInfoModel.bHighlight ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:OldVersion_Highlight_CN Value:self.resultInfoModel.bHighlight] AllowClick:YES ContentLines:1];
            }
            
            break;
            
        case 4:
            [resultItem setResutlItem:self.resultInfoModel.bTampered ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:Tampered_CN Value:self.resultInfoModel.bTampered] AllowClick:YES ContentLines:1];
            break;
            
        case 5:
            
            if(self.recType == DSLHKIDCardTypeApp_2003)
            {
                [resultItem setResutlItem:self.resultInfoModel.bGradualOld ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:OldVersion_Gradual_CN Value:self.resultInfoModel.bGradualOld] AllowClick:YES ContentLines:1];
            }
            else
            {
                [resultItem setResutlItem:self.resultInfoModel.bReproduction ? @"result_fail" : @"result_success" Content:[self resultItemChange_CN:Reproduction_CN Value:self.resultInfoModel.bReproduction] AllowClick:YES ContentLines:1];
            }
            
            break;
            
        case 6:
            
            if(self.recType == DSLHKIDCardTypeApp_2003)
            {
                [resultItem setResutlItem:self.resultInfoModel.bTriColorOld ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:OldVersion_TriColor_CN Value:self.resultInfoModel.bTriColorOld] AllowClick:YES ContentLines:1];
            }
            else
            {
                  [resultItem setResutlItem:self.resultInfoModel.bDeep_rtriangle ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:[DSLHKIDCardBundle IDCardBundleString:@"result_title65"] Value:self.resultInfoModel.bDeep_rtriangle] AllowClick:YES ContentLines:1];
            }
            
            break;
            
        case 7:
            
            if(self.recType == DSLHKIDCardTypeApp_2003)
            {
                [resultItem setResutlItem:self.resultInfoModel.bSmallFace ? @"result_success" : @"result_fail" Content:[self resultItemChange_CN:OldVersion_SmallFace_CN Value:self.resultInfoModel.bSmallFace] AllowClick:YES ContentLines:1];
            }
            break;
        case 8:
            if(self.recType == DSLHKIDCardTypeApp_2003)
            {
                [resultItem setResutlItem:self.resultInfoModel.bReproduction ? @"result_fail" : @"result_success" Content:[self resultItemChange_CN:Reproduction_CN Value:self.resultInfoModel.bReproduction] AllowClick:YES ContentLines:1];
            }
            break;

        default:
            break;
    }
    
    [self drawViewMark:(int)resultItem.tag hideTimes:0];
    
    if(self.recType == DSLHKIDCardTypeApp_2018)
    {
        if((int)resultItem.tag == 6)
        {
            [self performSelector:@selector(delayOffsetToBottom) withObject:nil afterDelay:2];
        }
    }
    else
    {
        if((int)resultItem.tag == 8)
        {
            [self performSelector:@selector(delayOffsetToBottom) withObject:nil afterDelay:2];
        }
    }
    
}

- (void)delayOffsetToBottom
{
    float offset = self.myScrollView.contentSize.height-self.view.bounds.size.height;
    [self.myScrollView setContentOffset:CGPointMake(0.0, offset) animated:YES];
}

- (void)initAntiFakePartResult
{
    if(self.recType == DSLHKIDCardTypeApp_2018)
    {
        [self.myScrollView addSubview:self.imgViewAntiFakePart1Result];
        self.imgViewAntiFakePart1Result.frame = CGRectMake((self.view.bounds.size.width-320)/2, self.unAntiFakeResultView.frame.origin.y+self.unAntiFakeResultView.frame.size.height+14, 320, 14+168+14+30+40-22+40+40);
        self.imgViewAntiFakePart1Result.userInteractionEnabled = YES;
        
        ResutlItemView* item1 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, 16, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item1.tag = 0;
        item1.myDelegate = self;
        item1.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item1];
        [self.muArrItems addObject:item1];
        
        ResutlItemView* item2 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item1.frame.origin.y+item1.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item2.tag = 1;
        item2.myDelegate = self;
        item2.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item2];
        [self.muArrItems addObject:item2];
        
        ResutlItemView* item3 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item2.frame.origin.y+item2.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item3.tag = 2;
        item3.myDelegate = self;
        item3.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item3];
        [self.muArrItems addObject:item3];
        
        ResutlItemView* item4 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item3.frame.origin.y+item3.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item4.tag = 3;
        item4.myDelegate = self;
        item4.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item4];
        [self.muArrItems addObject:item4];

        ResutlItemView* item5 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item4.frame.origin.y+item4.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item5.tag = 4;
        item5.myDelegate = self;
        item5.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item5];
        [self.muArrItems addObject:item5];
        
        ResutlItemView* item6 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item5.frame.origin.y+item5.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item6.tag = 5;
        item6.myDelegate = self;
        item6.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item6];
        [self.muArrItems addObject:item6];
        
        ResutlItemView* item7 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item6.frame.origin.y+item6.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item7.tag = 6;
        item7.myDelegate = self;
        item7.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item7];
        [self.muArrItems addObject:item7];
    }
    else
    {
        [self.myScrollView addSubview:self.imgViewAntiFakePart1Result];
        self.imgViewAntiFakePart1Result.frame = CGRectMake((self.view.bounds.size.width-320)/2, self.unAntiFakeResultView.frame.origin.y+self.unAntiFakeResultView.frame.size.height+14, 320, 14+210+14+5*22+40+40);
        self.imgViewAntiFakePart1Result.userInteractionEnabled = YES;
        
        ResutlItemView* item1 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, 16, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item1.tag = 0;
        item1.myDelegate = self;
        item1.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item1];
        [self.muArrItems addObject:item1];
        
        ResutlItemView* item2 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item1.frame.origin.y+item1.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item2.tag = 1;
        item2.myDelegate = self;
        item2.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item2];
        [self.muArrItems addObject:item2];
        
        ResutlItemView* item3 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item2.frame.origin.y+item2.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item3.tag = 2;
        item3.myDelegate = self;
        item3.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item3];
        [self.muArrItems addObject:item3];
        
        ResutlItemView* item4 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item3.frame.origin.y+item3.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item4.tag = 3;
        item4.myDelegate = self;
        item4.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item4];
        [self.muArrItems addObject:item4];
        
        ResutlItemView* item5 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item4.frame.origin.y+item4.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item5.tag = 4;
        item5.myDelegate = self;
        item5.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item5];
        [self.muArrItems addObject:item5];
        
        ////////
        ResutlItemView* item6 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item5.frame.origin.y+item5.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item6.tag = 5;
        item6.myDelegate = self;
        item6.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item6];
        [self.muArrItems addObject:item6];
        
        ResutlItemView* item7 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item6.frame.origin.y+item6.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item7.tag = 6;
        item7.myDelegate = self;
        item7.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item7];
        [self.muArrItems addObject:item7];
        
        ResutlItemView* item8 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item7.frame.origin.y+item7.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item8.tag = 7;
        item8.myDelegate = self;
        item8.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item8];
        [self.muArrItems addObject:item8];
        
        ResutlItemView* item9 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item8.frame.origin.y+item8.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 22.0)];
        item9.tag = 8;
        item9.myDelegate = self;
        item9.hidden = YES;
        [self.imgViewAntiFakePart1Result addSubview:item9];
        [self.muArrItems addObject:item9];
    }
}

- (void)setTotalResultData
{
    NSString* strVideoQuality = [DSLHKIDCardBundle IDCardBundleString:@"result_title14"];
    
    if(self.resultInfoModel.qualityScore >= self.resultInfoModel.qualitythreshold)
    {
        strVideoQuality = [DSLHKIDCardBundle IDCardBundleString:@"result_title15"];
    }
    
    NSString* strTotalScore = @"";
    UIColor* color = [UIColor redColor];
    
    int levelRisk = 0;
    if(self.resultInfoModel.authenticity < self.resultInfoModel.low_threshold)
    {
        levelRisk = -1;
        strTotalScore = [NSString stringWithFormat:@"%.2f(%@)", self.resultInfoModel.authenticity, [DSLHKIDCardBundle IDCardBundleString:@"result_title16"]];
        color = [UIColor dslc_colorWithHexString:@"0xF44336"];
    }
    else if(self.resultInfoModel.authenticity > self.resultInfoModel.high_threshold)
    {
        levelRisk = 1;
        strTotalScore = [NSString stringWithFormat:@"%.2f(%@)", self.resultInfoModel.authenticity, [DSLHKIDCardBundle IDCardBundleString:@"result_title17"]];
        color = [UIColor dslc_colorWithHexString:@"0x13D46B"];
    }
    else
    {
        strTotalScore = [NSString stringWithFormat:@"%.2f(%@)", self.resultInfoModel.authenticity, [DSLHKIDCardBundle IDCardBundleString:@"result_title18"]];
        color = [UIColor dslc_colorWithHexString:@"0xFD9312"];
    }
    
    if(self.resultInfoModel.bImageQuality)
    {
        self.totalResultView.frame = CGRectMake((self.view.bounds.size.width-320)/2, self.labelTotalResultTip.frame.origin.y+self.labelTotalResultTip.frame.size.height+12, 320, 87+30);
    }
    
    [self.totalResultView setTotalResult:strTotalScore VideoQuality:strVideoQuality TotalScoreColor:color IsShowTipText: !self.resultInfoModel.bImageQuality LevelRisk:levelRisk];
}

- (void)initViews
{
    [self.view addSubview:self.myScrollView];
    [self.myScrollView addSubview:self.resultFaceView];
    self.myScrollView.backgroundColor = [UIColor clearColor];
    [self.myScrollView addSubview:self.imgViewFaceRec];
    
    [self.myScrollView addSubview:self.labelTotalResultTip];
    self.labelTotalResultTip.frame = CGRectMake(self.imgViewFaceRec.frame.origin.x, self.imgViewFaceRec.frame.origin.y+self.imgViewFaceRec.frame.size.height+20, self.imgViewFaceRec.frame.size.width, 26.0);
    
    [self.myScrollView addSubview:self.totalResultView];
    
    [self setTotalResultData];
   
    
    [self.myScrollView addSubview:self.unAntiFakeResultView];
    
    [self initAntiFakePartResult];
    
    [self.myScrollView addSubview:self.labelOCRResultTip];
    self.labelOCRResultTip.frame = CGRectMake(self.imgViewAntiFakePart1Result.frame.origin.x, self.imgViewAntiFakePart1Result.frame.origin.y+self.imgViewAntiFakePart1Result.frame.size.height+20, self.imgViewAntiFakePart1Result.frame.size.width, 26.0);
    
    [self.myScrollView addSubview:self.viewBk];
    self.viewBk.frame = CGRectMake(self.labelOCRResultTip.frame.origin.x-8, self.labelOCRResultTip.frame.origin.y+12, 146, 10.0);
    [self.myScrollView sendSubviewToBack:self.viewBk];
    
    [self.myScrollView addSubview:self.imgViewOCRResult];
    self.imgViewOCRResult.frame = CGRectMake((self.view.bounds.size.width-320)/2, self.labelOCRResultTip.frame.origin.y+self.labelOCRResultTip.frame.size.height+18, 320, 234+40+10);
    self.imgViewOCRResult.userInteractionEnabled = YES;
    self.imgViewOCRResult.hidden = YES;
    
//    self.imgViewOCRResult.layer.borderWidth = 1;
//    self.imgViewOCRResult.layer.borderColor = [UIColor redColor].CGColor;
    
    ResutlItemView* item6 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, 16, self.imgViewOCRResult.frame.size.width, 22.0)];
    item6.tag = 6;
    
    int idCardLineNum = 1;
    if([self isCurrentLanguageEn])
    {
        idCardLineNum = 2;
    }
    
    [item6 setResutlItem:@"result_success" Content:[NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title19"], self.resultInfoModel.certiType] AllowClick:NO ContentLines:idCardLineNum];
    [self.imgViewOCRResult addSubview:item6];
    [self.muArrItems addObject:item6];
    
    ResutlItemView* item7 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item6.frame.origin.y+item6.frame.size.height+20, self.imgViewOCRResult.frame.size.width, 22.0)];
    item7.tag = 6;
    [item7 setResutlItem:@"result_success" Content:[NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title20"], self.resultInfoModel.firstName] AllowClick:NO ContentLines:1];
    [self.imgViewOCRResult addSubview:item7];
    [self.muArrItems addObject:item7];
    
    ResutlItemView* item8 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item7.frame.origin.y+item7.frame.size.height+20, self.imgViewOCRResult.frame.size.width, 22.0)];
    item8.tag = 6;
    [item8 setResutlItem:@"result_success" Content:[NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title21"], self.resultInfoModel.gender] AllowClick:NO ContentLines:1];
    [self.imgViewOCRResult addSubview:item8];
    [self.muArrItems addObject:item8];
    
    ResutlItemView* item9 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item8.frame.origin.y+item8.frame.size.height+20, self.imgViewOCRResult.frame.size.width, 22.0)];
    item9.tag = 6;
    [item9 setResutlItem:@"result_success" Content:[NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title22"], self.resultInfoModel.certiNo] AllowClick:NO ContentLines:1];
    [self.imgViewOCRResult addSubview:item9];
    [self.muArrItems addObject:item9];
    
    ResutlItemView* item10 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item9.frame.origin.y+item9.frame.size.height+20, self.imgViewOCRResult.frame.size.width, 22.0)];
    item10.tag = 6;
    [item10 setResutlItem:@"result_success" Content:[NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title23"], self.resultInfoModel.birthday] AllowClick:NO ContentLines:1];
    [self.imgViewOCRResult addSubview:item10];
    [self.muArrItems addObject:item10];
    
    ResutlItemView* item11 = [[ResutlItemView alloc] initWithFrame:CGRectMake(0.0, item10.frame.origin.y+item10.frame.size.height+20, self.imgViewOCRResult.frame.size.width, 22.0)];
    item11.tag = 7;
    
    if(self.resultInfoModel.fingerOcclusionNum == nil || [self.resultInfoModel.fingerOcclusionNum isEqualToString:@""])
    {
            [item11 setResutlItem:@"result_success" Content:[NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title68"], [DSLHKIDCardBundle IDCardBundleString:@"result_title44"]] AllowClick:NO ContentLines:1];
    }
    else
    {
        [item11 setResutlItem:@"result_success" Content:[NSString stringWithFormat:@"%@: %@(%@)", [DSLHKIDCardBundle IDCardBundleString:@"result_title68"], [DSLHKIDCardBundle IDCardBundleString:@"result_title43"], self.resultInfoModel.fingerOcclusionNum] AllowClick:NO ContentLines:2];
    }

    [self.imgViewOCRResult addSubview:item11];
    [self.muArrItems addObject:item11];
    
    [self.myScrollView addSubview:self.btnOk];
    self.btnOk.frame = CGRectMake((self.view.bounds.size.width-320)/2, self.imgViewOCRResult.frame.origin.y+self.imgViewOCRResult.frame.size.height+30, 320, 40.0);
    
    [self.myScrollView addSubview:self.labelRecID];
    self.labelRecID.frame = CGRectMake(((self.myScrollView.bounds.size.width-200)/2), self.btnOk.frame.origin.y+self.btnOk.frame.size.height+10, 200, 40);
    
 
    
    
    [self.imgViewFaceRec addSubview:self.viewMark];
    [self.imgViewFaceRec addSubview:self.viewMarkBig];
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

- (UIScrollView* )myScrollView
{
    if(_myScrollView == nil)
    {
        _myScrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        _myScrollView.backgroundColor = [UIColor whiteColor];
    
        _myScrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.recType == DSLHKIDCardTypeApp_2018 ? 1400-60+20+30+30+40+40+40+40: 1400-60+20+42+30+50*2+20+40+40+40+40);
        _myScrollView.showsVerticalScrollIndicator = NO;
        _myScrollView.showsHorizontalScrollIndicator = NO;
//        _myScrollView.layer.borderColor = [UIColor redColor].CGColor;
//        _myScrollView.layer.borderWidth = 1;
    }
    
    return _myScrollView;
}

-(ResultFaceView* )resultFaceView
{
    if(_resultFaceView == nil)
    {
        float addHeight = -22;
        if(kiPhoneXAll)
        {
            addHeight = -22;
        }
        _resultFaceView = [[ResultFaceView alloc] initWithFrame:CGRectMake(0.0, addHeight, self.view.bounds.size.width, 490) IDCardHead:self.imgSmallHead FaceHead:self.imgFaceRec FaceSimilarity:self.resultInfoModel.similarity FaceVerifyValid:self.resultInfoModel.bFaceVerifyValid];
    }
    
    return _resultFaceView;
}

- (UIImageView* )imgViewFaceRec
{
    if(_imgViewFaceRec == nil)
    {
        _imgViewFaceRec = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-320)/2, 340, 320, 200)];
        _imgViewFaceRec.image = self.imgIDCard;
        _imgViewFaceRec.layer.cornerRadius = 5;
        _imgViewFaceRec.layer.masksToBounds = YES;
        _imgViewFaceRec.hidden = YES;
    }
    
    return _imgViewFaceRec;
}

- (TotalResultView* )totalResultView
{
    if(_totalResultView == nil)
    {
        _totalResultView = [[TotalResultView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-320)/2, self.labelTotalResultTip.frame.origin.y+self.labelTotalResultTip.frame.size.height+12, 320, 107+30)];
        _totalResultView.hidden = YES;
        _totalResultView.myDelegate = self;
    }
    
    return _totalResultView;
}

- (UnAntiFakeResultView* )unAntiFakeResultView
{
    if(_unAntiFakeResultView == nil)
    {
        _unAntiFakeResultView = [[UnAntiFakeResultView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-320)/2, self.totalResultView.frame.origin.y+self.totalResultView.frame.size.height+18, 320, 30) HeightRisk:[self getHeightRisk] LowRisk:[self getLowRisk] totalRisks:self.totalRisks];
        _unAntiFakeResultView.hidden = YES;
    }
    return _unAntiFakeResultView;
}

- (UIImageView* )imgViewAntiFakePart1Result
{
    if(_imgViewAntiFakePart1Result == nil)
    {
        _imgViewAntiFakePart1Result = [[UIImageView alloc] init];
        _imgViewAntiFakePart1Result.image = [UIImage imageNamed:@"result_white_bg1"];
        _imgViewAntiFakePart1Result.hidden = YES;
        
    }
    return _imgViewAntiFakePart1Result;
}

- (UIImageView* )imgViewAntiFakePart2Result
{
    if(_imgViewAntiFakePart2Result == nil)
    {
        _imgViewAntiFakePart2Result = [[UIImageView alloc] init];
        _imgViewAntiFakePart2Result.image = [UIImage imageNamed:@"result_white_low_drange_bg"];
        _imgViewAntiFakePart2Result.hidden = YES;
        
    }
    return _imgViewAntiFakePart2Result;
}

-(UIView* )viewBk
{
    if(_viewBk == nil)
    {
        _viewBk = [[UIView alloc] init];
        _viewBk.backgroundColor = [UIColor dslc_colorWithHexString:@"0x02A6CA"];
        _viewBk.alpha = 0.18;
        _viewBk.hidden = YES;
    }
    
    return _viewBk;
}

- (UILabel* )labelTotalResultTip
{
    if(_labelTotalResultTip == nil)
    {
        _labelTotalResultTip = [[UILabel alloc] init];
        _labelTotalResultTip.textColor = [UIColor blackColor];
        _labelTotalResultTip.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:20];
        _labelTotalResultTip.textAlignment = NSTextAlignmentLeft;
        _labelTotalResultTip.text = [NSString stringWithFormat:@"%@:", [DSLHKIDCardBundle IDCardBundleString:@"result_title24"]];
        _labelTotalResultTip.hidden = YES;
    }
    return _labelTotalResultTip;
}

- (UILabel* )labelOCRResultTip
{
    if(_labelOCRResultTip == nil)
    {
        _labelOCRResultTip = [[UILabel alloc] init];
        _labelOCRResultTip.textColor = [UIColor blackColor];
        _labelOCRResultTip.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:20];
        _labelOCRResultTip.textAlignment = NSTextAlignmentLeft;
        _labelOCRResultTip.text = [NSString stringWithFormat:@"%@:", [DSLHKIDCardBundle IDCardBundleString:@"result_title25"]];
        _labelOCRResultTip.hidden = YES;
    }
    return _labelOCRResultTip;
}

- (UILabel* )labelScore
{
    if(_labelScore == nil)
    {
        _labelScore = [[UILabel alloc] init];
        _labelScore.textColor = [UIColor blackColor];
        _labelScore.font = [UIFont fontWithName:@"PingFangSC-Regular" size:20];
        _labelScore.textAlignment = NSTextAlignmentCenter;
        
        NSString* str =  [NSString stringWithFormat:@"%@: %.2f", [DSLHKIDCardBundle IDCardBundleString:@"result_title26"], self.resultInfoModel.authenticity];
        UIColor* color = [UIColor orangeColor];
        if(self.resultInfoModel.authenticity < self.resultInfoModel.low_threshold)
        {
            color = [UIColor redColor];
        }
        else if(self.resultInfoModel.authenticity >= self.resultInfoModel.high_threshold)
        {
             color = [UIColor greenColor];
        }
        
        NSMutableAttributedString* mAttribute = [[NSMutableAttributedString alloc] initWithString:str];
        [mAttribute addAttribute:NSForegroundColorAttributeName
                           value:[UIColor blackColor]
                           range:NSMakeRange(0, 4)];
        [mAttribute addAttribute:NSForegroundColorAttributeName
                           value:color
                           range:NSMakeRange(4, str.length-4)];
        _labelScore.attributedText = mAttribute;
        
        _labelScore.hidden = YES;
    }
    return _labelScore;
}

- (UILabel* )labelRecID
{
    if(_labelRecID == nil)
    {
        _labelRecID = [[UILabel alloc] init];
        _labelRecID.textColor = [UIColor blackColor];//[UIColor dslc_colorWithHexString:@"0xF3F3F3"];
        _labelRecID.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelRecID.textAlignment = NSTextAlignmentCenter;
        _labelRecID.text = [NSString stringWithFormat:@"%@: %@",[DSLHKIDCardBundle IDCardBundleString:@"result_title27"], self.recID];
        _labelRecID.hidden = YES;
    }
    return _labelRecID;
}

- (UIImageView* )imgViewOCRResult
{
    if(_imgViewOCRResult == nil)
    {
        _imgViewOCRResult = [[UIImageView alloc] init];
        _imgViewOCRResult.image = [UIImage imageNamed:@"result_white_bg1"];
        
    }
    return _imgViewOCRResult;
}

- (UIButton* )btnOk
{
    if(_btnOk == nil)
    {
        _btnOk = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOk setTitle:[DSLHKIDCardBundle IDCardBundleString:@"result_title28"] forState:UIControlStateNormal];
        [_btnOk addTarget:self action:@selector(clickOk:) forControlEvents:UIControlEventTouchUpInside];
        [_btnOk setTitleColor:[UIColor dslc_colorWithHexString:@"0xFFFFFF"] forState:UIControlStateNormal];
        [_btnOk setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
        _btnOk.layer.cornerRadius = 20.0;
        _btnOk.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
        _btnOk.hidden = NO;
        
    }
    return  _btnOk;
}

- (UIView* )viewMark
{
    if(_viewMark == nil)
    {
        _viewMark = [[UIView alloc] init];
        _viewMark.layer.borderColor = [UIColor dslc_colorWithHexString:@"0xFFEB74"].CGColor;
        _viewMark.layer.borderWidth = 2;
        _viewMark.layer.cornerRadius = 5;
        _viewMark.layer.masksToBounds = YES;
        _viewMark.hidden = YES;
        //_viewMark.frame = CGRectMake(320.0/1000.0 * 734.0, 200.0/630.0*364.0, 320.0/1000.0*100.0, 200.0/630.0*138.0);
    }
    
    return _viewMark;
}

- (UIView* )viewMarkBig
{
    if(_viewMarkBig == nil)
    {
        _viewMarkBig = [[UIView alloc] init];
        _viewMarkBig.layer.borderColor = [UIColor dslc_colorWithHexString:@"0xFFEB74"].CGColor;
        _viewMarkBig.layer.borderWidth = 2;
        _viewMarkBig.layer.cornerRadius = 5;
        _viewMarkBig.layer.masksToBounds = YES;
        _viewMarkBig.hidden = YES;
        //_viewMark.frame = CGRectMake(320.0/1000.0 * 734.0, 200.0/630.0*364.0, 320.0/1000.0*100.0, 200.0/630.0*138.0);
    }
    
    return _viewMarkBig;
}
- (void)clickOk:(id)sender
{

    [[AppDelegate sharedInstance] gotoHKIDCard_MCV];
    //[[AppDelegate sharedInstance] gotoMCVVc];
}

- (void)clickResultItem:(ResutlItemView *)resultItemView Tag:(int)tag
{
    for(int i = 0; i < [self.muArrItems count]; ++i)
    {
        ResutlItemView* tmpItem = [self.muArrItems objectAtIndex:i];
        if(resultItemView != tmpItem)
        {
            [tmpItem resetStatus:@"YES"];
        }
    }
    
    [self drawViewMark:tag hideTimes:1];
    
}

- (NSString* )getHeightRisk
{
    NSMutableString* heightRisk = [NSMutableString stringWithFormat:@""];
    if(self.resultInfoModel == nil)
    {
        return [DSLHKIDCardBundle IDCardBundleString:@"result_title29"];
    }
    
    if(self.recType == DSLHKIDCardTypeApp_2018)
    {
        if(!self.resultInfoModel.bLaserFace)
        {
            [heightRisk appendString:NewVersion_LaserFace_CN];
            self.totalRisks++;
        }
        
        if(!self.resultInfoModel.bFaceSimilarity)
        {
            [heightRisk appendFormat:@",%@", FaceSimilarity_CN];
            self.totalRisks++;
        }
        
        if(!self.resultInfoModel.bColorPrinting)
        {
            [heightRisk appendFormat:@",%@", NewVersion_ColorPrinting_CN];
            self.totalRisks++;
        }
        
        if(!self.resultInfoModel.bImageQuality)
        {
            [heightRisk appendString:NewVersion_ImageQuality_CN];
            self.totalRisks++;
        }
    }
    else
    {
        if(!self.resultInfoModel.bFaceSimilarity)
        {
            [heightRisk appendFormat:@",%@", FaceSimilarity_CN];
            self.totalRisks++;
        }
        
        if(!self.resultInfoModel.bHkOld)
        {
            [heightRisk appendString:OldVersion_HK_CN];
            self.totalRisks++;
        }
        
        if(!self.resultInfoModel.bTriColorOld)
        {
            [heightRisk appendFormat:@",%@", OldVersion_TriColor_CN];
            self.totalRisks++;
        }
    }
    
    return heightRisk;
}

- (NSString* )getLowRisk
{
    NSMutableString* lowRisk = [NSMutableString stringWithFormat:@""];
    if(self.resultInfoModel == nil)
    {
        return [DSLHKIDCardBundle IDCardBundleString:@"result_title30"];
    }
    
    if(self.recType == DSLHKIDCardTypeApp_2018)
    {
        if(!(self.resultInfoModel.bLaserRedbud || self.resultInfoModel.laserRedbudScore >= 0.5))
        //if(!self.resultInfoModel.bLaserRedbud)
        {
            [lowRisk appendString:NewVersion_LaserRedbud_CN];
            self.totalRisks++;
        }
        
    }
    else
    {
        if(!self.resultInfoModel.bChipOld)
        {
            [lowRisk appendString:OldVersion_Chip_CN];
            self.totalRisks++;
        }
        if(!self.resultInfoModel.bHighlight)
        {
            [lowRisk appendFormat:@",%@", OldVersion_Highlight_CN];
            self.totalRisks++;
        }
        if(!self.resultInfoModel.bGradualOld)
        {
            [lowRisk appendFormat:@",%@", OldVersion_Gradual_CN];
            self.totalRisks++;
        }
//        if(!self.resultInfoModel.bImageQualityOld)
//        {
//            [lowRisk appendFormat:@",%@", OldVersion_ImageQuality_CN];
//            self.totalRisks++;
//        }
    }
    
  
    return lowRisk;
}

- (NSString* )resultItemChange_CN:(NSString* )key Value:(BOOL)val
{
    NSString* itemCN = @"";
    if([key isEqualToString:NewVersion_ColorPrinting_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", NewVersion_ColorPrinting_CN,val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:[DSLHKIDCardBundle IDCardBundleString:@"result_title9"]])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title9"], val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:NewVersion_LaserFace_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", NewVersion_LaserFace_CN,val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:NewVersion_LaserRedbud_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", NewVersion_LaserRedbud_CN,val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:[DSLHKIDCardBundle IDCardBundleString:@"result_title19"]])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title19"], val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:OldVersion_HK_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", OldVersion_HK_CN, val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:OldVersion_TriColor_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", OldVersion_TriColor_CN, val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:OldVersion_Chip_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", OldVersion_Chip_CN, val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:OldVersion_Highlight_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", OldVersion_Highlight_CN, val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:OldVersion_Gradual_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", OldVersion_Gradual_CN, val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:Tampered_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", Tampered_CN,val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title66"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title67"]];
    }
    else if([key isEqualToString:OldVersion_SmallFace_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", OldVersion_SmallFace_CN,val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title33"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
    }
    else if([key isEqualToString:Reproduction_CN])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", Reproduction_CN,val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title43"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title44"]];
    }
    else if([key isEqualToString:[DSLHKIDCardBundle IDCardBundleString:@"result_title65"]])
    {
        itemCN = [NSString stringWithFormat:@"%@:  %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title65"], val ? [DSLHKIDCardBundle IDCardBundleString:@"result_title31"] : [DSLHKIDCardBundle IDCardBundleString:@"result_title32"]];
    }
    
    
    
    return itemCN;
}

- (void)drawViewMark:(int)itemIndex hideTimes:(int)times
{
    CGRect r;
    
    if(self.recType == DSLHKIDCardTypeApp_2018)
    {
        switch (itemIndex)
        {
            case 0: //鐳射人臉
            {
                r = CGRectMake(320.0/1000.0 * 734.0, 200.0/630.0*364.0, 320.0/1000.0*100.0, 200.0/630.0*138.0);
            }
                break;
            case 1: //
            {
                r = CGRectMake(320.0/1000.0 * 734.0, 200.0/630.0*364.0, 320.0/1000.0*100.0, 200.0/630.0*138.0);
                
                self.viewMarkBig.frame = CGRectMake(320.0/1000.0 * 9.0, 200.0/630.0*240.0, 320.0/1000.0*350.0, 200.0/630.0*350.0);
                self.viewMarkBig.hidden = NO;
                [self performSelector:@selector(delayHideViewMarkBig) withObject:nil afterDelay:0.9];
            }
                break;
            case 2: //鐳射花标
            {
                r = CGRectMake(320.0/1000.0 * 285.0, 200.0/630.0*370.0, 320.0/1000.0*75.0, 200.0/630.0*80.0);
            }
                break;
            case 3:
            case 4:
            {
                r = CGRectMake(1, 1, 320-2, 200-2);
            }
                break;
                
            default:
                r = CGRectMake(1, 1, 320-2, 200-2);
                break;
        }
    }
    else
    {
        switch (itemIndex)
        {
            case 0: //动感印刷
            {
                r = CGRectMake(320.0/800.0 * 25.0, 200.0/510.0*309.0, 320.0/800.0*177.0, 200.0/510.0*124.0);
            }
                break;
            case 1: //人脸比对
            {
                r = CGRectMake(320.0/800.0 * 25.0, 200.0/510.0*309.0, 320.0/800.0*177.0, 200.0/510.0*124.0);
                //r = CGRectMake(320.0/800.0 * 21.0, 200.0/510.0*175.0, 320.0/800.0*40.0, 200.0/510.0*106.0);
                
                self.viewMarkBig.frame = CGRectMake(320.0/800.0 * 544, 200.0/510.0*153, 320.0/800.0*205, 200.0/510.0*263);
                self.viewMarkBig.hidden = NO;
                [self performSelector:@selector(delayHideViewMarkBig) withObject:nil afterDelay:0.9];
            }
                break;
            case 2: //特征匹配
            {
                r = CGRectMake(320.0/800.0 * 71.0, 200.0/510.0*167.0, 320.0/800.0*135.0, 200.0/510.0*135.0);
            }
                break;
            case 3: //材質反光
                 r = CGRectMake(1, 1, 320-2, 200-2);
                break;
            case 4://是否被篡改
            {
                r = CGRectMake(1, 1, 320-2, 200-2);
            }
                break;
            case 5://渐变色背景
            {
                 r = CGRectMake(320.0/800.0 * 730.0, 200.0/510.0*174.0, 320.0/800.0*50.0, 200.0/510.0*230.0);
            }
                break;
            case 6: //变色油墨
            {
                r = CGRectMake(320.0/800.0 * 21.0, 200.0/510.0*175.0, 320.0/800.0*40.0, 200.0/510.0*106.0);
                
                //                self.viewMarkBig.frame = CGRectMake(320.0/1000.0 * 9.0, 200.0/630.0*240.0, 320.0/1000.0*350.0, 200.0/630.0*350.0);
                //                self.viewMarkBig.hidden = NO;
                //                [self performSelector:@selector(delayHideViewMarkBig) withObject:nil afterDelay:0.9];
            }
                break;
            case 7:
                r = CGRectMake(320.0/800.0 * 25.0, 200.0/510.0*309.0, 320.0/800.0*177.0, 200.0/510.0*124.0);
                break;
            default:
                r = CGRectMake(1, 1, 320-2, 200-2);
                break;
        }
    }
    
    
    
    self.viewMark.frame = r;
    self.viewMark.hidden = NO;
    //if(times > 0)
    {
        [self performSelector:@selector(delayHideViewMark) withObject:nil afterDelay:1.8];
    }

}

- (void)delayHideViewMark
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayHideViewMark) object:nil];
    self.viewMark.hidden = YES;
    //self.viewMarkBig.hidden = YES;
}

- (void)delayHideViewMarkBig
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayHideViewMarkBig) object:nil];
    //self.viewMark.hidden = YES;
    self.viewMarkBig.hidden = YES;
}

#pragma mark -TotalResultViewDelegate methods
- (void)clickTotalResultViewExplain
{
    [ScoreDefineView showScoreDefine:self.resultInfoModel.low_threshold MediumScore:self.resultInfoModel.low_threshold HighScore:self.resultInfoModel.high_threshold];
}
@end
