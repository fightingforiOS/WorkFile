//
//  DSLMCVResultFailView.m
//
//
//  Created by chenliqun on 2018/12/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import "DSLMCVResultFailView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLMCVIDCardBundle.h"
@interface DSLMCVResultFailView()
@property(nonatomic, strong) UILabel* labelTitle;
@property(nonatomic, strong) UILabel* labelDes;
@property(nonatomic,strong)UIButton *btnOk;
@property(nonatomic,strong)UIButton *btnViewGuide;

@end

@implementation DSLMCVResultFailView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    self.backgroundColor = [UIColor whiteColor];
    self.layer.cornerRadius = 8.0;
    [self addSubview:self.labelTitle];
    self.labelTitle.frame = CGRectMake(0.0, 39, self.frame.size.width, 28.0);
    [self addSubview:self.labelDes];
    if([DSLMCVIDCardBundle isChineseLanguage])
    {
        self.labelDes.frame = CGRectMake(0.0, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+8.0, self.frame.size.width, 20.0);
    }
    else
    {
        self.labelDes.frame = CGRectMake(0.0, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+8.0, self.frame.size.width, 50.0);
    }
    [self addSubview:self.btnOk];
    self.btnOk.frame = CGRectMake((self.frame.size.width-270)/2, self.labelDes.frame.origin.y+self.labelDes.frame.size.height+30.0, 270, 70);
    [self addSubview:self.btnViewGuide];
    self.btnViewGuide.frame = CGRectMake((self.frame.size.width-64.0)/2, self.btnOk.frame.origin.y+self.btnOk.frame.size.height+0.0, 64.0, 20);
    
}

- (void)showResultFailView:(DSLMCVIDCardRecFailType)failType
{
    
    switch (failType) {

        case DSLMCVIDCardRecFailType_Default: //普通错误
            
            self.labelTitle.text = [DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title7"];
            self.labelDes.text = [DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title8"];
        
            break;
        case DSLMCVIDCardRecFailType_OverTime: //超时错误

            self.labelTitle.text = [DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title3"];
            self.labelDes.text = [DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title4"];
            break;
        case DSLMCVIDCardRecFailType_LostObject: //失去目标错误
            
            self.labelTitle.text = [DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title5"];
            self.labelDes.text = [DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title6"];
            break;
       
        default:
            break;
    }
    
    self.hidden = NO;
}

- (void)delayClickOk
{
    [self clickOk:nil];
}

- (UILabel* )labelTitle
{
    if (_labelTitle == nil) {
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.font = [UIFont fontWithName:@"PingFangSC-Medium" size:24];
        _labelTitle.text = @"";
        
    }
    return _labelTitle;
}

- (UILabel* )labelDes
{
    if (_labelDes == nil) {
        _labelDes = [[UILabel alloc] init];
        _labelDes.textAlignment = NSTextAlignmentCenter;
        _labelDes.textColor = [UIColor dslc_colorWithHexString:@"#130A31" alpha:0.5];
        _labelDes.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _labelDes.text = @"";
        _labelDes.lineBreakMode = NSLineBreakByWordWrapping;
        _labelDes.numberOfLines = 0;
        
    }
    return _labelDes;
}

- (UIButton* )btnOk
{
    if(_btnOk == nil)
    {
        _btnOk = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOk setTitle:[DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title1"] forState:UIControlStateNormal];
        [_btnOk addTarget:self action:@selector(clickOk:) forControlEvents:UIControlEventTouchUpInside];
        [_btnOk setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnOk setBackgroundImage:[UIImage imageNamed:@"mcv_show_end_btn_normal"] forState:UIControlStateNormal];
        _btnOk.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _btnOk.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        _btnOk.contentEdgeInsets = UIEdgeInsetsMake(-24, 0, 0, 0);
    }
    return  _btnOk;
}

- (UIButton* )btnViewGuide
{
    if(_btnViewGuide == nil)
    {
        _btnViewGuide = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnViewGuide setTitle:[DSLMCVIDCardBundle IDCardBundleString:@"result_fail_title2"] forState:UIControlStateNormal];
        [_btnViewGuide addTarget:self action:@selector(clickGuide:) forControlEvents:UIControlEventTouchUpInside];
        [_btnViewGuide setTitleColor:[UIColor dslc_colorWithHexString:@"#0266FF"] forState:UIControlStateNormal];
        _btnViewGuide.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
    }
    return  _btnViewGuide;
}

- (void)clickGuide:(id)sender
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayClickOk) object:nil];
       
       self.hidden = YES;
       if(self.myDelegate)
       {
           if([self.myDelegate respondsToSelector:@selector(clickGuide)])
           {
               [self.myDelegate clickGuide];
           }
       }
}
- (void)clickOk:(id)sender
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(delayClickOk) object:nil];
    
    self.hidden = YES;
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(clickFailOK)])
        {
            [self.myDelegate clickFailOK];
        }
    }
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

@end
