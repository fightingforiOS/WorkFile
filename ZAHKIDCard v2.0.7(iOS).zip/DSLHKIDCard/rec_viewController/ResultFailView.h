//
//  ResultFailView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2018/12/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLHKIDCardEnumType.h"
NS_ASSUME_NONNULL_BEGIN

@protocol ResultFailViewDelegate <NSObject>

- (void)clickFailOK;

- (void)clickGuide;
@end

@interface ResultFailView : UIView

@property(nonatomic, assign) id<ResultFailViewDelegate> _Nullable myDelegate;

- (void)showResultFailView:(DSLHKIDCardRecFailType)failType;

@end

NS_ASSUME_NONNULL_END
