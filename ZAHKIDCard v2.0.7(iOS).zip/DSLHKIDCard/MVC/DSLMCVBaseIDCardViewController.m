//
//  DSLMCVBaseIDCardViewController.m
//  DSLMCVIDCard
//
//  Created by chenliqun on 2019/7/15.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "DSLMCVBaseIDCardViewController.h"

#import <AssetsLibrary/AssetsLibrary.h>
#import <CoreImage/CoreImage.h>

#import <DSLHKIDCard/DSLHKIDCard.h>
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardConfig.h"
#import <CoreMotion/CoreMotion.h>

@interface DSLMCVBaseIDCardViewController ()<AVCaptureVideoDataOutputSampleBufferDelegate>

@property(nonatomic,strong)AVCaptureDeviceInput *captureInput;
@property(nonatomic,strong)AVCaptureVideoDataOutput *captureVideoDataOutput; // video output
@property(nonatomic, readwrite) AVCaptureVideoOrientation videoOrientation;

@property(nonatomic, strong) dispatch_queue_t videoProcessQueue;

//摄像头捕捉的显示层
@property(nonatomic,strong)AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;

//当前视频帧数据
@property(atomic, strong) NSData* curImgData;


//半透明黑色遮罩
@property (nonatomic, strong) CAShapeLayer * maskLayer;
@property(nonatomic, strong) UIView* maskBgView;

//遮罩层颜色，默认黑色半透明
@property (nonatomic, strong) UIColor *maskColor;


@end

@implementation DSLMCVBaseIDCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.videoProcessQueue = dispatch_queue_create("queue2019", NULL);
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.maskColor = [UIColor colorWithWhite: 0 alpha: 0.8];
    CGSize size = self.view.bounds.size;
    
    [self initIDCardToRect];
    
    //设置拍摄有效区域
    self.effectiveRect = CGRectMake(0, (size.height-size.width)/2, size.width, size.width);
    
    [self.view.layer insertSublayer:self.captureVideoPreviewLayer atIndex:0];
    
    [self.view addSubview:self.maskBgView];
    
    [self.view addSubview:self.imgViewRecStatus];
    self.imgViewRecStatus.hidden = NO;
    
    [self setupEffectiveRect];
    
    [self setupCamera];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)initIDCardToRect
{
    CGSize size = self.view.bounds.size;
    float x = size.width * 0.05;
    self.idCardToRect = CGRectMake(x,(size.height - 228)/2.0, size.width-2*x, 228);
        //self.idCardToRect = CGRectMake((size.width-300)/2,(size.height - 185)/2.0, 300, 185);
    //self.effectiveRect = self.idCardToRect;
}
-(AVCaptureDevice *)inputDevice{
    if (_inputDevice == nil) {
        _inputDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        NSError *error = nil;
        if([_inputDevice lockForConfiguration:&error])
        {
            //设置自动连续对焦
            if([_inputDevice isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus])
            {
                [_inputDevice setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
            }
            //设置近距离焦距模式
            if([_inputDevice isAutoFocusRangeRestrictionSupported])
            {
                _inputDevice.autoFocusRangeRestriction = AVCaptureAutoFocusRangeRestrictionNear;
            }
            
            [_inputDevice unlockForConfiguration];
        }
    }
    return _inputDevice;
}

-(AVCaptureDeviceInput *)captureInput{
    if (_captureInput == nil) {
        _captureInput = [AVCaptureDeviceInput deviceInputWithDevice:self.inputDevice error:nil];
    }
    return _captureInput;
}
-(AVCaptureVideoDataOutput *)captureVideoDataOutput{
    if (_captureVideoDataOutput == nil) {
        _captureVideoDataOutput = [[AVCaptureVideoDataOutput alloc] init];
        _captureVideoDataOutput.alwaysDiscardsLateVideoFrames = YES;
        [_captureVideoDataOutput setSampleBufferDelegate:self queue:dispatch_queue_create("catch.serial.queue", DISPATCH_QUEUE_SERIAL)];
        
        NSString* key = (NSString*)kCVPixelBufferPixelFormatTypeKey;
        NSNumber* value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA];
        NSDictionary* videoSettings = [NSDictionary dictionaryWithObject:value forKey:key];
        [_captureVideoDataOutput setVideoSettings:videoSettings];
        
        AVCaptureConnection *conn = [_captureVideoDataOutput connectionWithMediaType:AVMediaTypeVideo];

        [conn setVideoOrientation:AVCaptureVideoOrientationLandscapeLeft];
        
        _videoOrientation = [_captureVideoDataOutput connectionWithMediaType:AVMediaTypeVideo].videoOrientation;
    }
    return _captureVideoDataOutput;
}

-(AVCaptureVideoPreviewLayer *)captureVideoPreviewLayer{
    if (_captureVideoPreviewLayer == nil) {
        _captureVideoPreviewLayer = [AVCaptureVideoPreviewLayer layerWithSession:self.captureSession];
        _captureVideoPreviewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
        _captureVideoPreviewLayer.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    }
    return _captureVideoPreviewLayer;
}

-(AVCaptureSession *)captureSession{
    if (_captureSession == nil) {
        _captureSession = [[AVCaptureSession alloc] init];
        [_captureSession setSessionPreset:AVCaptureSessionPreset1920x1080];//AVCaptureSessionPreset1920x1080
        //[_captureSession setSessionPreset:AVCaptureSessionPreset1920x1080];AVCaptureSessionPreset3840x2160
        //[_captureSession setSessionPreset:AVCaptureSessionPreset3840x2160];
    }
    return _captureSession;
}

- (UIImageView* )imgViewRecStatus
{
    if(_imgViewRecStatus == nil)
    {
        _imgViewRecStatus = [[FLAnimatedImageView alloc] init];
        _imgViewRecStatus.contentMode = UIViewContentModeScaleAspectFill;
        _imgViewRecStatus.clipsToBounds = YES;
        //_imgViewRecStatus.frame = CGRectMake((self.view.frame.size.width-375)/2, self.view.bounds.size.height-80-225, 375, 225);
        _imgViewRecStatus.frame = CGRectMake((self.view.frame.size.width-375/2)/2, self.view.bounds.size.height-80-225/2, 375/2, 225/2);
    }
    return _imgViewRecStatus;
}


- (UIView* )maskBgView
{
    if(_maskBgView == nil)
    {
        _maskBgView = [[UIView alloc] init];
        _maskBgView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    }
    return _maskBgView;
}

- (UIImageView* )idCardToRectImgView
{
    if(_idCardToRectImgView == nil)
    {
        _idCardToRectImgView = [[UIImageView alloc] init];

        _idCardToRectImgView.frame = CGRectMake(self.idCardToRect.origin.x, (self.maskBgView.frame.size.height-self.idCardToRect.size.height)/2-1, self.idCardToRect.size.width, self.idCardToRect.size.height);
    }
    
    return _idCardToRectImgView;
}

/**黑色半透明遮掩层*/
- (CAShapeLayer *)maskLayer {
    if (!_maskLayer) {
        _maskLayer = [CAShapeLayer layer];
        _maskLayer.path = [self getMaskPathWithRect:self.view.bounds exceptRect:CGRectZero].CGPath;
        _maskLayer.fillColor = self.maskColor.CGColor;
    }
    return _maskLayer;
}

- (void)updateEffectiveRect:(BOOL)needDraw
{
    if(needDraw)
    {
        _maskLayer.path = [self getMaskPathWithRect:self.view.bounds exceptRect:self.effectiveRect].CGPath;
    }
    else
    {
        _maskLayer.path = [self getMaskPathWithRect:self.view.bounds exceptRect:CGRectZero].CGPath;
    }
    
    _maskLayer.fillColor = self.maskColor.CGColor;
}

/**生成空缺部分rect的layer*/
- (UIBezierPath *)getMaskPathWithRect: (CGRect)rect exceptRect: (CGRect)exceptRect
{
    if (!CGRectContainsRect(rect, exceptRect)) {
        return nil;
    }
    else if (CGRectEqualToRect(rect, CGRectZero)) {
        return nil;
    }
    
    CGFloat boundsInitX = CGRectGetMinX(rect);
    CGFloat boundsInitY = CGRectGetMinY(rect);
    CGFloat boundsWidth = CGRectGetWidth(rect);
    CGFloat boundsHeight = CGRectGetHeight(rect);
    
    CGFloat minX = CGRectGetMinX(exceptRect);
    CGFloat maxX = CGRectGetMaxX(exceptRect);
    CGFloat minY = CGRectGetMinY(exceptRect);
    CGFloat maxY = CGRectGetMaxY(exceptRect);
    CGFloat width = CGRectGetWidth(exceptRect);
    
    /** 添加路径*/
    UIBezierPath * path = [UIBezierPath bezierPathWithRect: CGRectMake(boundsInitX, boundsInitY, minX, boundsHeight)];
    [path appendPath: [UIBezierPath bezierPathWithRect: CGRectMake(minX, boundsInitY, width, minY)]];
    [path appendPath: [UIBezierPath bezierPathWithRect: CGRectMake(maxX, boundsInitY, boundsWidth - maxX, boundsHeight)]];
    [path appendPath: [UIBezierPath bezierPathWithRect: CGRectMake(minX, maxY, width, boundsHeight - maxY)]];
    
    return path;
}

/**配置拍摄范围*/
- (void)setupEffectiveRect{
    [self.maskBgView.layer addSublayer: self.maskLayer];
    
    [self.maskBgView addSubview:self.idCardToRectImgView];
    
}

- (void)resetVideoUI
{
    [self updateEffectiveRect:YES];
    
    self.maskLayer.hidden = NO;
}
#pragma mark -- 视频相关操作

-(void)setupCamera{
    if ([self.captureSession canAddInput:self.captureInput]) {
        [self.captureSession addInput:self.captureInput];
    }
    if ([self.captureSession canAddOutput:self.captureVideoDataOutput]) {
        [self.captureSession addOutput:self.captureVideoDataOutput];
    }
}

- (CGFloat)fileSize:(NSURL *)path
{
    return [[NSData dataWithContentsOfURL:path] length]/1024.00 /1024.00;
}

- (void)proccessRecordVideo
{
    
}


//- (CGAffineTransform)transformFromVideoBufferOrientationToOrientation:(AVCaptureVideoOrientation)orientation withAutoMirroring:(BOOL)mirror
//{
//    CGAffineTransform transform = CGAffineTransformIdentity;
//    
//    CGFloat orientationAngleOffset = MGAngleOffsetFromPortraitOrientationToOrientation(orientation);
//    CGFloat videoOrientationAngleOffset = MGAngleOffsetFromPortraitOrientationToOrientation(self.videoOrientation);
//    
//    CGFloat angleOffset = orientationAngleOffset - videoOrientationAngleOffset;
//    transform = CGAffineTransformMakeRotation(angleOffset);
//    transform = CGAffineTransformRotate(transform, -M_PI);
//    
//    return transform;
//}
//
//CGFloat MGAngleOffsetFromPortraitOrientationToOrientation(AVCaptureVideoOrientation orientation)
//{
//    CGFloat angle = 0.0;
//    switch ( orientation )
//    {
//        case AVCaptureVideoOrientationPortrait:
//            angle = 0.0;
//            break;
//        case AVCaptureVideoOrientationPortraitUpsideDown:
//            angle = M_PI;
//            break;
//        case AVCaptureVideoOrientationLandscapeRight:
//            angle = -M_PI_2;
//            break;
//        case AVCaptureVideoOrientationLandscapeLeft:
//            angle = M_PI_2;
//            break;
//        default:
//            break;
//    }
//    return angle;
//}

-(NSData *)imageFromSampleBuffer:(CMSampleBufferRef) sampleBuffer // Create a CGImageRef from sample buffer data
{
    // Get a CMSampleBuffer's Core Video image buffer for the media data
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    
    // Lock the base address of the pixel buffer
    CVPixelBufferLockBaseAddress(imageBuffer, 0);
    
    // Get the number of bytes per row for the pixel buffer
    void *baseAddress = CVPixelBufferGetBaseAddress(imageBuffer);
    
    // Get the number of bytes per row for the pixel buffer
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer);
    
    // Get the pixel buffer width and height
    size_t width = CVPixelBufferGetWidth(imageBuffer);
    size_t height = CVPixelBufferGetHeight(imageBuffer);
    
    //    NSLog(@"w: %zu h: %zu bytesPerRow:%zu", width, height, bytesPerRow);
    
    // Create a device-dependent RGB color space
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    // Create a bitmap graphics context with the sample buffer data
    CGContextRef context = CGBitmapContextCreate(baseAddress,
                                                 width,
                                                 height,
                                                 8,
                                                 bytesPerRow,
                                                 colorSpace,
                                                 kCGBitmapByteOrder32Little
                                                 | kCGImageAlphaPremultipliedFirst);
    // Create a Quartz image from the pixel data in the bitmap graphics context
    CGImageRef quartzImage = CGBitmapContextCreateImage(context);
    
    // Unlock the pixel buffer
    CVPixelBufferUnlockBaseAddress(imageBuffer,0);
    
    // Free up the context and color space
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    
    UIImage *image = [UIImage imageWithCGImage:quartzImage
                                         scale:1.0f
                                   orientation:UIImageOrientationUp];
    
    // Release the Quartz image
    CGImageRelease(quartzImage);
    
//    UIImage* img = [self yp_imagecutWithOriginalImage:image withCutRect:self.effectiveRect];
//    return UIImageJPEGRepresentation(img, 1.0);
    
    return UIImageJPEGRepresentation(image, 1.0);
    
}

/** originalImage：原图片   rect：需要剪切的位置*/
- (UIImage *)yp_imagecutWithOriginalImage:(UIImage *)originalImage withCutRect:(CGRect)rect {
    CGImageRef subImageRef = CGImageCreateWithImageInRect(originalImage.CGImage, rect);
    CGRect smallRect = CGRectMake(0, 0, CGImageGetWidth(subImageRef), CGImageGetHeight(subImageRef));
    // 开启图形上下文
    UIGraphicsBeginImageContext(smallRect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextDrawImage(context, smallRect, subImageRef);
    UIImage * image = [UIImage imageWithCGImage:subImageRef];
    // 关闭图形上下文
    UIGraphicsEndImageContext();
    
    CGImageRelease(subImageRef);
    
    return image;
}


#pragma mark -- Delegate protocols

#pragma mark -- AVCaptureVideoDataOutputSampleBufferDelegate
- (void)captureOutput:(AVCaptureOutput *)output didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer fromConnection:(AVCaptureConnection *)connection {
    
    if(self.bStopRecording || !self.bStartRec)
    {
        return;
    }
    
    self.curImgData = [self imageFromSampleBuffer:sampleBuffer];
    
    dispatch_async(self.videoProcessQueue, ^{
        
        //进行数据分析
        
        static NSInteger nProcessFrame = 0;
        if (nProcessFrame > 0 || !self.bStartRec) {
            return;    //last frame not finished
        }
        nProcessFrame ++;

        //必需, 把视频帧传给SDK方法(addDetectBufferData)，供SDK分析识别;
        //注意:需要在inputDevice对象初始化时设置为【连续自动对焦】模式,如下:
        /**
         //设置自动连续对焦
         if([_inputDevice isFocusModeSupported:AVCaptureFocusModeContinuousAutoFocus])
         {
         [_inputDevice setFocusMode:AVCaptureFocusModeContinuousAutoFocus];
         }
         */
        //NSLog(@"处理帧： %li", (long)nProcessFrame);
        
        //NSLog(@"--------------------------当前状态: %i", self.curStep);
        
        [DSLMCVIDCardSDK addMCVDetectBufferData:self.curImgData Orient:1 Step:self.curStep];
        nProcessFrame--;
        
    });
    
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    if (error == nil) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"已存入手机相册" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
        
    }else{
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"保存失败" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
    }
    
}


#pragma mark-- 闪光灯相关
- (void)turnTorchOn:(BOOL)on
{
    if ([self.inputDevice hasTorch]
        &&
        [self.inputDevice hasFlash]
        )
    {
        
        [self.inputDevice lockForConfiguration:nil];
        if (on)
        {
            [self.inputDevice setTorchMode:AVCaptureTorchModeOn];
            [self.inputDevice setFlashMode:AVCaptureFlashModeOn];
        }
        else
        {
            [self.inputDevice setTorchMode:AVCaptureTorchModeOff];
            [self.inputDevice setFlashMode:AVCaptureFlashModeOff];
        }
        [self.inputDevice unlockForConfiguration];
    }
    else
    {
    }
}

- (void)rotateIDCardForCNHKIDCardPicture:(BOOL) bUp
{
    
    CATransform3D myTransform1 = CATransform3DIdentity;
    myTransform1.m34 = 0;
    myTransform1 = CATransform3DRotate(myTransform1,M_PI/180, 1, 0, 0);
    
    self.idCardToRectImgView.layer.transform = myTransform1;
    
    CGFloat angle;
    if(bUp)
    {
         [self setAnchorPoint:CGPointMake(0.5, 1.0) forView:self.idCardToRectImgView];
        angle = M_PI / 180 * 8;
    }
    else
    {
        angle = M_PI / 180 * 1;
    }
    CATransform3D myTransform = CATransform3DIdentity;
    myTransform.m34 = -0.01;
    
    //沿（0，1，0）这个向量旋转
    myTransform = CATransform3DRotate(myTransform,angle, 1, 0, 0);
    self.idCardToRectImgView.layer.transform = myTransform;
    
}

- (void)setAnchorPoint:(CGPoint)anchorPoint forView:(UIView *)view
{
    CGRect oldFrame = view.frame;
    
    view.layer.anchorPoint = anchorPoint;
    
    view.frame = oldFrame;
    
}

@end
