//
//  ShowLocalDataViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/8/6.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "ShowLocalDataViewController.h"
#import "UIColor+DSLCHexColor.h"
#import "IRNetworkEngine.h"
#import "UIView+Toast.h"
@interface ShowLocalDataViewController ()

@property(nonatomic, strong) UITextView* txView;

@property(nonatomic, strong) UIButton* btnUploadJson;
@property(nonatomic, strong) UIButton* btnRemoveJson;
@end

@implementation ShowLocalDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self configBackButton];
    self.view.backgroundColor = [UIColor whiteColor];
    [self initView];
    [self.view addSubview:self.btnUploadJson];
    [self.view addSubview:self.btnRemoveJson];

}

- (void)initView
{
    self.txView = [[UITextView alloc] init];
    self.txView.frame = CGRectMake(10.0, 100.0, self.view.bounds.size.width-20.0, 100);
    self.txView.layer.borderColor = [UIColor grayColor].CGColor;
    self.txView.layer.borderWidth = 1.0;
    self.txView.layer.cornerRadius = 5.0;
    [self.view addSubview:self.txView];
}

- (UIButton* )btnUploadJson
{
    if(_btnUploadJson == nil)
    {
        _btnUploadJson = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnUploadJson setTitle:@"上传Json文件" forState:UIControlStateNormal];
        [_btnUploadJson setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnUploadJson setBackgroundColor:[UIColor blueColor]];
        _btnUploadJson.layer.cornerRadius = 20.0;
        _btnUploadJson.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:15];
        [_btnUploadJson addTarget:self action:@selector(clickUploadJsonFile:) forControlEvents:UIControlEventTouchUpInside];
        _btnUploadJson.frame = CGRectMake((self.view.frame.size.width-160)/2,240, 160, 40);
    }
    
    return _btnUploadJson;
}

- (UIButton* )btnRemoveJson
{
    if(_btnRemoveJson == nil)
    {
        _btnRemoveJson = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnRemoveJson setTitle:@"删除本地Json文件" forState:UIControlStateNormal];
        [_btnRemoveJson setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnRemoveJson setBackgroundColor:[UIColor redColor]];
        _btnRemoveJson.layer.cornerRadius = 20.0;
        _btnRemoveJson.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:15];
        [_btnRemoveJson addTarget:self action:@selector(clickRemoveJsonFile:) forControlEvents:UIControlEventTouchUpInside];
        _btnRemoveJson.frame = CGRectMake((self.view.frame.size.width-160)/2,340, 160, 40);
    }
    
    return _btnRemoveJson;
}

-(void)configBackButton{
    UIButton* btn = [[UIButton alloc] initWithFrame:CGRectMake(20, 40, 50, 50)];
    UIImage* image =  [UIImage imageNamed:@"closeVideo"];
    
    [btn setImage:image forState:UIControlStateNormal];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(doPopBack:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)clickRemoveJsonFile:(id)sender
{
    [self removeSaveRequestData];
}

-(void)clickUploadJsonFile:(id)sender
{
    NSString* fileKey = [[NSUUID UUID] UUIDString];
    fileKey = [fileKey substringWithRange:NSMakeRange(fileKey.length-8, 8)];
    NSDate *date = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    //获取当前时间日期展示字符串 如：2019-05-23-13:58:59
    NSString *str = [formatter stringFromDate:date];
    fileKey = [NSString stringWithFormat:@"eKey-off-line-data-%@-%@", fileKey, str];
    NSString *jsonString;
    NSMutableArray* muArr = [self getSaveRequestData];
    if([muArr count] > 0)
        {
            NSError *error;
            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:muArr options:NSJSONWritingPrettyPrinted error:&error];

            if (jsonData)
            {
                jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
                jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\\n" withString:@""];
                jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\\" withString:@""];
                jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\"{" withString:@"\{"];
                jsonString = [jsonString stringByReplacingOccurrencesOfString:@"}\"" withString:@"}"];
            }
        }
    else
    {
        [self showAlterController:@"本地没有可上传的数据！！！"];
        return;
    }
    
    [self.view makeToast:@"文件上传中..." duration:2.0 position:CSToastPositionCenter];
    __weak typeof(self) weakSelf = self;
    [IRNetworkEngine uploadJsonFile:[NSString stringWithFormat:@"/api/kvstorage/put/%@", fileKey] JsonStr:jsonString FileKey:fileKey completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if(error == nil)
                   {
                       [weakSelf showAlterController:[NSString stringWithFormat:@"上传成功, 文件名: %@", fileKey]];
                       weakSelf.txView.text = fileKey;
                   }
                   else
                   {
                       [weakSelf showAlterController:@"上传失败"];
                   }
        });
       
    }];
}
-(void)doPopBack:(id)sender{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (NSMutableArray* )getSaveRequestData
{
    NSString* path = [self pathForSaveRequestData];
    
    if(path == nil || [path isEqualToString:@""])
    {
        return [NSMutableArray arrayWithCapacity:5];
    }
    
    return [NSKeyedUnarchiver unarchiveObjectWithFile:path];
}

- (void)removeSaveRequestData
{
    NSMutableArray* muArr = [NSMutableArray arrayWithCapacity:5];
    NSString* path = [self pathForSaveRequestData];
    [NSKeyedArchiver archiveRootObject:muArr toFile:path];
    [self showAlterController:@"本地本地Json文件已经删除"];
}

- (NSString* ) pathForSaveRequestData
{
    NSString* path = nil;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    if ([paths count] > 0)
    {
        path = [paths objectAtIndex:0];
    }
    path = [path stringByAppendingString:@"/saveRequestData.za"];
    
    return path;
}

- (void)showAlterController:(NSString* )msg
{
    //@"App使用已過期，請聯系供應商"
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:msg message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"確定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [actionSheet addAction:action1];
    
    [self presentViewController:actionSheet animated:NO completion:nil];
}

@end
