//
//  ZAUsageRecordCount.h
//  ZABankAndIDCardSDK
//  统计用户使用的情况
//  Created by chenliqun on 16/4/20.
//  Copyright © 2016年 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZAUsageRecordCount : NSObject

+ (instancetype)sharedInstance;

/**
 *  增加一条使用记录
 *
 *  @param useResult 操作结果
 *  @param useType   操作类型
 */
- (void)addOneRecord:(NSString*) useResult UseType:(NSString*) useType;

/**
 *  保存使用记录
 */
- (void)saveRecords;
/**
 *  上传使用记录到服务器端
 */
- (void)uploadUseRecord;

@end
