//
//  AgreementView.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/11/25.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AgreementView : UIView

@end

NS_ASSUME_NONNULL_END
