//
//  RemindViewController.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/10.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLHKIDCardEnumType.h"

NS_ASSUME_NONNULL_BEGIN

@interface RemindViewController : UIViewController

//身份证件类别
@property(nonatomic, assign) DSLHKIDCardTypeApp recType;
//是否使用lite版本
@property(nonatomic, assign) bool useLiteVersion;

@end

NS_ASSUME_NONNULL_END
