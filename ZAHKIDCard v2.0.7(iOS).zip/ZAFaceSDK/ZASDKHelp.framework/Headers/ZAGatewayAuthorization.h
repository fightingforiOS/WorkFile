//
//  ZAGatewayAuthorization.h
//  ZAGatewayAuthorization
//
//  Created by clq on 16/4/13.
//  Copyright © 2016年 clq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZAGatewayAuthorization : NSObject

+ (instancetype)sharedInstance;

/**
 SDK验签获取token接口
 
 @param appKey appKey
 @param secret secret
 @param grant_type client_credentials
 @param bSynchronized 是否同步请求
 @param completion 请求完成block
 @return 当同步情况下返回值有用
 */
-(NSDictionary* ) zaGatewayAuthorization:(NSString*) appKey  Secret:(NSString*)secret TransferMode:(BOOL) bSynchronized  SDKVersion:(int)sdkVersion completion: (void(^)(id result, id requestError, NSURLResponse *response)) completion;

@end
