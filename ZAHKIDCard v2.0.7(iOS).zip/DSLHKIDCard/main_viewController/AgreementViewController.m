//
//  AgreementViewController.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/11/25.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "AgreementViewController.h"
#import "AgreementView.h"
#import "UIColor+DSLCHexColor.h"

@interface AgreementViewController ()
@property(nonatomic, strong) UIButton* btnAgree;

@property(nonatomic, strong) UIButton* btnRefuse;
@end

@implementation AgreementViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initView];
}

- (void)initView
{
    AgreementView* agreementView = [[AgreementView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    [self.view addSubview:agreementView];
    
    self.btnRefuse.frame =  CGRectMake(40.0, UIScreen.mainScreen.bounds.size.height-80.0, 90.0, 34.0);
    [agreementView addSubview:self.btnRefuse];
    
    self.btnAgree.frame = CGRectMake(UIScreen.mainScreen.bounds.size.width-40.0-90.0, UIScreen.mainScreen.bounds.size.height-80.0, 90.0, 34.0);
    [agreementView addSubview:self.btnAgree];
    
}


- (UIButton* )btnAgree
{
    if(_btnAgree == nil)
    {
        _btnAgree = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnAgree.alpha = 0.7;
        [_btnAgree setTitle:@"Agree" forState:UIControlStateNormal];
        [_btnAgree addTarget:self action:@selector(clickAgree:) forControlEvents:UIControlEventTouchUpInside];
        [_btnAgree setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnAgree setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
        _btnAgree.layer.cornerRadius = 4.0;
        
        _btnAgree.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
    }
    return  _btnAgree;
}

- (UIButton* )btnRefuse
{
    if(_btnRefuse == nil)
    {
        _btnRefuse = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnRefuse.alpha = 0.7;
        [_btnRefuse setTitle:@"Refuse" forState:UIControlStateNormal];
        [_btnRefuse addTarget:self action:@selector(clickRefuse:) forControlEvents:UIControlEventTouchUpInside];
        [_btnRefuse setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateNormal];
        _btnRefuse.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x02A6CA"].CGColor;
        _btnRefuse.layer.borderWidth = 1.0;
        //[_btnRefuse setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
        _btnRefuse.layer.cornerRadius = 4.0;
        _btnRefuse.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
    }
    return  _btnRefuse;
}

- (void)clickAgree:(id)sender
{
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(agreement:)])
        {
            [self.myDelegate agreement:YES];
        }
    }
}

- (void)clickRefuse:(id)sender
{
    if(self.myDelegate)
       {
           if([self.myDelegate respondsToSelector:@selector(agreement:)])
           {
               [self.myDelegate agreement:NO];
           }
       }
}

@end
