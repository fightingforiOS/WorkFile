//
//  NextOperationView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import "NextOperationView.h"
#import "DSLPlayAudio.h"
#import "DSLHKIDCardBundle.h"
#import "DSLHKIDCardConfig.h"
#import "UIColor+DSLCHexColor.h"

@interface NextOperationView()

@property(nonatomic, strong) UIView* viewOpBk;
@property(nonatomic,strong)UILabel *labelNextOperation;
//@property(nonatomic,strong)UIImageView *imgViewMark;

@end

@implementation NextOperationView


- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{

    [self addSubview:self.labelNextOperation];

    self.viewOpBk.frame = self.bounds;
    self.labelNextOperation.frame = CGRectMake(0.0, (40.0-28.0)/2, self.frame.size.width, 28.0);
    self.labelNextOperation.textAlignment = NSTextAlignmentCenter;
}

- (UIView* )viewOpBk
{
    if(_viewOpBk == nil)
    {
        _viewOpBk = [[UIView alloc] init];
        [_viewOpBk setBackgroundColor:[UIColor blackColor]];
        _viewOpBk.alpha = 0.48;
        _viewOpBk.layer.borderColor = [UIColor blackColor].CGColor;
        _viewOpBk.layer.cornerRadius = 21.0;
    }
    
    return _viewOpBk;
}

- (UILabel* )labelNextOperation
{
    if (_labelNextOperation == nil) {
        _labelNextOperation = [[UILabel alloc] init];
        _labelNextOperation.textAlignment = NSTextAlignmentCenter;
        _labelNextOperation.textColor = [UIColor whiteColor];
        _labelNextOperation.font = [UIFont fontWithName:@"PingFangSC-Medium" size:24];
        _labelNextOperation.lineBreakMode = NSLineBreakByWordWrapping;
        _labelNextOperation.numberOfLines = 0;
        
        
    }
    return _labelNextOperation;
}

- (void)setNextOpStatus:(DSLHKIDCardOperationStatus)opStatus Text:(NSString* )text IDCardType:(DSLHKIDCardTypeApp)idCardType
{
    if(opStatus == DSLHKIDCardOperation_ORTH || opStatus == DSLHKIDCardOperation_STOP1 || opStatus == DSLHKIDCardOperation_STOP2 || opStatus == DSLHKIDCardOperation_STOP3)
    {
        self.labelNextOperation.textColor = [UIColor dslc_colorWithHexString:@"0x0AFF7A"];
    }
    else
    {
        self.labelNextOperation.textColor = [UIColor whiteColor];
    }
    
    switch (opStatus)
    {
        case DSLHKIDCardOperation_ORTH:
        {
            //需要播放成功声音
            [self setNextOpText:text];
        }
            break;
        case DSLHKIDCardOperation_LEFTDOWN:
        {
            [self setNextOpText:text];
        }
            break;
        case DSLHKIDCardOperation_COMPLETE:
        {
            [self setNextOpText:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title7"]];
        }
            break;
        case DSLHKIDCardOperation_RESET:
        {
            //需要播放成功声音
            [self setNextOpText:text];
        }
            break;
        default:
        {
            [self setNextOpText:text];
        }
            break;
    }
    
    
}

- (void) setNextOpText:(NSString* )text
{
    
    if(text == nil || [text isEqualToString:@""] || [text isEqualToString:self.labelNextOperation.text])
    {
        return;
    }
    
    self.labelNextOperation.text = text;
    if([DSLHKIDCardBundle isChineseLanguage])
    {
        CGSize textSize = CGSizeMake(self.bounds.size.width-20, 28);//[self computerContentHeight:text ContentSize:CGSizeMake(300, 20.0) FontSize:16];

        self.labelNextOperation.frame = CGRectMake((self.bounds.size.width-textSize.width)/2, (40.0-28)/2, textSize.width, textSize.height);
    }
    else
    {
        if([text isEqualToString:@"Start detection"])
        {
            NSLog(text);
        }

        //NSString* str = [text stringByReplacingOccurrencesOfString:@" " withString:@"a"];
        
        CGSize textSize = [self computerContentHeight:text ContentSize:CGSizeMake(self.bounds.size.width, 120.0) FontSize:24.0];
        if(textSize.height > 32)
        {
            self.labelNextOperation.frame = CGRectMake((self.bounds.size.width-textSize.width)/2, (40.0-28)/2, textSize.width, textSize.height+30);
        }
        else
        {
            self.labelNextOperation.frame = CGRectMake((self.bounds.size.width-300)/2, 20, 300, 30);
        }


    }
}

- (CGSize) computerContentHeight:(NSString*) content ContentSize:(CGSize) contentSize FontSize:(float) fontSize
{
    UIFont *font = [UIFont systemFontOfSize:fontSize];
    
    NSDictionary *attrDictionary = [NSDictionary dictionaryWithObject:font
                                                               forKey:NSFontAttributeName];
    
    NSAttributedString* attrContent = [[NSAttributedString alloc] initWithString:content attributes:attrDictionary];
    CGRect attrContentSize = [attrContent boundingRectWithSize:contentSize options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize size = CGSizeMake(ceilf(attrContentSize.size.width), ceilf(attrContentSize.size.height));
    return size;
    
}

- (void)delayShowTip:(NSString* )text
{
    [self setNextOpText:text];
}
@end
