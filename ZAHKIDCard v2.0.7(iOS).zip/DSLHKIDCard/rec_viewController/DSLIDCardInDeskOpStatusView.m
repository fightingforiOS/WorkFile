//
//  DSLIDCardInDeskOpStatusView.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/5/11.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "DSLIDCardInDeskOpStatusView.h"


#define Max_Rotation_Angle_2018Card 28

#define Max_Rotation_Angle_2003Card 30

#define Finish_Mark_Width 16

#define Finish_Mark_Height 16

#define Bar_Width 30

#define Bar_Height 30

#define Progress_Height 8

#define View_Self_Height 30

#define Center_Mark_Width 30

@interface DSLIDCardInDeskOpStatusView()

//向左完成标志
@property(nonatomic, strong) UIImageView* imgViewLeftFinishMark;
//向右完成标志
@property(nonatomic, strong) UIImageView* imgViewRightFinishMark;
//中间开始标志
@property(nonatomic, strong) UIImageView* imgViewCenterMark;
//进度移动bar
@property(nonatomic, strong) UIImageView* imgViewBar;
//进度条背景
@property(nonatomic, strong) UIImageView* viewImgProgressBk;
//左进度条
@property(nonatomic, strong) UIView* viewLeftProgress;
//左进度条背景渐变
@property(nonatomic, strong) CAGradientLayer* gradientLayerLeft;
//右进度条
@property(nonatomic, strong) UIView* viewRightProgress;
//右进度条背景渐变
@property(nonatomic, strong) CAGradientLayer* gradientLayerRight;
//进度条方向是否是向左
@property(nonatomic, assign) BOOL bBarOriginalDirctionLeft;

//当前进度条方向是否是向左
@property(nonatomic, assign) BOOL bCurBarDirctionLeft;

@property(nonatomic, assign) double dCurMaxRotationAngle;

@property(nonatomic, assign) BOOL bIDCard2018;

@property(nonatomic, assign) DSLHKIDCardOperationStatus curdIDCardOpetationStatus;

@property(nonatomic, assign) BOOL bFirstReSet;

@property(nonatomic, assign) double dCurRotationAngle;
@end

@implementation DSLIDCardInDeskOpStatusView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)initData
{
    self.dCurMaxRotationAngle = Max_Rotation_Angle_2018Card;
    self.bFirstReSet = YES;
    self.viewLeftProgress.frame = CGRectMake(0.0, 0.0, 0.0, 0.0);
    self.gradientLayerLeft.frame = self.viewLeftProgress.bounds;
    
    self.viewRightProgress.frame = CGRectMake(0.0, 0.0, 0.0, 0.0);
    self.gradientLayerRight.frame = self.viewRightProgress.bounds;
    self.imgViewCenterMark.image = [UIImage imageNamed:@"idcard_in_desk_center_mark"];
}

- (void)setupView
{
    self.dCurMaxRotationAngle = Max_Rotation_Angle_2018Card;
    
    self.bFirstReSet = YES;
    
    [self addSubview:self.imgViewLeftFinishMark];
    [self addSubview:self.viewImgProgressBk];
    [self addSubview:self.imgViewRightFinishMark];
    [self addSubview:self.imgViewCenterMark];
    [self addSubview:self.viewLeftProgress];
    [self.viewLeftProgress.layer addSublayer:self.gradientLayerLeft];
    [self addSubview:self.viewRightProgress];
    [self.viewRightProgress.layer addSublayer:self.gradientLayerRight];
    [self addSubview:self.imgViewBar];
    
    //[self setBarOriginalDirctionLeft:YES IDCardType2018:YES];
    
}
- (void)setIDCardOperationStatus:(DSLHKIDCardOperationStatus) opStatus;
{
    self.curdIDCardOpetationStatus = opStatus;
    
    switch (self.curdIDCardOpetationStatus)
    {
        case DSLHKIDCardOperation_ORTH:
        {
            if(self.bBarOriginalDirctionLeft)
            {
                self.bCurBarDirctionLeft = YES;
                self.imgViewBar.image = [UIImage imageNamed:@"idcard_in_desk_left_bar"];
            }
            else
            {
                self.bCurBarDirctionLeft = NO;
                self.imgViewBar.image = [UIImage imageNamed:@"idcard_in_desk_right_bar"];
            }
        }
            break;
        case DSLHKIDCardOperation_RESET:
        {
            
            if(self.bFirstReSet)
            {
                self.dCurMaxRotationAngle = self.dCurRotationAngle;
                if(self.bBarOriginalDirctionLeft)
                {
                    self.imgViewLeftFinishMark.image = [UIImage imageNamed:@"idcard_in_desk_finish_mark"];
                    self.imgViewBar.image = [UIImage imageNamed:@"idcard_in_desk_right_bar"];
                }
                else
                {
                    self.imgViewRightFinishMark.image = [UIImage imageNamed:@"idcard_in_desk_finish_mark"];
                     self.imgViewBar.image = [UIImage imageNamed:@"idcard_in_desk_left_bar"];
                }
               
            }
            else
            {
                
            }
        }
            break;
        case DSLHKIDCardOperation_LEFTDOWN:
        {
            self.bCurBarDirctionLeft = self.bBarOriginalDirctionLeft ? NO : YES;

            self.bFirstReSet = NO;
            self.imgViewCenterMark.image = [UIImage imageNamed:@"idcard_in_desk_center_green_mark"];
        }
            break;
        case DSLHKIDCardOperation_COMPLETE:
        {
            self.dCurMaxRotationAngle = self.dCurRotationAngle;
            if(self.bBarOriginalDirctionLeft)
            {
                self.imgViewRightFinishMark.image = [UIImage imageNamed:@"idcard_in_desk_finish_mark"];
            }
            else
            {
                self.imgViewLeftFinishMark.image = [UIImage imageNamed:@"idcard_in_desk_finish_mark"];
            }
            
        }
            break;
        default:
            break;
    }
}

- (void)setBarOriginalDirctionLeft:(BOOL)bBarOriginalDirctionLeft IDCardType2018:(BOOL)bIDCard2018
{
    self.bBarOriginalDirctionLeft = bBarOriginalDirctionLeft;
    
    self.bCurBarDirctionLeft = bBarOriginalDirctionLeft;
    
    self.bIDCard2018 = bIDCard2018;
    
    if(bIDCard2018)
    {
        self.dCurMaxRotationAngle = Max_Rotation_Angle_2018Card;
    }
    else
    {
        self.dCurMaxRotationAngle = Max_Rotation_Angle_2003Card;
    }
    
    self.imgViewLeftFinishMark.frame = CGRectMake(0.0, (View_Self_Height-Finish_Mark_Height)/2, Finish_Mark_Width, Finish_Mark_Height);
    
    self.viewImgProgressBk.frame = CGRectMake(self.imgViewLeftFinishMark.frame.origin.x+Finish_Mark_Width, (View_Self_Height-Progress_Height)/2, self.frame.size.width-2*Finish_Mark_Width, Progress_Height);
    
    self.imgViewRightFinishMark.frame = CGRectMake(self.frame.size.width-Finish_Mark_Width, (View_Self_Height-Finish_Mark_Height)/2, Finish_Mark_Width, Finish_Mark_Height);
    
    self.imgViewCenterMark.frame = CGRectMake((self.frame.size.width-Center_Mark_Width)/2, 0, Center_Mark_Width, View_Self_Height);
    
    self.imgViewBar.frame = CGRectMake((self.frame.size.width-Center_Mark_Width)/2, 0, Bar_Width, Bar_Height);
    
    self.viewLeftProgress.frame = CGRectMake(self.frame.size.width/2, (View_Self_Height-Progress_Height)/2, 0, 0);
    
    self.viewRightProgress.frame = CGRectMake(self.frame.size.width/2, (View_Self_Height-Progress_Height)/2, 0, 0);
    
   
    
}
- (UIImageView* )imgViewLeftFinishMark
{
    if(_imgViewLeftFinishMark == nil)
    {
        _imgViewLeftFinishMark = [[UIImageView alloc] init];
        _imgViewLeftFinishMark.image = [UIImage imageNamed:@"idcard_in_desk_un_finish_mark"];
    }
    return _imgViewLeftFinishMark;
}

- (UIImageView* )imgViewRightFinishMark
{
    if(_imgViewRightFinishMark == nil)
    {
        _imgViewRightFinishMark = [[UIImageView alloc] init];
        _imgViewRightFinishMark.image = [UIImage imageNamed:@"idcard_in_desk_un_finish_mark"];
    }
    return _imgViewRightFinishMark;
}

- (UIImageView* )imgViewCenterMark
{
    if(_imgViewCenterMark == nil)
    {
        _imgViewCenterMark = [[UIImageView alloc] init];
        _imgViewCenterMark.image = [UIImage imageNamed:@"idcard_in_desk_center_mark"];
    }
    return _imgViewCenterMark;
}

- (UIImageView* )imgViewBar
{
    if(_imgViewBar == nil)
    {
        _imgViewBar = [[UIImageView alloc] init];
        _imgViewBar.image = [UIImage imageNamed:@"idcard_in_desk_left_bar"];
    }
    return _imgViewBar;
}

- (UIImageView* )viewImgProgressBk
{
    if(_viewImgProgressBk == nil)
    {
        _viewImgProgressBk = [[UIImageView alloc] init];
        _viewImgProgressBk.image = [UIImage imageNamed:@"idcard_in_desk_progress_bk"];
    }
    return _viewImgProgressBk;
}

- (UIView* )viewLeftProgress
{
    if(_viewLeftProgress == nil)
    {
        _viewLeftProgress = [[UIView alloc] init];
        [_viewLeftProgress setBackgroundColor:[UIColor greenColor]];
    }
    
    return _viewLeftProgress;
}

- (CAGradientLayer* )gradientLayerLeft
{
    if(_gradientLayerLeft == nil)
    {
        _gradientLayerLeft = [CAGradientLayer layer];
        _gradientLayerLeft.colors = @[(__bridge id)[UIColor colorWithRed:10/255.0 green:255/255.0 blue:122/255.0 alpha:0.0].CGColor, (__bridge id)[UIColor colorWithRed:10/255.0 green:255/255.0 blue:122/255.0 alpha:1.0].CGColor];
        _gradientLayerLeft.locations = @[@(0), @(1.0f)];
        _gradientLayerLeft.startPoint = CGPointMake(1.18, 0.5);
        _gradientLayerLeft.endPoint = CGPointMake(0.04, 0.5);
        _gradientLayerLeft.frame = _viewLeftProgress.bounds;
    }
    
    return _gradientLayerLeft;
}

- (UIView* )viewRightProgress
{
    if(_viewRightProgress == nil)
    {
        _viewRightProgress = [[UIView alloc] init];
        [_viewRightProgress setBackgroundColor:[UIColor greenColor]];
    }
    
    return _viewRightProgress;
}

- (CAGradientLayer* )gradientLayerRight
{
    if(_gradientLayerRight == nil)
    {
        _gradientLayerRight = [CAGradientLayer layer];
        _gradientLayerRight.colors = @[(__bridge id)[UIColor colorWithRed:10/255.0 green:255/255.0 blue:122/255.0 alpha:0.0].CGColor, (__bridge id)[UIColor colorWithRed:10/255.0 green:255/255.0 blue:122/255.0 alpha:1.0].CGColor];
        _gradientLayerRight.locations = @[@(0), @(1.0f)];
        _gradientLayerRight.startPoint = CGPointMake(1.18, 0.5);
        _gradientLayerRight.endPoint = CGPointMake(0.04, 0.5);
        _gradientLayerRight.frame = _viewRightProgress.bounds;
    }
    
    return _gradientLayerRight;
}

- (void)updateRotationAngle:(double)angle RotationDirctionLeft:(BOOL) rotationDirctionLeft
{
    if(rotationDirctionLeft != self.bCurBarDirctionLeft)
    {
        return;
    }
    
    if(angle >self.dCurMaxRotationAngle)
    {
        angle = self.dCurMaxRotationAngle;
    }
    self.dCurRotationAngle = angle;
    
    double progress = (angle / self.dCurMaxRotationAngle) * (self.frame.size.width-2*Finish_Mark_Width)/2;
    [self updateProgress:progress];
}

- (void)updateProgress:(double)progress
{
    @try {
            switch (self.curdIDCardOpetationStatus) {
            case DSLHKIDCardOperation_ORTH:
            {
                if(self.bBarOriginalDirctionLeft)
                {
                    self.imgViewBar.frame = CGRectMake((self.frame.size.width)/2-progress-Bar_Width/4, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                    self.viewLeftProgress.frame = CGRectMake(Finish_Mark_Width+(self.frame.size.width-2*Finish_Mark_Width)/2-progress, (View_Self_Height-Progress_Height)/2, progress, Progress_Height);
                    self.gradientLayerLeft.frame = self.viewLeftProgress.bounds;
                }
                else
                {
                    self.imgViewBar.frame = CGRectMake((self.frame.size.width)/2+progress-Bar_Width/2, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                    self.viewRightProgress.frame = CGRectMake((self.frame.size.width)/2, (View_Self_Height-Progress_Height)/2, progress, Progress_Height);
                    self.gradientLayerRight.frame = self.viewRightProgress.bounds;
                }
            }
                break;
            case DSLHKIDCardOperation_RESET:
            {
                
                if(self.bFirstReSet)
                {
                    if(self.bBarOriginalDirctionLeft)
                    {
                        self.imgViewBar.frame = CGRectMake((self.frame.size.width)/2-progress-Finish_Mark_Width, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                        self.viewLeftProgress.frame = CGRectMake(Finish_Mark_Width, (View_Self_Height-Progress_Height)/2, (self.frame.size.width-2*Finish_Mark_Width)/2, Progress_Height);
                        self.gradientLayerLeft.frame = self.viewLeftProgress.bounds;
                    }
                    else
                    {
                        self.imgViewBar.frame = CGRectMake((self.frame.size.width)/2+progress-Bar_Width/2, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                        self.viewRightProgress.frame = CGRectMake((self.frame.size.width)/2, (View_Self_Height-Progress_Height)/2, (self.frame.size.width-2*Finish_Mark_Width)/2, Progress_Height);
                        self.gradientLayerRight.frame = self.viewRightProgress.bounds;
                    }

                }
                else
                {
                    
                }
            }
                break;
            case DSLHKIDCardOperation_LEFTDOWN:
            {
                if(self.bBarOriginalDirctionLeft)
                {
                    self.imgViewBar.frame = CGRectMake((self.frame.size.width)/2+progress-Bar_Width, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                                     
                    self.viewLeftProgress.frame = CGRectMake(Finish_Mark_Width, (View_Self_Height-Progress_Height)/2, (self.frame.size.width-2*Finish_Mark_Width)/2, Progress_Height);
                    self.gradientLayerLeft.frame = self.viewLeftProgress.bounds;
                    self.viewRightProgress.frame = CGRectMake((self.frame.size.width-2*Finish_Mark_Width)/2, (View_Self_Height-Progress_Height)/2, progress, Progress_Height);
                    self.gradientLayerRight.frame = self.viewRightProgress.bounds;
                }
                else
                {
                    self.imgViewBar.frame = CGRectMake((self.frame.size.width)/2-progress-Finish_Mark_Width/2, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                    self.viewRightProgress.frame = CGRectMake(Finish_Mark_Width+(self.frame.size.width-2*Finish_Mark_Width)/2, (View_Self_Height-Progress_Height)/2, (self.frame.size.width-2*Finish_Mark_Width)/2, Progress_Height);
                    self.gradientLayerRight.frame = self.viewRightProgress.bounds;
                    self.viewLeftProgress.frame = CGRectMake(Finish_Mark_Width+(self.frame.size.width-2*Finish_Mark_Width)/2-progress, (View_Self_Height-Progress_Height)/2, progress, Progress_Height);
                    self.gradientLayerLeft.frame = self.viewLeftProgress.bounds;
                }
            }
                break;
            case DSLHKIDCardOperation_COMPLETE:
            {
                if(self.bBarOriginalDirctionLeft)
                {
                    self.imgViewBar.frame = CGRectMake(self.frame.size.width-Finish_Mark_Width, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                    self.viewRightProgress.frame = CGRectMake(Finish_Mark_Width+(self.frame.size.width-2*Finish_Mark_Width)/2, (View_Self_Height-Progress_Height)/2, (self.frame.size.width-2*Finish_Mark_Width)/2, Progress_Height);
                    self.gradientLayerRight.frame = self.viewRightProgress.bounds;
                }
                else
                {
                    self.imgViewBar.frame = CGRectMake(0.0, (View_Self_Height-Bar_Height)/2, Bar_Width, Bar_Height);
                    self.viewLeftProgress.frame = CGRectMake(Finish_Mark_Width, (View_Self_Height-Progress_Height)/2, (self.frame.size.width-2*Finish_Mark_Width)/2, Progress_Height);
                    self.gradientLayerLeft.frame = self.viewLeftProgress.bounds;
                }

            }
                break;
            default:
                break;
        }
    } @catch (NSException *exception) {
        NSLog(@"exception: %@", exception.reason);
    } @finally {
        
    }

}
@end
