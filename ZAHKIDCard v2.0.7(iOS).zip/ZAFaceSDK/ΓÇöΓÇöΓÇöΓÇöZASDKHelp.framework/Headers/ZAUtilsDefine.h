//
//  ZAUtilsDefine.h
//  ZaGatewaySdk
//
//  Created by mqm on 16/4/14.
//  Copyright © 2016年 clq. All rights reserved.
//

#ifndef ZAUtilsDefine_h
#define ZAUtilsDefine_h

//屏幕宽度 （区别于viewcontroller.view.fream）
#define WIN_WIDTH  [UIScreen mainScreen].bounds.size.width
//屏幕高度 （区别于viewcontroller.view.fream）
#define WIN_HEIGHT [UIScreen mainScreen].bounds.size.height

#define SDKVERSION @"1"


#define HTTPURL_AUTH_TEST_BASE @"http://oauth.anlink.tech"
#define HTTPURL_AUTH_RELEASE_BASE @"https://oauth.anlink.com"


#define HTTPURL_OCR_TEST_BASE @"http://opengw.daily.zhongan.com/gateway.do"
//#define HTTPURL_OCR_TEST_BASE @"http://120.27.167.34:8080/gateway.do"
//ocr uat
#define HTTPURL_OCR_UAT_BASE @"https://opengw-uat.zhongan.com/Gateway.do"
//OCR
#define HTTPURL_OCR_RELEASE_BASE @"https://opengw.zhongan.com/Gateway.do"


#ifdef DEBUG
//mobileGateway
#define HTTPURL_SDK_BASE @"https://mobile.zhongan.com/sdk/"
//OCR
#define HTTPURL_OCR_BASE @"http://ocr.test.zhonganonline.com/"
//FACE
#define HTTPURL_FACE_BASE @"http://face.test.zhonganonline.com/"



#   define ILog(fmt, ...) {NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__);}
#   define DLog(...) NSLog(__VA_ARGS__)
#   define ELog(err) if(err) ILog(@"%@", err)}

#else

//mobileGateway
#define HTTPURL_SDK_BASE @"https://mobile.zhongan.com/sdk/"
//OCR
#define HTTPURL_OCR_BASE @"http://ocr.zalabs.zhonganonline.com/"
//FACE
#define HTTPURL_FACE_BASE @"http://face.zalabs.zhonganonline.com/"

// 屏蔽输出
#   define ILog(...)
#   define DLog(...)
#   define ELog(err)

#endif


//颜色转换
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]

#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]


//RGB color macro
#define UIColorFrom0xRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]
//RGB color macro with alpha
#define UIColorFrom0xRGBWithAlpha(rgbValue,a) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:a]


// 判断string是否为空 nil 或者 @"" 或者 (null)；
#define IsNilString(__String) (__String==nil || [__String isEqualToString:@""] || [[__String stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""])


#endif /* UtilsDefine_h */
