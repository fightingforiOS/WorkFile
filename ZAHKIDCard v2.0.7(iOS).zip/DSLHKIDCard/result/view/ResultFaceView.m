//
//  ResultFaceView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/23.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "ResultFaceView.h"
#import "ResultFaceItem.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"

@interface ResultFaceView()

@property(nonatomic, strong) UIImageView* imgViewBg;
@property(nonatomic, strong) UIImageView* imgViewHead;
@property(nonatomic, strong) UILabel* labelTip; //提示
@property(nonatomic, strong) UIImageView* imgViewIDCardHead;
@property(nonatomic, strong) UIImageView* imgViewFaceHead;
@property(nonatomic, strong) UIImageView* imgViewHeadGap;
@property(nonatomic, strong) UILabel* labelFaceSimilarity; //面部相似度
@property(nonatomic, strong) UILabel* labelLiveDetectTip; //活检
@property(nonatomic, strong) UILabel* labelVerifyResult; //验证
@property(nonatomic, strong) UIImage* imgIDCardHead;
@property(nonatomic, strong) UIImage* imgFaceHead;
@property(nonatomic, assign) double dSimilarity;
@property(nonatomic, assign) BOOL bFaceVerifyValid;

@property(nonatomic, strong) ResultFaceItem* resultFaceItemLeft;
@property(nonatomic, strong) ResultFaceItem* resultFaceItemCenter;
@property(nonatomic, strong) ResultFaceItem* resultFaceItemRight;

@end

@implementation ResultFaceView

- (instancetype)initWithFrame:(CGRect)frame IDCardHead:(UIImage* )idCardHead FaceHead:(UIImage* )faceHead FaceSimilarity:(double)similarity FaceVerifyValid:(BOOL)bFaceVerifyValid
{
    if(self = [super initWithFrame:frame])
    {
        self.imgIDCardHead = idCardHead;
        self.imgFaceHead = faceHead;
        self.dSimilarity = similarity;
        self.bFaceVerifyValid = bFaceVerifyValid;
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    [self addSubview:self.imgViewBg];
    [self addSubview:self.imgViewHead];
    [self addSubview:self.labelTip];
    [self addSubview:self.imgViewIDCardHead];
    [self addSubview:self.imgViewHeadGap];
    [self addSubview:self.imgViewFaceHead];
    
//    self.imgViewBg.layer.borderWidth = 1.0;
//    self.imgViewBg.layer.borderColor = [UIColor orangeColor].CGColor;
    UIView* resultItemBk = [[UIView alloc] init];
    resultItemBk.frame = CGRectMake(0.0, _imgViewFaceHead.frame.origin.y+_imgViewFaceHead.frame.size.height+10, self.bounds.size.width, 80.0);
    resultItemBk.backgroundColor = [UIColor dslc_colorWithHexString:@"0x02A6CA"];
    resultItemBk.alpha = 0.8;
    [self addSubview:resultItemBk];
//    resultItemBk.layer.borderWidth = 1.0;
//    resultItemBk.layer.borderColor = [UIColor blackColor].CGColor;
    
    [resultItemBk addSubview:self.resultFaceItemLeft];
    [resultItemBk addSubview:self.resultFaceItemCenter];
    [resultItemBk addSubview:self.resultFaceItemRight];
    self.resultFaceItemLeft.hidden = YES;
    self.resultFaceItemCenter.hidden = YES;
    self.resultFaceItemRight.hidden = YES;
    
    float gapW = ([UIScreen mainScreen].bounds.size.width - 3 * 100) / 4;
    self.resultFaceItemLeft.frame = CGRectMake(2*gapW, 15, 100, 50);
    self.resultFaceItemCenter.frame = CGRectMake(self.resultFaceItemLeft.frame.origin.x+self.resultFaceItemLeft.frame.size.width, 15, 100, 50);
    self.resultFaceItemRight.frame = CGRectMake(self.resultFaceItemCenter.frame.origin.x+self.resultFaceItemCenter.frame.size.width, 15, 100, 50);
    
//    [self addSubview:self.labelFaceSimilarity];
//    [self addSubview:self.labelLiveDetectTip];
    //[self performSelector:@selector(delayShowFaceSimilarity) withObject:nil afterDelay:1];
}

- (void)delayShowFaceSimilarity
{
    self.resultFaceItemLeft.hidden = NO;
    [self performSelector:@selector(delayShowVerifyResult) withObject:nil afterDelay:1];
}

- (void)delayShowLiveDetectTip
{
    self.resultFaceItemRight.hidden = NO;
    
}

- (void)delayShowVerifyResult
{
    self.resultFaceItemCenter.hidden = NO;
    [self performSelector:@selector(delayShowLiveDetectTip) withObject:nil afterDelay:1];
}

- (UIImageView* )imgViewBg
{
    if(_imgViewBg == nil)
    {
        
        _imgViewBg = [[UIImageView alloc] init];
        _imgViewBg.image = [UIImage imageNamed:@"result_bg"];
        _imgViewBg.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.bounds.size.width, self.bounds.size.height-214+22);
    }
    
    return _imgViewBg;
}

- (UIImageView* )imgViewHead
{
    if(_imgViewHead == nil)
    {
        float viewW = self.bounds.size.width;
        _imgViewHead = [[UIImageView alloc] init];
        _imgViewHead.image = [UIImage imageNamed:@"result_mark"];
        _imgViewHead.frame = CGRectMake((viewW-44)/2, 65, 44, 44);
    }
    
    return _imgViewHead;
}

- (UILabel* )labelTip
{
    if(_labelTip == nil)
    {
        float viewW = self.bounds.size.width;
        _labelTip = [[UILabel alloc] init];
        _labelTip.textColor = [UIColor whiteColor];
        _labelTip.numberOfLines = 1;
        _labelTip.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:20];
        _labelTip.textAlignment = NSTextAlignmentCenter;
        _labelTip.text = [DSLHKIDCardBundle IDCardBundleString:@"result_title54"];
        _labelTip.frame = CGRectMake(0, _imgViewHead.frame.origin.y+_imgViewHead.frame.size.height+13, viewW, 26);
    }
    return  _labelTip;
}

- (UIImageView* )imgViewIDCardHead
{
    if(_imgViewIDCardHead == nil)
    {
        float viewW = self.bounds.size.width;
        _imgViewIDCardHead = [[UIImageView alloc] init];
        _imgViewIDCardHead.image = self.imgIDCardHead;
        _imgViewIDCardHead.frame = CGRectMake((viewW-290)/2, _labelTip.frame.origin.y+_labelTip.frame.size.height+16, 100, 100);
        _imgViewIDCardHead.layer.cornerRadius = 50.0;
        _imgViewIDCardHead.layer.masksToBounds = YES;
        
    }
    
    return _imgViewIDCardHead;
}

- (UIImageView* )imgViewHeadGap
{
    if(_imgViewHeadGap == nil)
    {
        _imgViewHeadGap = [[UIImageView alloc] init];
        _imgViewHeadGap.image = [UIImage imageNamed:@"face_head_gap"];
        _imgViewHeadGap.frame = CGRectMake(_imgViewIDCardHead.frame.origin.x+_imgViewIDCardHead.frame.size.width+24, _imgViewIDCardHead.frame.origin.y+_imgViewIDCardHead.frame.size.height/2-10, 30, 24);
    }
    
    return _imgViewHeadGap;
}

- (UIImageView* )imgViewFaceHead
{
    if(_imgViewFaceHead == nil)
    {
        _imgViewFaceHead = [[UIImageView alloc] init];
        _imgViewFaceHead.image = self.imgFaceHead;
        _imgViewFaceHead.frame = CGRectMake(_imgViewHeadGap.frame.origin.x+_imgViewHeadGap.frame.size.width+24, _labelTip.frame.origin.y+_labelTip.frame.size.height+16, 100, 100);
        _imgViewFaceHead.layer.cornerRadius = 50.0;
        _imgViewFaceHead.layer.masksToBounds = YES;
    }
    
    return _imgViewFaceHead;
}

- (ResultFaceItem* )resultFaceItemLeft
{
    if(_resultFaceItemLeft == nil)
    {
        _resultFaceItemLeft = [[ResultFaceItem alloc] initWithFrame:CGRectZero];
        _resultFaceItemLeft.labelKey.text = [NSString stringWithFormat:@"%@:", [DSLHKIDCardBundle IDCardBundleString:@"result_title55"]];
        _resultFaceItemLeft.labelVal.text = [NSString stringWithFormat:@"%.2f%% ", self.dSimilarity*100];
    }
    return _resultFaceItemLeft;
}

- (ResultFaceItem* )resultFaceItemCenter
{
    if(_resultFaceItemCenter == nil)
    {
        _resultFaceItemCenter = [[ResultFaceItem alloc] initWithFrame:CGRectZero];
        _resultFaceItemCenter.labelKey.text = [NSString stringWithFormat:@"%@:", [DSLHKIDCardBundle IDCardBundleString:@"result_title56"]];
        _resultFaceItemCenter.labelVal.text = [DSLHKIDCardBundle IDCardBundleString:@"result_title33"];
    }
    return _resultFaceItemCenter;
}

- (ResultFaceItem* )resultFaceItemRight
{
    if(_resultFaceItemRight == nil)
    {
        _resultFaceItemRight = [[ResultFaceItem alloc] initWithFrame:CGRectZero];
        _resultFaceItemRight.labelKey.text = [NSString stringWithFormat:@"%@:", [DSLHKIDCardBundle IDCardBundleString:@"result_title57"]];
        if(self.bFaceVerifyValid)
        {
            _resultFaceItemRight.labelVal.text = [DSLHKIDCardBundle IDCardBundleString:@"result_title33"];
        }
        else
        {
            _resultFaceItemRight.labelVal.text = [DSLHKIDCardBundle IDCardBundleString:@"result_title34"];
        }
    }
    return _resultFaceItemRight;
}

- (UILabel* )labelFaceSimilarity
{
    if(_labelFaceSimilarity == nil)
    {
        float viewW = self.bounds.size.width;
        _labelFaceSimilarity = [[UILabel alloc] init];
        _labelFaceSimilarity.textColor = [UIColor whiteColor];
        _labelFaceSimilarity.numberOfLines = 1;
        _labelFaceSimilarity.font = [UIFont fontWithName:@"PingFangSC-Medium" size:15];
        _labelFaceSimilarity.textAlignment = NSTextAlignmentCenter;
        _labelFaceSimilarity.text = [NSString stringWithFormat:@"%@:   %.2f%% ", [DSLHKIDCardBundle IDCardBundleString:@"result_title55"], self.dSimilarity*100];
        _labelFaceSimilarity.frame = CGRectMake(0, _imgViewFaceHead.frame.origin.y+_imgViewFaceHead.frame.size.height+10, viewW, 20);
    }
    return  _labelFaceSimilarity;
}



- (UILabel* )labelLiveDetectTip
{
    if(_labelLiveDetectTip == nil)
    {
        float viewW = self.bounds.size.width;
        _labelLiveDetectTip = [[UILabel alloc] init];
        _labelLiveDetectTip.textColor = [UIColor whiteColor];
        _labelLiveDetectTip.numberOfLines = 1;
        _labelLiveDetectTip.font = [UIFont fontWithName:@"PingFangSC-Medium" size:15];
        _labelLiveDetectTip.textAlignment = NSTextAlignmentCenter;
        _labelLiveDetectTip.text = [NSString stringWithFormat:@"%@      :   %@  ", [DSLHKIDCardBundle IDCardBundleString:@"result_title56"], [DSLHKIDCardBundle IDCardBundleString:@"result_title33"]];

        _labelLiveDetectTip.frame = CGRectMake(0, _labelVerifyResult.frame.origin.y+_labelVerifyResult.frame.size.height+6, viewW, 20);
    }
    return  _labelLiveDetectTip;
}

- (UILabel* )labelVerifyResult
{
    if(_labelVerifyResult == nil)
    {
        float viewW = self.bounds.size.width;
        _labelVerifyResult = [[UILabel alloc] init];
        _labelVerifyResult.textColor = [UIColor whiteColor];
        _labelVerifyResult.numberOfLines = 1;
        _labelVerifyResult.font = [UIFont fontWithName:@"PingFangSC-Medium" size:15];
        _labelVerifyResult.textAlignment = NSTextAlignmentCenter;
        if(self.bFaceVerifyValid)
        {
            _labelVerifyResult.text = [NSString stringWithFormat:@"%@:   %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title57"], [DSLHKIDCardBundle IDCardBundleString:@"result_title33"]];
        }
        else
        {
            _labelVerifyResult.text = [NSString stringWithFormat:@"%@:   %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title57"], [DSLHKIDCardBundle IDCardBundleString:@"result_title34"]];
        }
        
        _labelVerifyResult.frame = CGRectMake(0, _labelFaceSimilarity.frame.origin.y+_labelFaceSimilarity.frame.size.height+6, viewW, 20);
    }
    return  _labelVerifyResult;
}

@end
