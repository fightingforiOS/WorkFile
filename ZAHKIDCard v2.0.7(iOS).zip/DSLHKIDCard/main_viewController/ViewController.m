//
//  ViewController.m
//  TestHKIDCard
//
//  Created by chentao on 2018/7/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import "ViewController.h"
#import "DSLHKBaseIDCardViewController.h"
#import "DSLHKIDCardViewController.h"
#import "DSLHKIDCardInDeskViewController.h"

#import "AppDelegate.h"
#import "UploadVideoTipView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardConfig.h"
#import <AVKit/AVKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import "SettingView.h"
#import "DSLHKIDCardConfig.h"
#import "DSLHKIDCardBundle.h"
#import "IRNetworkEngine.h"
#import "AgreementViewController.h"
#import "ShowLocalDataViewController.h"
#import "DSLHKIDCardEnumType.h"

#define kiPhoneX ([UIScreen mainScreen].bounds.size.height == 812 || [UIScreen mainScreen].bounds.size.height == 896)

#define ExpiredDateStr @"2019-05-30"

@interface ViewController ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate, UploadVideoTipViewDelegate, AgreementVcDelegate,UITextFieldDelegate>
@property(nonatomic,strong)UIButton *ocrButton;
@property(nonatomic, strong) UploadVideoTipView* uploadVideoTipView;
@property(nonatomic, strong) UIImageView* imgViewShadowBK;
@property(nonatomic, assign) int selectedType;
@property(nonatomic, assign) BOOL bShowVideoTipView;

@property(nonatomic, strong) AVPlayerViewController* moviePlayer;
@property(nonatomic, strong) AVPlayer* player;

@property(nonatomic, strong) UIButton* btnPassVideo;

@property(nonatomic, strong) UIImageView* imgViewPlayerBK;
@property(nonatomic,strong)UIButton *btnGotoRec;
@property(nonatomic,strong)UIButton *btnReplay;

@property(nonatomic, strong) AVPlayerItem* playerItem;

@property(nonatomic, strong) UILabel* labelIP;

@property(nonatomic, strong) SettingView* settingView;

@property(nonatomic, strong) UILabel* labelAppVersion;

//是否播放演示视频
@property(nonatomic, assign) BOOL bPlayVideo;

//选择动作操作模式
@property(nonatomic, strong) UISwitch* switchSelectIDCardInDesk;
@property(nonatomic, strong) UILabel* labelSelectIDCardInDesk;

//是否只采集视频
@property(nonatomic, strong) UISwitch* switchVideoDataOnlyCollection;
@property(nonatomic, strong) UILabel* labelVideoDataOnlyCollection;

//选择是否是Lite版本模式
@property(nonatomic, strong) UISwitch* switchLiteMode;
@property(nonatomic, strong) UILabel* labelLiteMode;

@end

@implementation ViewController


- (UILabel* )labelLiteMode
{
    if(_labelLiteMode == nil)
    {
        _labelLiteMode = [[UILabel alloc] init];
        _labelLiteMode.textColor = [UIColor whiteColor];
        _labelLiteMode.textAlignment = NSTextAlignmentCenter;
        _labelLiteMode.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelLiteMode.text = [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title14"];
    }
    return _labelLiteMode;
}

- (UISwitch* )switchLiteMode
{
    if(_switchLiteMode == nil)
    {
        _switchLiteMode = [[UISwitch alloc] init];
    }
    
    return _switchLiteMode;
}

- (UILabel* )labelVideoDataOnlyCollection
{
    if(_labelVideoDataOnlyCollection == nil)
    {
        _labelVideoDataOnlyCollection = [[UILabel alloc] init];
        _labelVideoDataOnlyCollection.textColor = [UIColor whiteColor];
        _labelVideoDataOnlyCollection.textAlignment = NSTextAlignmentCenter;
        _labelVideoDataOnlyCollection.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelVideoDataOnlyCollection.text = [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title13"];
    }
    return _labelVideoDataOnlyCollection;
}

- (UISwitch* )switchVideoDataOnlyCollection
{
    if(_switchVideoDataOnlyCollection == nil)
    {
        _switchVideoDataOnlyCollection = [[UISwitch alloc] init];
    }
    
    return _switchVideoDataOnlyCollection;
}

- (UILabel* )labelSelectIDCardInDesk
{
    if(_labelSelectIDCardInDesk == nil)
    {
        _labelSelectIDCardInDesk = [[UILabel alloc] init];
        _labelSelectIDCardInDesk.textColor = [UIColor whiteColor];
        _labelSelectIDCardInDesk.textAlignment = NSTextAlignmentCenter;
        _labelSelectIDCardInDesk.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        _labelSelectIDCardInDesk.text = [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title12"];
    }
    return _labelSelectIDCardInDesk;
}

- (UISwitch* )switchSelectIDCardInDesk
{
    if(_switchSelectIDCardInDesk == nil)
    {
        _switchSelectIDCardInDesk = [[UISwitch alloc] init];
        //[_switchSelectIDCardInDesk addTarget:self action:@selector(switchSelectIDCardInDesk:) forControlEvents:UIControlEventValueChanged];  // 开关事件切换通知
    }
    
    return _switchSelectIDCardInDesk;
}

- (SettingView* )settingView
{
    if(_settingView == nil)
    {
        _settingView = [[SettingView alloc] init];
        _settingView.hidden = YES;
    }
    
    return _settingView;
}

- (UILabel* )labelIP
{
    if(_labelIP == nil)
    {
        _labelIP = [[UILabel alloc] init];
        _labelIP.textColor = [UIColor whiteColor];
        _labelIP.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelIP.textAlignment = NSTextAlignmentCenter;
        _labelIP.text = [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title1"];
    }
    return  _labelIP;
}

- (UILabel* )labelAppVersion
{
    if(_labelAppVersion == nil)
    {
        _labelAppVersion = [[UILabel alloc] init];
        _labelAppVersion.textColor = [UIColor whiteColor];
        _labelAppVersion.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelAppVersion.textAlignment = NSTextAlignmentCenter;
        _labelAppVersion.text = [NSString stringWithFormat:@"App %@: %@", [DSLHKIDCardBundle IDCardBundleString:@"main_vc_title9"], [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
    }
    return  _labelAppVersion;
}

- (UploadVideoTipView* )uploadVideoTipView
{
    if(_uploadVideoTipView == nil)
    {
        _uploadVideoTipView = [[UploadVideoTipView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-305)/2, (self.view.bounds.size.height-430)/2, 305, 430)];
        _uploadVideoTipView.myDelegate = self;
    }
    return _uploadVideoTipView;
}

- (UIButton* )btnGotoRec
{
    if(_btnGotoRec == nil)
    {
        _btnGotoRec = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnGotoRec.frame = CGRectMake((self.view.bounds.size.width - 236)/2.0,(self.view.frame.size.height)/2-96, 236, 48);
        [_btnGotoRec setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title2"] forState:UIControlStateNormal];
        [_btnGotoRec setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //[_btnGotoRec setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateHighlighted];
        [_btnGotoRec setBackgroundColor:[UIColor dslc_colorWithHexString:@"0x04C3DD"]];
        _btnGotoRec.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        _btnGotoRec.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x04C3DD"].CGColor;
        [_btnGotoRec addTarget:self action:@selector(clickGotoRec:) forControlEvents:UIControlEventTouchUpInside];
        _btnGotoRec.layer.cornerRadius = 20;
        _btnGotoRec.layer.borderWidth = 2;
    }
    
    return _btnGotoRec;
}

- (UIButton* )btnReplay
{
    if(_btnReplay == nil)
    {
        _btnReplay = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnReplay.frame = CGRectMake((self.view.bounds.size.width - 236)/2.0,(self.view.frame.size.height)/2-24, 236, 48);
        [_btnReplay setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title3"] forState:UIControlStateNormal];
        [_btnReplay setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //[_btnGotoRec setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateHighlighted];
        [_btnReplay setBackgroundColor:[UIColor clearColor]];
        _btnReplay.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        _btnReplay.layer.borderColor = [UIColor dslc_colorWithHexString:@"0x04C3DD"].CGColor;
        [_btnReplay addTarget:self action:@selector(clickReplay:) forControlEvents:UIControlEventTouchUpInside];
        _btnReplay.layer.cornerRadius = 24;
        _btnReplay.layer.borderWidth = 1;
    }
    
    return _btnReplay;
}

- (UIImageView* )imgViewPlayerBK
{
    if(_imgViewPlayerBK == nil)
    {
        _imgViewPlayerBK = [[UIImageView alloc] initWithFrame:self.view.bounds];
        _imgViewPlayerBK.backgroundColor = [UIColor blackColor];
        _imgViewPlayerBK.alpha = 0.86;
    }
    
    return _imgViewPlayerBK;
}

- (UIImageView* )imgViewShadowBK
{
    if(_imgViewShadowBK == nil)
    {
        _imgViewShadowBK = [[UIImageView alloc] initWithFrame:self.view.bounds];
        _imgViewShadowBK.backgroundColor = [UIColor blackColor];
        _imgViewShadowBK.alpha = 0.78;
        //_imgViewOverlayBk.image = [UIImage imageNamed:@"overlayBk"];
    }
    
    return _imgViewShadowBK;
}

- (UIImage*)createImageWithColor: (UIColor*) color{
    
    CGRect rect=CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return theImage;
}

//- (void)switchSelectIDCardInDesk:(id)sender
//{
//
//}

- (void)playOver:(NSNotification *)notification
{
    [self.view addSubview:self.imgViewPlayerBK];
    [self.view addSubview:self.btnGotoRec];
    [self.view addSubview:self.btnReplay];
    
    [self.btnPassVideo removeFromSuperview];
}

- (void)addNotify
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playOver:) name:AVPlayerItemDidPlayToEndTimeNotification object:nil];
}

- (BOOL) bPlayVideo
{
    _bPlayVideo = [[[NSUserDefaults standardUserDefaults] objectForKey:PLAYVIDEOSTATUS] boolValue];
    return _bPlayVideo;
}

- (void)dealloc
{
    [self.moviePlayer.player removeObserver:self forKeyPath:@"status"];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    if(self.bPlayVideo)
//    {
//        self.moviePlayer;
//    }
    
    self.bPlayVideo =  [[[NSUserDefaults standardUserDefaults] objectForKey:PLAYVIDEOSTATUS] boolValue];
    if(!self.bPlayVideo)
    {
        [self.settingView saveStatus:@"1" key:PLAYVIDEOSTATUS];
        [self.settingView updateUIStatus];
    }
    
    [self addNotify];
    
    UIImageView *backgroundImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"main_bk"]];
    backgroundImageView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    [self.view addSubview:backgroundImageView];
    
    UIImageView *mainLogoImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"main_logo"]];
    mainLogoImageView.frame = CGRectMake((self.view.bounds.size.width-202)/2, 200, 202, 73);
    [self.view addSubview:mainLogoImageView];
    
    [self.view addSubview:self.labelSelectIDCardInDesk];
    self.labelSelectIDCardInDesk.frame = CGRectMake(mainLogoImageView.frame.origin.x,60, 100.0, 32.0);
    
    [self.view addSubview:self.switchSelectIDCardInDesk];
    self.switchSelectIDCardInDesk.frame = CGRectMake(self.labelSelectIDCardInDesk.frame.origin.x+self.labelSelectIDCardInDesk.frame.size.width+10.0,60, 40.0, 32.0);
    
    [self.view addSubview:self.labelVideoDataOnlyCollection];
    self.labelVideoDataOnlyCollection.frame = CGRectMake(mainLogoImageView.frame.origin.x,self.switchSelectIDCardInDesk.frame.origin.y+40.0, 100.0, 32.0);
    
    [self.view addSubview:self.switchVideoDataOnlyCollection];
    self.switchVideoDataOnlyCollection.frame = CGRectMake(self.labelVideoDataOnlyCollection.frame.origin.x+self.labelVideoDataOnlyCollection.frame.size.width+10.0,self.switchSelectIDCardInDesk.frame.origin.y+40.0, 40.0, 32.0);
    
    [self.view addSubview:self.labelLiteMode];
    self.labelLiteMode.frame = CGRectMake(mainLogoImageView.frame.origin.x,self.labelVideoDataOnlyCollection.frame.origin.y+40, 100.0, 32.0);
    
    [self.view addSubview:self.switchLiteMode];
    self.switchLiteMode.frame = CGRectMake(self.labelLiteMode.frame.origin.x+self.labelLiteMode.frame.size.width+10.0,self.switchVideoDataOnlyCollection.frame.origin.y+40.0, 40.0, 32.0);
    
    UIButton* settingBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    settingBtn.frame = CGRectMake(self.view.bounds.size.width - 100,60, 60, 28);
    [settingBtn setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title4"] forState:UIControlStateNormal];
    [settingBtn setTitleColor:[UIColor dslc_colorWithHexString:@"0xFCFEFE"] forState:UIControlStateNormal];
    [settingBtn setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateHighlighted];
    settingBtn.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
    [settingBtn addTarget:self action:@selector(clickSettingBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:settingBtn];
    
    [self.view addSubview:self.settingView];
    self.settingView.frame = CGRectMake(self.view.bounds.size.width - 190-10-60,settingBtn.frame.origin.y+settingBtn.frame.size.height+20.0, 190+50, 50);
    
    _ocrButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _ocrButton.frame = CGRectMake((self.view.bounds.size.width - 236)/2.0,(self.view.frame.size.height-44)/2, 236, 44);
    [_ocrButton setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title5"] forState:UIControlStateNormal];
    [_ocrButton setTitleColor:[UIColor dslc_colorWithHexString:@"0xFCFEFE"] forState:UIControlStateNormal];
    [_ocrButton setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateHighlighted];
    [_ocrButton setBackgroundImage:[UIImage imageNamed:@"main_video_btn_selected"] forState:UIControlStateHighlighted];
    _ocrButton.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:20];
    _ocrButton.layer.borderColor = [UIColor whiteColor].CGColor;
    _ocrButton.layer.cornerRadius = 20;
    _ocrButton.layer.borderWidth = 2;
    
    _ocrButton.tag = 100;
    [self.view addSubview:_ocrButton];
    [_ocrButton addTarget:self action:@selector(selectedRecType:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *testButton1 = [UIButton buttonWithType:UIButtonTypeCustom];
    testButton1.frame = CGRectMake((self.view.bounds.size.width - 236)/2.0, _ocrButton.frame.origin.y+_ocrButton.frame.size.height+40, 236, 44);
    [testButton1 setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title6"] forState:UIControlStateNormal];
    
    [testButton1 setTitleColor:[UIColor dslc_colorWithHexString:@"0xFCFEFE"] forState:UIControlStateNormal];
    [testButton1 setTitleColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"] forState:UIControlStateHighlighted];
    [testButton1 setBackgroundImage:[UIImage imageNamed:@"main_video_btn_selected"] forState:UIControlStateHighlighted];
    testButton1.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:20];
    testButton1.tag = 200;
    testButton1.layer.borderColor = [UIColor whiteColor].CGColor;
    testButton1.layer.cornerRadius = 20;
    testButton1.layer.borderWidth = 2;
    [self.view addSubview:testButton1];
    [testButton1 addTarget:self action:@selector(selectedRecType:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *logoutButton = [UIButton buttonWithType:UIButtonTypeCustom];
    logoutButton.frame = CGRectMake((self.view.bounds.size.width - 250)/2.0, testButton1.frame.origin.y+testButton1.frame.size.height+44, 250, 44);
    [logoutButton setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title7"] forState:UIControlStateNormal];
    [logoutButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    logoutButton.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:20];
    [logoutButton setBackgroundImage:[UIImage imageNamed:@"main_video_btn_selected"] forState:UIControlStateHighlighted];
    logoutButton.layer.borderColor = [UIColor whiteColor].CGColor;
    logoutButton.layer.cornerRadius = 20;
    logoutButton.layer.borderWidth = 2;
    logoutButton.tag = 300;
    [self.view addSubview:logoutButton];
    [logoutButton addTarget:self action:@selector(logoutBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:self.labelIP];
    self.labelIP.frame = CGRectMake(0.0, logoutButton.frame.origin.y+logoutButton.frame.size.height+30, self.view.bounds.size.width, 20);
    self.labelIP.hidden = YES;
    
    UIButton* serviceVersionBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [serviceVersionBtn setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title10"] forState:UIControlStateNormal];
    NSMutableAttributedString* muAttrStr = [[NSMutableAttributedString alloc] initWithString:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title10"]];
    NSRange r = {0, muAttrStr.length};
    [muAttrStr addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:r];
    [muAttrStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:12] range:r];
    [serviceVersionBtn setAttributedTitle:muAttrStr forState:UIControlStateNormal];
    
    [serviceVersionBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    serviceVersionBtn.frame = CGRectMake(0.0, self.view.bounds.size.height-80, self.view.bounds.size.width, 40);
    [self.view addSubview:serviceVersionBtn];
    [serviceVersionBtn addTarget:self action:@selector(checkServicVersion:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.labelAppVersion];
    self.labelAppVersion.frame = CGRectMake(0.0, self.view.bounds.size.height-40, self.view.bounds.size.width, 20);
    
    
    UIImageView *logoImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Logo"]];
    logoImageView.frame = CGRectMake((self.view.bounds.size.width-151)/2, self.view.frame.size.height-90, 151, 39);
    [self.view addSubview:logoImageView];
    
    
    
    [self.view addSubview:self.imgViewShadowBK];
    self.imgViewShadowBK.hidden = YES;
    [self.view addSubview:self.uploadVideoTipView];
    self.uploadVideoTipView.hidden = YES;
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)showUploadVideoTip
{
//    self.imgViewShadowBK.hidden = NO;
//    //self.uploadVideoTipView.hidden = NO;
    
    AgreementViewController* agreementVc = [[AgreementViewController alloc] init];
    agreementVc.myDelegate = self;
    agreementVc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:agreementVc animated:YES completion:^{
         
       }];

}


- (NSDate *)dateFromString:(NSString *)string withFormat:(NSString *)format {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    NSDate *date = [formatter dateFromString:string];
    return date;
}

- (BOOL)checkIsExpired
{
    NSDate* expiredDate = [self dateFromString:ExpiredDateStr withFormat:@"yyyy-MM-dd"];
    if([[NSDate date] compare:expiredDate] == NSOrderedDescending)
    {
        return YES;
    }
    
    return NO;
}

- (void)checkServicVersion:(id)sender
{
    [IRNetworkEngine getServiceVersion:@"/version" completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            NSArray* arr = result;
            NSMutableString* muStr = [NSMutableString stringWithCapacity:4];
            for(int i = 0; i < [arr count]; ++i)
            {
                NSDictionary* dic = [arr objectAtIndex:i];
                [muStr appendFormat:@"%@", dic[@"service_name"]];
                [muStr appendString:@"\n"];
                [muStr appendFormat:@"version: %@", dic[@"version"]];
                [muStr appendString:@"\n"];
                [muStr appendFormat:@"release_date: %@", dic[@"release_date"]];
                [muStr appendString:@"\n"];
                [muStr appendString:@"\n"];
            }

            [self showAlterController:muStr title:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title11"]];
            
        });
    }];
   
  
    
}
- (void)selectedRecType:(id)sender
{
    UIButton* btn = (UIButton* )sender;
    
    self.selectedType = (int)btn.tag;
    if(SHOW_UPLOAD_VIDEO_TIP)
    {
        [self showUploadVideoTip];
    }
    else
    {
        if(!self.bPlayVideo)
        {
            [self showRecVc];
        }
        else
        {
            [self showVideo];
        }
    }
    
}

- (void)logoutBtn:(id)sender
{
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:USER_NAME];
    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:PASSWORD];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[AppDelegate sharedInstance] gotoLoginVc];
}

- (void)gotoOCRIDCardAntiVC:(id)sender
{
    
    DSLHKBaseIDCardViewController *vc = [[DSLHKBaseIDCardViewController alloc] init];
    if(self.switchSelectIDCardInDesk.on)
    {
        vc = [[DSLHKIDCardInDeskViewController alloc] init];
        vc.iOpType = 1;
    }
    else
    {
        vc = [[DSLHKIDCardViewController alloc] init];
        vc.iOpType = 0;
    }
    
    vc.useLiteVersion = self.switchLiteMode.on;
    
    vc.isVideoDataOnlyCollectionMode = self.switchVideoDataOnlyCollection.on;
    
    vc.recType = DSLHKIDCardTypeApp_2003;
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:^{
        self.uploadVideoTipView.hidden = YES;
        self.imgViewShadowBK.hidden = YES;
        if(self.bPlayVideo)
        {
            [self removeMoviePlayerUI];
        }
    }];
}

-(void)gotoOCRIDCardVC:(id)sender{
    DSLHKBaseIDCardViewController *vc = [[DSLHKBaseIDCardViewController alloc] init];
    if(self.switchSelectIDCardInDesk.on)
    {
        vc = [[DSLHKIDCardInDeskViewController alloc] init];
        vc.iOpType = 1;
    }
    else
    {
        vc = [[DSLHKIDCardViewController alloc] init];
        vc.iOpType = 0;
    }
    
    vc.useLiteVersion = self.switchLiteMode.on;
    vc.isVideoDataOnlyCollectionMode = self.switchVideoDataOnlyCollection.on;
    vc.recType = DSLHKIDCardTypeApp_2018;
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:^{
        self.uploadVideoTipView.hidden = YES;
        self.imgViewShadowBK.hidden = YES;
        if(self.bPlayVideo)
        {
            [self removeMoviePlayerUI];
        }
    }];
}


- (void)clickUploadVideoTipOK
{
    NSString* selected = [[NSUserDefaults standardUserDefaults] objectForKey:@"selected"];
    if(selected != nil && [selected isEqualToString:@"200"])
    {
        self.uploadVideoTipView.hidden = YES;
        self.imgViewShadowBK.hidden = YES;
        return; //拒绝，不能继续操作
    }
    else if(selected != nil)
    {
        self.uploadVideoTipView.hidden = YES;
        self.imgViewShadowBK.hidden = YES;
        
        if(!self.bPlayVideo)
        {
            [self showRecVc];
        }
        else
        {
            [self showVideo];
        }
    }
    
}

- (void)showRecVc
{
    if(self.selectedType == 100)
    {
        [self gotoOCRIDCardVC:nil];
    }
    else if(self.selectedType == 200)
    {
        [self gotoOCRIDCardAntiVC:nil];
    }
    
}

#pragma mark-- 播放视频
-(AVPlayerViewController *)moviePlayer{
        
    if (!_moviePlayer)
    {
        _moviePlayer = [[AVPlayerViewController alloc] init];
        _moviePlayer.view.frame = self.view.bounds;
        
    }
    
    return _moviePlayer;
}

- (AVPlayer* )player
{
    NSString* videoUrl = @"";

    if(self.selectedType == 100)    //2018证件
     {
         if(self.switchSelectIDCardInDesk.on)
         {
             videoUrl = [[NSBundle mainBundle] pathForResource:@"desk_2018" ofType:@"mp4"];
         }
         else
         {
             videoUrl = [[NSBundle mainBundle] pathForResource:@"hold_2018" ofType:@"mp4"];
         }
     }
     else if(self.selectedType == 200)   //2003证件
     {
        if(self.switchSelectIDCardInDesk.on)
        {
            videoUrl = [[NSBundle mainBundle] pathForResource:@"desk_2003" ofType:@"mp4"];
        }
        else
        {
            videoUrl = [[NSBundle mainBundle] pathForResource:@"hold_2003" ofType:@"mp4"];
        }
     }
    
    if(_player != nil)
    {
         [_player removeObserver:self forKeyPath:@"status"];
    }

    _player = [AVPlayer playerWithURL:[NSURL fileURLWithPath:videoUrl]];
    [_player addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew context:nil];
    
    return _player;
}
  
- (AVPlayerItem* )playerItem
{
    if(_playerItem == nil)
    {
        NSString* videoUrl = [[NSBundle mainBundle] pathForResource:@"sampleVideo" ofType:@"mp4"];
        _playerItem = [AVPlayerItem playerItemWithURL:[NSURL fileURLWithPath:videoUrl]];
    }
    return _playerItem;
}
- (UIButton* )btnPassVideo
{
    if(_btnPassVideo == nil)
    {
        _btnPassVideo = [UIButton buttonWithType:UIButtonTypeCustom];
        _btnPassVideo.frame = CGRectMake(20.0, kiPhoneX ? 110.0 : 40, 68.0, 28.0);
        [_btnPassVideo setTitle:[DSLHKIDCardBundle IDCardBundleString:@"main_vc_title8"] forState:UIControlStateNormal];
        [_btnPassVideo setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnPassVideo setBackgroundColor:[UIColor blackColor]];
        _btnPassVideo.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _btnPassVideo.layer.borderColor = [UIColor blackColor].CGColor;
        _btnPassVideo.layer.cornerRadius = 14;
        _btnPassVideo.layer.borderWidth = 2;
        [_btnPassVideo addTarget:self action:@selector(clickBtnPassVideo:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnPassVideo;
    
}



- (void)clickGotoRec:(id)sendr
{
    [self showRecVc];
}

- (void)clickReplay:(id)sendr
{
    [self.view addSubview:self.btnPassVideo];
    
    [self.btnReplay removeFromSuperview];
    [self.btnGotoRec removeFromSuperview];
    [self.imgViewPlayerBK removeFromSuperview];
    self.btnReplay = nil;
    self.btnGotoRec = nil;
    self.imgViewPlayerBK = nil;
    
    CGFloat a=0;
    NSInteger dragedSeconds = floorf(a);
    CMTime dragedCMTime = CMTimeMake(dragedSeconds, 1);
    [self.moviePlayer.player seekToTime:dragedCMTime];
    
    if (self.moviePlayer.readyForDisplay) {
        [self.moviePlayer.player play];
    }
    
}
- (void)clickBtnPassVideo:(id)sender
{
    [self showRecVc];
}

- (void)clickSettingBtn:(id)sender
{
    if(Is_Local_Save)
    {
        ShowLocalDataViewController* showVc = [[ShowLocalDataViewController alloc] init];
          [self presentViewController:showVc animated:YES completion:^{

          }];
    }
    else
    {
         self.settingView.hidden = !self.settingView.hidden;
    }

}
- (void)showVideo
{
    self.moviePlayer.player = self.player;
    
    [self.view addSubview:self.moviePlayer.view];
    
    [self.view addSubview:self.btnPassVideo];

}

- (void)removeMoviePlayerUI
{
    [self.moviePlayer.player pause];
    [self.moviePlayer.view removeFromSuperview];
    
    CGFloat a=0;
    NSInteger dragedSeconds = floorf(a);
    CMTime dragedCMTime = CMTimeMake(dragedSeconds, 1);
    [self.moviePlayer.player seekToTime:dragedCMTime];
    
    [self.btnPassVideo removeFromSuperview];
    [self.btnReplay removeFromSuperview];
    [self.btnGotoRec removeFromSuperview];
    [self.imgViewPlayerBK removeFromSuperview];
    
    self.btnPassVideo = nil;
    self.btnReplay = nil;
    self.btnGotoRec = nil;
    self.imgViewPlayerBK = nil;
}

- (void)showAlterController:(NSString* )msg title:(NSString* )title
{
    //@"App使用已過期，請聯系供應商"
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:[DSLHKIDCardBundle IDCardBundleString:@"upload_video_tip5"] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [actionSheet addAction:action1];
    
    [self presentViewController:actionSheet animated:YES completion:nil];
}

#pragma mark-- AgreementVcDelegate methods
- (void)agreement:(BOOL)agree
{
    if(agree)
    {
        [self dismissViewControllerAnimated:NO completion:^{
        if(!self.bPlayVideo)
        {
            [self showRecVc];
        }
        else
        {
            [self showVideo];
        }
        }];
    }
    else
    {
        [self dismissViewControllerAnimated:NO completion:nil];
    }
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    AVPlayer* player = (AVPlayer*)object;
    if([keyPath isEqualToString:@"status"])
    {
        if(player.status == AVPlayerStatusReadyToPlay)
        {
             [self.moviePlayer.player play];
        }
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}
@end
