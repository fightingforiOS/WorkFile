//
//  ResultFaceView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/23.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ResultFaceView : UIView

- (instancetype)initWithFrame:(CGRect)frame IDCardHead:(UIImage* )idCardHead FaceHead:(UIImage* )faceHead FaceSimilarity:(double)similarity FaceVerifyValid:(BOOL)bFaceVerifyValid;

- (void)delayShowFaceSimilarity;
- (void)delayShowLiveDetectTip;

@end

NS_ASSUME_NONNULL_END
