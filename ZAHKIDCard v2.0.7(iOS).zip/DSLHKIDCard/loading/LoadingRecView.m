//
//  LoadingRecView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/28.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "LoadingRecView.h"
#import "DGActivityIndicatorView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"
@interface LoadingRecView()

@property(nonatomic, strong) UILabel* labelTitle;
@property(nonatomic, strong) UIActivityIndicatorView* activityIndicatorView;
@property(nonatomic, strong) DGActivityIndicatorView* dGActivityIndicatorView;

@end

@implementation LoadingRecView


- (instancetype) initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    return self;
}

- (void)setupView
{
    self.backgroundColor = [UIColor whiteColor];
    //self.layer.backgroundColor = [UIColor whiteColor].CGColor;
    //self.layer.borderWidth = 1.0;
    self.layer.cornerRadius = 5;
    self.layer.masksToBounds = YES;
    
    float viewW = self.bounds.size.width;
    
    [self addSubview:self.dGActivityIndicatorView];
    self.dGActivityIndicatorView.frame =CGRectMake((viewW-100)/2, 20.0, 100, 100);

    [self.dGActivityIndicatorView startAnimating];
    
    [self addSubview:self.labelTitle];
    self.labelTitle.frame = CGRectMake(0, self.dGActivityIndicatorView.frame.origin.y+self.dGActivityIndicatorView.frame.size.height-5, viewW, 24);
    
}

- (UILabel* )labelTitle
{
    if(_labelTitle == nil)
    {
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.text = [DSLHKIDCardBundle IDCardBundleString:@"loading_rec_title1"];
    }
    return  _labelTitle;
}

- (UIActivityIndicatorView* )activityIndicatorView
{
    if(_activityIndicatorView == nil)
    {
        _activityIndicatorView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:(UIActivityIndicatorViewStyleWhiteLarge)];
        _activityIndicatorView.color = [UIColor grayColor];
        //_activityIndicatorView.backgroundColor = [UIColor blueColor];
    }
    
    return _activityIndicatorView;
}

- (DGActivityIndicatorView* )dGActivityIndicatorView
{
    if(_dGActivityIndicatorView == nil)
    {
        _dGActivityIndicatorView = [[DGActivityIndicatorView alloc] initWithType:DGActivityIndicatorAnimationTypeBallPulse tintColor:[UIColor dslc_colorWithHexString:@"0x02A6CA"]];
    }
    
    return _dGActivityIndicatorView;
}

- (void)setLoadingTitle:(NSString* )tilte
{
    self.labelTitle.text = tilte;
}

@end
