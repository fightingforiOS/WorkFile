//
//  STConstants.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/5/26.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#ifndef STConstants_h
#define STConstants_h

#pragma mark -event property

//登录账号
NSString* const DSL_ST_EVENT_PROPERTY_USER_ID = @"user_id";
//事件来源
NSString* const DSL_ST_EVENT_PROPERTY_SOURCE = @"source";
//设备ID
NSString* const DSL_ST_EVENT_PROPERTY_DEVICE_ID = @"device_id";
//会话ID,记录app从打开到关闭过程周期(识别成功会重新初始化)
NSString* const DSL_ST_EVENT_PROPERTY_SESSION_ID = @"session_id";
//设备名称
NSString* const DSL_ST_EVENT_PROPERTY_DEVICE_NAME = @"device_name";
//App 版本号
NSString* const DSL_ST_EVENT_PROPERTY_APP_VERSION = @"app_version";
//SDK 版本号
NSString* const DSL_ST_EVENT_PROPERTY_SDK_VERSION = @"sdk_version";
//手机系统版本号
NSString* const DSL_ST_EVENT_PROPERTY_OS_VERSION = @"os_version";
//设备型号
NSString* const DSL_ST_EVENT_PROPERTY_DEVICE_MODEL = @"device_model";
//设备品牌
NSString* const DSL_ST_EVENT_PROPERTY_BRAND = @"brand";
//系统语言
NSString* const DSL_ST_EVENT_PROPERTY_LANGUAGE = @"language";
//日志记录时间,时间发生的时间戳,单位毫秒
NSString* const DSL_ST_EVENT_PROPERTY_TIME_STAMP = @"time_stamp";
//一次操作持续时间
NSString* const DSL_ST_EVENT_PROPERTY_DURATION_TIME = @"duration_time";
//失败原因，0：曝光、1：目标丢失、2：超时、3：光线过暗
NSString* const DSL_ST_EVENT_PROPERTY_FAIL_REASON = @"fail_reason";
//警告信息，INVALID、BLUR、FAR、NEAR、OUT_OF_RANGE、NO_PARALLEL_TO_MOBILEPHONE、TILT这些警告信息在一次操作失败或成功中出现的次数
NSString* const DSL_ST_EVENT_PROPERTY_WARN_INFO = @"warn_info";
//成功
NSString* const DSL_ST_EVENT_PROPERTY_SUCCESS = @"success";
//成功前失败的次数
NSString* const DSL_ST_EVENT_PROPERTY_FAIL_COUNT = @"fail_count";
//0：手持版；1：桌面版
NSString* const DSL_ST_EVENT_PROPERTY_OP_VERSION_TYPE = @"op_version_type";
//识别证件类型：2003/2018
NSString* const DSL_ST_EVENT_PROPERTY_ID_CARD_TYPE = @"id_card_type";
//上传的视频大小，单位/KB
NSString* const DSL_ST_EVENT_PROPERTY_VIDEO_SIZE = @"video_size";
//上传的视频时长，单位/秒
NSString* const DSL_ST_EVENT_PROPERTY_VIDEO_TIME_LENGTH = @"video_time_length";

//具体警告原因
//找不到证件
NSString* const DSL_ST_EVENT_PROPERTY_WARN_INVALID = @"invalid";
//视频模糊
NSString* const DSL_ST_EVENT_PROPERTY_WARN_BLUR = @"blur";
//距离过远
NSString* const DSL_ST_EVENT_PROPERTY_WARN_FAR = @"far";
//距离过近
NSString* const DSL_ST_EVENT_PROPERTY_WARN_NEAR = @"near";
//证件超出范围，不在框内
NSString* const DSL_ST_EVENT_PROPERTY_WARN_OUT_OF_RANGE = @"out_of_range";
//证件没有与手机平行放置
NSString* const DSL_ST_EVENT_PROPERTY_WARN_NO_PARALLEL_TO_MOBILEPHONE = @"no_parallel_to_mobilephone";
//证件倾斜
NSString* const DSL_ST_EVENT_PROPERTY_WARN_TILT = @"tilt";

#endif /* STConstants_h */
