//
//  DGActivityIndicatorLineScalePulseOutRapidAnimation.h
//  DGActivityIndicatorExample
//
//  Created by Nguyen Vinh on 7/20/15.
//  Copyright (c) 2015 Danil Gontovnik. All rights reserved.
//

#import "DGActivityIndicatorAnimation.h"

@interface DGActivityIndicatorLineScalePulseOutRapidAnimation: DGActivityIndicatorAnimation

@end
