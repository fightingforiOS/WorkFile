//
//  TotalResultView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import "TotalResultView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLHKIDCardBundle.h"

@interface TotalResultView()

@property(nonatomic, strong) UILabel* labelTotalScore;
@property(nonatomic, strong) UILabel* labelVideoQuality;
@property(nonatomic, strong) UILabel* labelTip;
@property(nonatomic, strong) UILabel* labelManualProcess;
@property(nonatomic, strong) UIButton* btnExplain;

@end

@implementation TotalResultView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

- (void)setTotalResult:(NSString* )strTotalScore VideoQuality:(NSString* )videoQuality TotalScoreColor:(UIColor* )color IsShowTipText:(BOOL) showTipText LevelRisk:(int) levelRisk
{
    self.labelTip.hidden = !showTipText;
    
    NSString* str = [NSString stringWithFormat:@"%@:   %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title48"], strTotalScore];
    NSMutableAttributedString* mAttribute = [[NSMutableAttributedString alloc] initWithString:str];
    int blackLength = 4;
    if([self isCurrentLanguageEn])
    {
        blackLength = 17;
    }
    
    [mAttribute addAttribute:NSForegroundColorAttributeName
                       value:[UIColor blackColor]
                       range:NSMakeRange(0, blackLength)];
    [mAttribute addAttribute:NSForegroundColorAttributeName
                       value:color
                       range:NSMakeRange(blackLength, str.length-blackLength)];
    
    [mAttribute addAttribute:NSFontAttributeName
                       value:[UIFont systemFontOfSize:12]
                       range:NSMakeRange(blackLength, str.length-blackLength)];
    
    self.labelTotalScore.attributedText = mAttribute;
    
    self.labelVideoQuality.text = [NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title49"], videoQuality];
    
    NSString* strLevelRiskTip = [DSLHKIDCardBundle IDCardBundleString:@"result_title62"];
    if(levelRisk == -1)
    {
        strLevelRiskTip = [DSLHKIDCardBundle IDCardBundleString:@"result_title63"];
    }
    else if(levelRisk == 1)
    {
        strLevelRiskTip = [DSLHKIDCardBundle IDCardBundleString:@"result_title61"];
    }
    self.labelManualProcess.text = [NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title60"],  strLevelRiskTip];
}
- (void)setupView
{
//    self.layer.borderColor = [UIColor redColor].CGColor;
//    self.layer.borderWidth = 1;
    self.layer.cornerRadius = 5.0;
    self.backgroundColor = [UIColor dslc_colorWithHexString:@"0xF3F3F3"];
    [self addSubview:self.btnExplain];
    [self addSubview:self.labelTotalScore];
    [self addSubview:self.labelVideoQuality];
    [self addSubview:self.labelManualProcess];
    [self addSubview:self.labelTip];
    
    self.btnExplain.frame = CGRectMake(self.bounds.size.width-25, 6, 20, 20);
    self.labelTotalScore.frame = CGRectMake(16, 18, self.bounds.size.width-20, 20);
    self.labelVideoQuality.frame = CGRectMake(16, self.labelTotalScore.frame.origin.y+self.labelTotalScore.frame.size.height+10, self.bounds.size.width-20, 20);
    self.labelManualProcess.frame = CGRectMake(16, self.labelVideoQuality.frame.origin.y+self.labelVideoQuality.frame.size.height+10, self.bounds.size.width-20, 20);
    self.labelTip.frame = CGRectMake(16, self.labelManualProcess.frame.origin.y+self.labelManualProcess.frame.size.height+10, self.bounds.size.width-20, 16);
}

- (UILabel* )labelTotalScore
{
    if(_labelTotalScore == nil)
    {
        _labelTotalScore = [[UILabel alloc] init];
        _labelTotalScore.textColor = [UIColor blackColor];
        _labelTotalScore.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        _labelTotalScore.textAlignment = NSTextAlignmentLeft;
        _labelTotalScore.text = @"";
    }
    return  _labelTotalScore;
}

- (UILabel* )labelVideoQuality
{
    if(_labelVideoQuality == nil)
    {
        _labelVideoQuality = [[UILabel alloc] init];
        _labelVideoQuality.textColor = [UIColor blackColor];
        _labelVideoQuality.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        _labelVideoQuality.textAlignment = NSTextAlignmentLeft;
        _labelVideoQuality.text = @"";
    }
    return  _labelVideoQuality;
}

- (UILabel* )labelTip
{
    if(_labelTip == nil)
    {
        _labelTip = [[UILabel alloc] init];
        _labelTip.textColor = [UIColor blackColor];
        _labelTip.alpha = 0.3;
        _labelTip.font = [UIFont fontWithName:@"PingFangSC-Regular" size:12];
        _labelTip.textAlignment = NSTextAlignmentLeft;
        _labelTip.text = [DSLHKIDCardBundle IDCardBundleString:@"result_title50"];
    }
    return  _labelTip;
}

- (UILabel* )labelManualProcess
{
    if(_labelManualProcess == nil)
    {
        _labelManualProcess = [[UILabel alloc] init];
        _labelManualProcess.textColor = [UIColor blackColor];
        _labelManualProcess.font = [UIFont fontWithName:@"PingFangSC-Regular" size:16];
        _labelManualProcess.textAlignment = NSTextAlignmentLeft;
        _labelManualProcess.text = @"";
    }
    return  _labelManualProcess;
}

- (UIButton* )btnExplain
{
    if(_btnExplain == nil)
    {
        _btnExplain = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnExplain setImage:[UIImage imageNamed:@"result_explain"] forState:UIControlStateNormal];
        [_btnExplain addTarget:self action:@selector(clickBtnExplain:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnExplain;
}

- (void)clickBtnExplain:(id)sender
{
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(clickTotalResultViewExplain)])
        {
            [self.myDelegate clickTotalResultViewExplain];
        }
    }
}
@end
