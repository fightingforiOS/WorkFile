//
//  ResultInfoModel.h
//  TestHKIDCard
//
//  Created by chenliqun on 2018/12/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ResultInfoModel : NSObject

@property(nonatomic,copy)NSString *certiType;
@property(nonatomic,copy)NSString *firstName;
@property(nonatomic,copy)NSString *lastName;
@property(nonatomic,copy)NSString *gender;
@property(nonatomic,copy)NSString *certiNo;
@property(nonatomic,copy)NSString *birthday;
@property(nonatomic,copy)NSString *faceDetected;
@property(nonatomic,assign)BOOL antiOK;

@property(nonatomic,assign)BOOL bFaceVerifyValid;

@property(nonatomic,assign)BOOL bColorPrinting; //彩虹印刷是否通过(彩虹印刷)
@property(nonatomic,assign)BOOL bFaceSimilarity;    //证件人脸对比是否通过(证件人像比对)
@property(nonatomic,assign)BOOL bImageQuality;
@property(nonatomic,assign)BOOL bLaserFace; //镭射人脸是否通过(镭射人像)
@property(nonatomic,assign)BOOL bLaserRedbud;   //镭射紫金花是否通过(镭射花标)
@property(nonatomic, assign) double laserRedbudScore;//镭射紫金花得分
@property(nonatomic, assign) BOOL bTampered;   //证件是否被篡改

@property(nonatomic, assign)double similarity;

@property(nonatomic, assign)double authenticity;    //分数
@property(nonatomic, assign)double low_threshold;    //低分数
@property(nonatomic, assign)double high_threshold;    //高分数

@property(nonatomic, assign)double qualityScore;    //视频质量分数
@property(nonatomic, assign) double qualitythreshold;        //视频质量阈值分数

@property(nonatomic, assign) BOOL bHighlight;   //图像亮度

@property(nonatomic, assign) BOOL bReproduction;   //是否翻拍
@property(nonatomic, assign) BOOL bDeep_rtriangle;   //材质检测

//老版特征值
@property(nonatomic, assign) BOOL bHkOld;   //动感印刷
@property(nonatomic, assign) BOOL bTriColorOld;   //变色油墨
@property(nonatomic, assign) BOOL bChipOld;   //特征匹配
@property(nonatomic, assign) BOOL bSmallFace;   //动感印刷人脸变化是否通过
@property(nonatomic, assign) BOOL bGradualOld;   //渐淡色背景
@property(nonatomic, strong) NSString* fingerOcclusionNum;   //手指遮挡证件

@property(nonatomic, strong) NSData* imgIdCard;

@end

NS_ASSUME_NONNULL_END
