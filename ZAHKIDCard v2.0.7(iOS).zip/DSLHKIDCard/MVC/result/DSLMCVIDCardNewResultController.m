//
//  DSLMCVIDCardNewResultController.m
//  DSLHKIDCard
//
//  Created by chenliqun13 on 2020/12/1.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "DSLMCVIDCardNewResultController.h"
#import "DSLMCVIDCardBundle.h"
#import "DSLMCVTotalResultView.h"
#import "DSLMCVScoreDefineView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLMCVResutlItemView.h"
#import "AppDelegate.h"

@interface DSLMCVIDCardNewResultController ()<DSLMCVTotalResultViewDelegate>

@property(nonatomic, strong) DSLMCVTotalResultView* totalResultView;
@property(nonatomic, strong) UIButton* btnOk;
@property(nonatomic, strong) UIScrollView* myScrollView;

@end

@implementation DSLMCVIDCardNewResultController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor dslc_colorWithHexString:@"#F9F9F9"];
    
    [self setupView];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (UIScrollView* )myScrollView
{
    if(_myScrollView == nil)
    {
        _myScrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
        _myScrollView.backgroundColor = [UIColor whiteColor];
        _myScrollView.showsVerticalScrollIndicator = NO;
        _myScrollView.showsHorizontalScrollIndicator = NO;
//        _myScrollView.layer.borderColor = [UIColor redColor].CGColor;
//        _myScrollView.layer.borderWidth = 1;
    }
    
    return _myScrollView;
}

- (void)setupView
{
    [self.view addSubview:self.myScrollView];
    
    UIImageView* imgViewHeadBk = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mcv_result_headbk"]];
    imgViewHeadBk.frame = CGRectMake(0.0, 0.0, self.view.bounds.size.width, 218.0);
    [self.myScrollView addSubview:imgViewHeadBk];
    [self.myScrollView sendSubviewToBack:imgViewHeadBk];
    
    UILabel* labelTitle = [UILabel new];
    [labelTitle setTextColor:[UIColor whiteColor]];
    labelTitle.font = [UIFont fontWithName:@"PingFangSC-Medium" size:24];
    labelTitle.textAlignment = NSTextAlignmentCenter;
    labelTitle.text = [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title1"];
    labelTitle.frame = CGRectMake(0.0, 66.0, self.view.bounds.size.width, 28.0);
    [self.myScrollView addSubview:labelTitle];
    
    UIImageView* imgViewFrontIDCard = [[UIImageView alloc] init];
    imgViewFrontIDCard.image = self.imgFrontIDCard;
    imgViewFrontIDCard.frame = CGRectMake((self.view.bounds.size.width-160*2-20)/2, labelTitle.frame.origin.y+labelTitle.frame.size.height+45.0, 160.0, 100);
    imgViewFrontIDCard.layer.masksToBounds = YES;
    imgViewFrontIDCard.layer.cornerRadius = 7.0;
    
    [self.myScrollView addSubview:imgViewFrontIDCard];
    
    UIImageView* imgViewBackIDCard = [[UIImageView alloc] init];
    imgViewBackIDCard.image = self.imgBackIDCard;
    imgViewBackIDCard.frame = CGRectMake(imgViewFrontIDCard.frame.origin.x+imgViewFrontIDCard.frame.size.width+20, labelTitle.frame.origin.y+labelTitle.frame.size.height+45.0, 160.0, 100);
    [self.myScrollView addSubview:imgViewBackIDCard];
    imgViewBackIDCard.layer.masksToBounds = YES;
    imgViewBackIDCard.layer.cornerRadius = 7.0;
    
    self.totalResultView = [[DSLMCVTotalResultView alloc] initWithFrame:CGRectMake(23, imgViewFrontIDCard.frame.origin.y+imgViewFrontIDCard.frame.size.height+20.0, (self.view.bounds.size.width-2*23), 164)];
    self.totalResultView.myDelegate = self;
    
    [self.myScrollView addSubview:self.totalResultView];
    int levelRisk = 0;
    if(self.mcvResultInfoModel.certRiskScore < 0.4)
    {
        levelRisk = 2;
    }
    else if(self.mcvResultInfoModel.certRiskScore >= 0.4 && self.mcvResultInfoModel.certRiskScore <= 0.7)
    {
        levelRisk = 1;
    }
    else if (self.mcvResultInfoModel.certRiskScore > 0.7)
    {
        levelRisk = 0;
    }
    
    [self.totalResultView setTotalResult:self.mcvResultInfoModel.certRiskScore LevelRisk:levelRisk];
    
    UIView* viewOCRBk = [UIView new];
    viewOCRBk.frame = CGRectMake(23, self.totalResultView.frame.origin.y+self.totalResultView.frame.size.height+10.0, (self.view.bounds.size.width-2*23), 164);
    viewOCRBk.layer.cornerRadius =
    viewOCRBk.layer.cornerRadius = 5.0;
    viewOCRBk.backgroundColor = [UIColor whiteColor];
    [self.myScrollView addSubview:viewOCRBk];
    
    UILabel* labelOCRTip = [UILabel new];
    [labelOCRTip setTextColor:[UIColor dslc_colorWithHexString:@"#000000" alpha:0.3]];
    labelOCRTip.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
    labelOCRTip.textAlignment = NSTextAlignmentLeft;
    labelOCRTip.text = [DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title2"];
    labelOCRTip.frame = CGRectMake(16.0, 8.0, 300, 18.0);
    [viewOCRBk addSubview:labelOCRTip];
    DSLMCVResutlItemView* itemView1 = [DSLMCVResutlItemView new];
    itemView1.frame = CGRectMake(0.0, labelOCRTip.frame.origin.y+labelOCRTip.frame.size.height+20, (self.view.bounds.size.width-28*2), 20);
    [viewOCRBk addSubview:itemView1];
    
    DSLMCVResutlItemView* itemView2 = [DSLMCVResutlItemView new];
    itemView2.frame = CGRectMake(0.0, itemView1.frame.origin.y+itemView1.frame.size.height+20, (self.view.bounds.size.width-28*2), 20);
    [viewOCRBk addSubview:itemView2];
    
    DSLMCVResutlItemView* itemView3 = [DSLMCVResutlItemView new];
    itemView3.frame = CGRectMake(0.0, itemView2.frame.origin.y+itemView2.frame.size.height+20, (self.view.bounds.size.width-28*2), 20);
    [viewOCRBk addSubview:itemView3];
    
    if(self.mcvResultInfoModel.certiType != nil && ![self.mcvResultInfoModel.certiType isEqualToString:@""])
    {
        [itemView1 setResutlItem:@"result_success" ContentLeft:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title3"] ContentRight:self.mcvResultInfoModel.certiType ContentLines:1];
    }
    else
    {
        [itemView1 setResutlItem:@"result_fail" ContentLeft:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title3"] ContentRight:self.mcvResultInfoModel.certiType ContentLines:1];
    }
    
    if(self.mcvResultInfoModel.certExpiryDate != nil && ![self.mcvResultInfoModel.certExpiryDate isEqualToString:@""])
    {
        [itemView2 setResutlItem:@"result_success" ContentLeft:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title4"] ContentRight:self.mcvResultInfoModel.certExpiryDate ContentLines:1];
    }
    else
    {
        [itemView2 setResutlItem:@"result_fail" ContentLeft:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title4"] ContentRight:self.mcvResultInfoModel.certExpiryDate ContentLines:1];
    }
    
    if(self.mcvResultInfoModel.certiNo != nil && ![self.mcvResultInfoModel.certiNo isEqualToString:@""])
    {
        [itemView3 setResutlItem:@"result_success" ContentLeft:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title5"] ContentRight:self.mcvResultInfoModel.certiNo ContentLines:1];
    }
    else
    {
        [itemView3 setResutlItem:@"result_fail" ContentLeft:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title5"] ContentRight:self.mcvResultInfoModel.certiNo ContentLines:1];
    }
    
    [self.myScrollView addSubview:self.btnOk];
    self.btnOk.frame = CGRectMake((self.view.bounds.size.width-320)/2, viewOCRBk.frame.origin.y+viewOCRBk.frame.size.height+20, 320, 70);
    
    UILabel* labelContextID = [UILabel new];
       [labelContextID setTextColor:[UIColor blackColor]];
       labelContextID.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
       labelContextID.textAlignment = NSTextAlignmentCenter;
    labelContextID.text = [NSString stringWithFormat:@"識別ID:%@", self.recID];
    labelContextID.frame = CGRectMake(0.0, self.btnOk.frame.origin.y+self.btnOk.frame.size.height+10, self.myScrollView.bounds.size.width, 14.0);
       [self.myScrollView addSubview:labelContextID];
    
    self.myScrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.btnOk.frame.origin.y+self.btnOk.frame.size.height+20.0+80.0);
}


- (UIButton* )btnOk
{
    if(_btnOk == nil)
    {
        _btnOk = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnOk setTitle:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_result_title6"] forState:UIControlStateNormal];
        [_btnOk addTarget:self action:@selector(clickBtnOk:) forControlEvents:UIControlEventTouchUpInside];
        [_btnOk setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_btnOk setBackgroundImage:[UIImage imageNamed:@"mcv_result_btn_normal"] forState:UIControlStateNormal];
        _btnOk.titleLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _btnOk.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        _btnOk.contentEdgeInsets = UIEdgeInsetsMake(-24, 0, 0, 0);
    }
    return  _btnOk;
}

-(void)clickBtnOk:(id)sender
{
    [[AppDelegate sharedInstance] gotoHKIDCard_MCV];
}

#pragma mark -DSLMCVTotalResultViewDelegate methods
- (void)clickMCVTotalResultViewExplain
{
    [DSLMCVScoreDefineView showScoreDefine:0.4 MediumScore:0.4 HighScore:0.7];
}

@end
