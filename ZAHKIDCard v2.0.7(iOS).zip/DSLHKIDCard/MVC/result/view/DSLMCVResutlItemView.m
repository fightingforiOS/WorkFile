//
//  DSLMCVResutlItemView.m

//
//  Created by chenliqun on 2019/1/22.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "DSLMCVResutlItemView.h"
#import "UIColor+DSLCHexColor.h"

#define showTimeGap 1
@interface DSLMCVResutlItemView()

@property(nonatomic, strong) UIImageView* imgViewHead;  //左图
@property(nonatomic, strong) UILabel* labelContentRight; //内容右
@property(nonatomic, strong) UILabel* labelContentLeft; //内容左
@property(nonatomic, strong) NSString* imgName;
@property(nonatomic, strong) NSString* content;
@property(nonatomic, assign) BOOL bNormalStatus;
@property(nonatomic, assign) BOOL bAllowClick;
@end

@implementation DSLMCVResutlItemView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    return self;
}

- (void)setupView
{
    [self addSubview:self.imgViewHead];
    [self addSubview:self.labelContentLeft];
    [self addSubview:self.labelContentRight];
}

- (UIImageView* )imgViewHead
{
    if(_imgViewHead == nil)
    {
        float viewH = self.bounds.size.height;
        
        _imgViewHead = [[UIImageView alloc] init];
        _imgViewHead.frame = CGRectMake(20.0, (viewH-14)/2, 14, 14);
    }
    
    return _imgViewHead;
}

- (UILabel* )labelContentLeft
{
    if(_labelContentLeft == nil)
    {
        _labelContentLeft = [[UILabel alloc] init];
        _labelContentLeft.textColor = [UIColor dslc_colorWithHexString:@"#000000" alpha:0.3];
        _labelContentLeft.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _labelContentLeft.textAlignment = NSTextAlignmentLeft;
        _labelContentLeft.text = @"证件类型:";
    }
    return  _labelContentLeft;
}

- (UILabel* )labelContentRight
{
    if(_labelContentRight == nil)
    {
        float viewH = self.bounds.size.height;
        float viewW = self.bounds.size.width;
        _labelContentRight = [[UILabel alloc] init];
        _labelContentRight.textColor = [UIColor blackColor];
        _labelContentRight.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _labelContentRight.textAlignment = NSTextAlignmentLeft;
        _labelContentRight.text = @"鐳射花標: 未識別成功";
        _labelContentRight.frame = CGRectMake(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20, (viewH-20)/2, viewW-(_imgViewHead.frame.origin.x+_imgViewHead.frame.size.width+20), 20);
    }
    return  _labelContentRight;
}

- (void)setResutlItem:(NSString* ) imgName ContentLeft:(NSString* )contentLeft ContentRight:(NSString* )contentRight ContentLines:(int)lines
{
    float viewH = self.bounds.size.height;
    
    self.imgViewHead.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@", imgName]];
    self.labelContentRight.text = contentRight;
    self.labelContentLeft.text = contentLeft;
    
    self.labelContentRight.numberOfLines = lines;
    
    self.imgViewHead.frame = CGRectMake(20.0, (viewH-14)/2, 14, 14);
    CGSize sizeLeft = [self computerContentHeight:contentLeft ContentSize:CGSizeMake(120.0, 18.0) FontSize:14];
    self.labelContentLeft.frame = CGRectMake(self.imgViewHead.frame.origin.x+self.imgViewHead.frame.size.width+10, (viewH-18)/2, sizeLeft.width, 18);
    
    CGSize sizeRight = [self computerContentHeight:contentRight ContentSize:CGSizeMake(200.0, 18.0) FontSize:14];
    self.labelContentRight.frame = CGRectMake(self.labelContentLeft.frame.origin.x+self.labelContentLeft.frame.size.width+10, (viewH-18)/2, sizeRight.width, 18);
    
    if(lines == 2)
    {
        float viewH = self.bounds.size.height;
        self.labelContentRight.frame = CGRectMake(self.labelContentLeft.frame.origin.x+self.labelContentLeft.frame.size.width+10, (viewH-18)/2, sizeRight.width, 50);
    }

}

- (CGSize) computerContentHeight:(NSString*) content ContentSize:(CGSize) contentSize FontSize:(float) fontSize
{
    UIFont *font = [UIFont systemFontOfSize:fontSize];
    
    NSDictionary *attrDictionary = [NSDictionary dictionaryWithObject:font
                                                               forKey:NSFontAttributeName];
    
    NSAttributedString* attrContent = [[NSAttributedString alloc] initWithString:content attributes:attrDictionary];
    CGRect attrContentSize = [attrContent boundingRectWithSize:contentSize options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize size = CGSizeMake(ceilf(attrContentSize.size.width), ceilf(attrContentSize.size.height));
    return size;
    
}

@end
