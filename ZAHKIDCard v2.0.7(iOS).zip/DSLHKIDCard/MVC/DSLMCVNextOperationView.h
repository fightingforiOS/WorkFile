//
//  NextOperationView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DSLHKIDCard/DSLHKIDCard.h>
#import "DSLMCVIDCardEnumType.h"

NS_ASSUME_NONNULL_BEGIN

@interface DSLMCVNextOperationView : UIView

- (void)setNextOpStatus:(DSLMCVIDCardOperationStatus)opStatus Text:(NSString* )text;

@end

NS_ASSUME_NONNULL_END
