//
//  ZAFaceManager.h
//  ZAFaceManager
//
//  Created by Joe on 16/1/6.
//  Copyright © 2016年 ZhongAn Insurance. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 活体检测返回值
 */
typedef enum
{
    ZAFaceDetectResultErrorActionBlend = 0,           ///<动作错误
    ZAFaceDetectResultErrorNotVideo,
    ZAFaceDetectResultErrorTimeOut,           ///<超时
    ZAFaceDetectResultErrorFaceLostNotContinusous,
    ZAFaceDetectResultErrorTooManyFaceLost,
    ZAFaceDetectResultErrorFaceNotContunuous,
    ZAFaceDetectResultErrorMask,
    ZAFaceDetectResultErrorAuthorizationFail    //验签失败,需要提醒用户是否联网
    
}ZAFaceDetectErrorResult;

/**
 *  活体完成sucessBlock
 *  *  @param imageData 返回图片的base64字符串
 */
typedef void (^ZAFaceDetectSucessHandler)(NSString *imageData);

/**
 *  活体完成errorBlock
 *
 *  @param errorType 错误类型
 */
typedef void (^ZAFaceDetectErrorHandler)(ZAFaceDetectErrorResult errorType);


@interface ZAFaceManager : NSObject

/**
 *  需要验证的动作个数（小于等于4次) 默认3
 */
@property (nonatomic, assign) NSUInteger times;
/**
 *  每个动作超时时间，单位为秒，默认10秒
 */
@property (nonatomic, assign) float duration;

/**
 * 活体检测识别最大失败次数，默认3次
 */
@property (nonatomic, assign) NSUInteger actionFailCount;

/**
 *  是否动作为随机 默认 YES(随机)
 */
@property (nonatomic, assign) BOOL randomAction;

+ (instancetype)sharedInstance;

/**
 *  启动检测器
 *
 *  @param viewController    开启活体检测的viewController
 *  @param sucessHandle  成功回调
 *  @param errorHandle  失败回调
 */
- (void)startDetectInViewController:(UIViewController *)viewController successHandle:(ZAFaceDetectSucessHandler)sucessHandle errorHandler:(ZAFaceDetectErrorHandler)errorHandle;

/**
 *  获取 Face SDK版本号
 *
 *  @return sdk 版本号
 */
- (NSString *)faceSDKVersion;

@end

@interface NSString (ToImageWithBase64)

/**
 *  base64转图片
 *
 *  @return 返回图片
 */
- (UIImage *)changeToImage;

@end
