//
//  AgreementView.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/11/25.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import "AgreementView.h"
#import <WebKit/WebKit.h>

@interface AgreementView()

@property(nonatomic, strong) WKWebView* webView;

@end
@implementation AgreementView

-(instancetype)initWithFrame:(CGRect)frame
{
    if(self == [super initWithFrame:frame])
    {
        [self initWebView];
    }
    
    return self;
}

- (void)initWebView
{
    self.backgroundColor = [UIColor whiteColor];
    
    WKWebView* webView = [[WKWebView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    webView.scrollView.backgroundColor = [UIColor whiteColor];
    webView.backgroundColor = [UIColor whiteColor];
    NSString *path = [[NSBundle mainBundle] pathForResource:@"TU_Legal_20191125" ofType:@"pdf"]; // 本地
    NSURL *url = [NSURL fileURLWithPath:path];
    NSURLRequest *request=[NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
    self.webView = webView;
    [self addSubview:self.webView];
}
@end
