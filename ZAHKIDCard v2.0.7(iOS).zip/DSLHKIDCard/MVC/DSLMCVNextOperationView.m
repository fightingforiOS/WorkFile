//
//  DSLMCVNextOperationView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import "DSLMCVNextOperationView.h"
#import "DSLPlayAudio.h"
#import "DSLMCVIDCardBundle.h"
#import "DSLHKIDCardConfig.h"
#import "UIColor+DSLCHexColor.h"

@interface DSLMCVNextOperationView()

@property(nonatomic, strong) UIView* viewOpBk;
@property(nonatomic,strong)UILabel *labelNextOperation;

@end

@implementation DSLMCVNextOperationView


- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
    [self addSubview:self.viewOpBk];
    [self addSubview:self.labelNextOperation];

    self.viewOpBk.frame = self.bounds;
    self.labelNextOperation.frame = CGRectMake(0.0, (self.bounds.size.height-26.0)/2, self.frame.size.width, 26.0);
    self.labelNextOperation.textAlignment = NSTextAlignmentCenter;
}

- (UIView* )viewOpBk
{
    if(_viewOpBk == nil)
    {
        _viewOpBk = [[UIView alloc] init];
        [_viewOpBk setBackgroundColor:[UIColor blackColor]];
        _viewOpBk.alpha = 0.48;
        _viewOpBk.layer.borderColor = [UIColor blackColor].CGColor;
        _viewOpBk.layer.cornerRadius = 21.0;
    }
    
    return _viewOpBk;
}

- (UILabel* )labelNextOperation
{
    if (_labelNextOperation == nil) {
        _labelNextOperation = [[UILabel alloc] init];
        _labelNextOperation.textAlignment = NSTextAlignmentCenter;
        _labelNextOperation.textColor = [UIColor whiteColor];
        _labelNextOperation.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
        _labelNextOperation.lineBreakMode = NSLineBreakByWordWrapping;
        _labelNextOperation.numberOfLines = 0;

        
    }
    return _labelNextOperation;
}

- (void)setNextOpStatus:(DSLMCVIDCardOperationStatus)opStatus Text:(NSString* )text
{
    if(opStatus == DSLMCVIDCardOperation_ORTH)
    {
        self.labelNextOperation.textColor = [UIColor dslc_colorWithHexString:@"0x0AFF7A"];
    }
    else
    {
        self.labelNextOperation.textColor = [UIColor whiteColor];
    }
    
    switch (opStatus)
    {
        case DSLMCVIDCardOperation_ORTH:
        {
            //需要播放成功声音
            [self setNextOpText:text];
        }
            break;
       
        case DSLMCVIDCardOperation_COMPLETE:
        {
            [self setNextOpText:[DSLMCVIDCardBundle IDCardBundleString:@"mcv_idcard_operation_title7"]];
        }
            break;
       
        default:
        {
            [self setNextOpText:text];
        }
            break;
    }
    
    
}

- (void) setNextOpText:(NSString* )text
{
    
    if(text == nil || [text isEqualToString:@""] || [text isEqualToString:self.labelNextOperation.text])
    {
        return;
    }
    
    self.labelNextOperation.text = text;
//    if([DSLMCVIDCardBundle isChineseLanguage])
//    {
//        CGSize textSize = CGSizeMake(self.bounds.size.width-20, 22);//[self computerContentHeight:text ContentSize:CGSizeMake(300, 20.0) FontSize:16];
//
//        self.labelNextOperation.frame = CGRectMake(0.0, 0.0, textSize.width, textSize.height);
//    }
//    else
//    {
//        if([text isEqualToString:@"Start detection"])
//        {
//            NSLog(text);
//        }
//
//
//        CGSize textSize = [self computerContentHeight:text ContentSize:CGSizeMake(self.bounds.size.width, 120.0) FontSize:24.0];
//        if(textSize.height > 32)
//        {
//            self.labelNextOperation.frame = CGRectMake((self.bounds.size.width-textSize.width)/2, (40.0-28)/2, textSize.width, textSize.height+30);
//        }
//        else
//        {
//            self.labelNextOperation.frame = CGRectMake((self.bounds.size.width-300)/2, 20, 300, 30);
//        }
//    }
}

- (CGSize) computerContentHeight:(NSString*) content ContentSize:(CGSize) contentSize FontSize:(float) fontSize
{
    UIFont *font = [UIFont systemFontOfSize:fontSize];
    
    NSDictionary *attrDictionary = [NSDictionary dictionaryWithObject:font
                                                               forKey:NSFontAttributeName];
    
    NSAttributedString* attrContent = [[NSAttributedString alloc] initWithString:content attributes:attrDictionary];
    CGRect attrContentSize = [attrContent boundingRectWithSize:contentSize options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize size = CGSizeMake(ceilf(attrContentSize.size.width), ceilf(attrContentSize.size.height));
    return size;
    
}

- (void)delayShowTip:(NSString* )text
{
    [self setNextOpText:text];
}
@end
