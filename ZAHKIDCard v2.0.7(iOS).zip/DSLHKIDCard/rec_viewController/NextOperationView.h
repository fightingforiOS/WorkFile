//
//  NextOperationView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DSLHKIDCard/DSLHKIDCard.h>
#import "DSLHKIDCardEnumType.h"

NS_ASSUME_NONNULL_BEGIN

@interface NextOperationView : UIView

- (void)setNextOpStatus:(DSLHKIDCardOperationStatus)opStatus Text:(NSString* )text IDCardType:(DSLHKIDCardTypeApp)idCardType;

@end

NS_ASSUME_NONNULL_END
