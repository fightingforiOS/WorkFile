//
//  DSLMCVIDCardNewResultController.h
//  DSLHKIDCard
//
//  Created by chenliqun13 on 2020/12/1.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLMCVResultInfoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DSLMCVIDCardNewResultController : UIViewController

@property(nonatomic, strong) UIImage* imgFrontIDCard;   //正面证件照
@property(nonatomic, strong) UIImage* imgBackIDCard;    //背面证件照

@property(nonatomic, strong) DSLMCVResultInfoModel* mcvResultInfoModel;
@property(nonatomic, copy) NSString* recID; //验证ID
@end

NS_ASSUME_NONNULL_END
