//
//  ZASDKAuthorization.h
//  ZASDKHelp
//
//  Created by chenliqun on 2018/4/16.
//  Copyright © 2018年 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^VoidBlock_logInfo)(NSArray* logInfos);

@interface ZASDKAuthorization : NSObject

+ (instancetype _Nullable)sharedInstance;


/**
 众安sdk验权
 @param appKey 在众安网站申请的appkey
 @param secret 在众安网站申请的secret
 @param completion 验证结果 -1:网络错误；0:验权通过；1验权失败; 2token过期; 3当前使用的sdk版本过低 401:appKey或者secret错误；400:grant_type错误
 */
- (void)zaSDKAuthorization: ( NSString* _Nullable ) appKey
                    Secret:( NSString* _Nullable )secret
                    Completion: (void(^ _Nullable)(int result)) completion;


/*
 * 检查是否有SDK使用权限,可以通过上面方法注册获取权限
 */
-(BOOL)hasSDKAuthorization;

/*
  继续验权
  @param completion 验证结果 -1:网络错误；0:验权通过；1验权失败; 2token过期; 3当前使用的sdk版本过低 401:appKey或者secret错误；400:grant_type错误
 */
-(void)continueAuthorization:(void(^ _Nullable)(int result))completion;


/**
 获取OCR运行日志信息
 暂未开放
 @param completion 日志信息
 */
- (void)getLogInfo:(VoidBlock_logInfo)completion;

@end
