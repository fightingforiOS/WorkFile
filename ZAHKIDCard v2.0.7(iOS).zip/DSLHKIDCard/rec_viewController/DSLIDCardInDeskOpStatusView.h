//
//  DSLIDCardInDeskOpStatusView.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/5/11.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <DSLHKIDCard/DSLHKIDCard.h>

NS_ASSUME_NONNULL_BEGIN

@interface DSLIDCardInDeskOpStatusView : UIView

/**
 初始化
 */
- (void)initData;
/**
设置Bar的初始朝向

@param bBarOriginalDirctionLeft 是否是向左
@param bIDCard2018 证件类型
*/
- (void)setBarOriginalDirctionLeft:(BOOL)bBarOriginalDirctionLeft IDCardType2018:(BOOL)bIDCard2018;

/**
设置当前证件操作的状态

@param opStatus 操作状态
*/
- (void)setIDCardOperationStatus:(DSLHKIDCardOperationStatus) opStatus;

/**
实时更新手机旋转角度

@param angle 手机旋转角度
@param rotationDirctionLeft 手机旋转朝向
*/
- (void)updateRotationAngle:(double)angle RotationDirctionLeft:(BOOL) rotationDirctionLeft;

@end

NS_ASSUME_NONNULL_END
