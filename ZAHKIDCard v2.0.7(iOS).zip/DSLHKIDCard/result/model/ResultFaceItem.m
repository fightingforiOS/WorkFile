//
//  ResultFaceItem.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/3/6.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "ResultFaceItem.h"

@interface ResultFaceItem()

@end

@implementation ResultFaceItem

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self initView];
    }
    
    return self;
}

- (void)initView
{
//    self.layer.borderColor = [UIColor redColor].CGColor;
//    self.layer.borderWidth = 1;
    self.backgroundColor = [UIColor clearColor];
    
    [self addSubview:self.labelKey];
    [self addSubview:self.labelVal];
}

- (UILabel* )labelKey
{
    if(_labelKey == nil)
    {
        _labelKey = [[UILabel alloc] init];
        _labelKey.textColor = [UIColor whiteColor];
        _labelKey.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _labelKey.textAlignment = NSTextAlignmentCenter;
        _labelKey.text = @"面部相似度";
        _labelKey.frame = CGRectMake(0.0, 0.0, 100, 20);
    }
    return  _labelKey;
}

- (UILabel* )labelVal
{
    if(_labelVal == nil)
    {
        _labelVal = [[UILabel alloc] init];
        _labelVal.textColor = [UIColor whiteColor];
        _labelVal.font = [UIFont fontWithName:@"PingFangSC-Regular" size:15];
        _labelVal.textAlignment = NSTextAlignmentCenter;
        _labelVal.text = @"95%";
        _labelVal.frame = CGRectMake(0.0, _labelKey.frame.origin.y+_labelKey.frame.size.height+10.0, 100, 20);
    }
    return  _labelVal;
}

@end
