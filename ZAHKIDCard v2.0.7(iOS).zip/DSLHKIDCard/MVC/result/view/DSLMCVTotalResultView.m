//
//  DSLMCVTotalResultView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import "DSLMCVTotalResultView.h"
#import "UIColor+DSLCHexColor.h"
#import "DSLMCVIDCardBundle.h"

@interface DSLMCVTotalResultView()

@property(nonatomic, strong) UIImageView* imgViewHeadBk;
@property(nonatomic, strong) UILabel* labelTip;
@property(nonatomic, strong) UILabel* labelRiskTip;
@property(nonatomic, strong) UILabel* labelRiskScore;
@property(nonatomic, strong) UIView* viewRiskProcess;
@property(nonatomic, strong) UIView* viewRiskProcessBk;
@property(nonatomic, strong) UIButton* btnExplain;

@end

@implementation DSLMCVTotalResultView

- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView];
    }
    
    return self;
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

- (void)setTotalResult:(double )ristScore LevelRisk:(int) levelRisk
{
    NSString* strLevelRisk = @"低风险";
    if(levelRisk == 1)
    {
        strLevelRisk = @"中风险";
    }
    else if(levelRisk == 2)
    {
        strLevelRisk = @"高风险";
    }
    self.labelRiskScore.text = [NSString stringWithFormat:@"%0.2f (%@)", ristScore, strLevelRisk];
    switch (levelRisk)
    {
        case 2:
            self.viewRiskProcess.frame = CGRectMake(self.labelTip.frame.origin.x, self.labelRiskScore.frame.origin.y+self.labelRiskScore.frame.size.height+10.0, (self.bounds.size.width-2*self.labelTip.frame.origin.x)*ristScore, 12);
            break;
        case 1:
            self.viewRiskProcess.frame = CGRectMake(self.labelTip.frame.origin.x, self.labelRiskScore.frame.origin.y+self.labelRiskScore.frame.size.height+10.0, (self.bounds.size.width-2*self.labelTip.frame.origin.x)*ristScore, 12);
            break;
        case 0:
            self.viewRiskProcess.frame = CGRectMake(self.labelTip.frame.origin.x, self.labelRiskScore.frame.origin.y+self.labelRiskScore.frame.size.height+10.0, (self.bounds.size.width-2*self.labelTip.frame.origin.x)*ristScore, 12);
            break;
            
        default:
            break;
    }
}


- (void)setTotalResult:(NSString* )strTotalScore VideoQuality:(NSString* )videoQuality TotalScoreColor:(UIColor* )color IsShowTipText:(BOOL) showTipText LevelRisk:(int) levelRisk
{

}
- (void)setupView
{
    
    [self addSubview:self.imgViewHeadBk];
    [self addSubview:self.labelTip];
    [self addSubview:self.labelRiskTip];
    [self addSubview:self.labelRiskScore];
    [self addSubview:self.viewRiskProcessBk];
    [self addSubview:self.viewRiskProcess];
    [self addSubview:self.btnExplain];
    self.labelTip.frame = CGRectMake(16, 8, self.frame.size.width-20, 18);
    self.imgViewHeadBk.frame =  CGRectMake(0, 0, self.frame.size.width, 38);
    
    self.labelRiskTip.frame =  CGRectMake(self.labelTip.frame.origin.x, self.imgViewHeadBk.frame.origin.y+self.imgViewHeadBk.frame.size.height+20.0, 150, 18);
    self.btnExplain.frame = CGRectMake(self.frame.size.width-25, self.imgViewHeadBk.frame.origin.y+self.imgViewHeadBk.frame.size.height+20.0, 20, 20);
    self.labelRiskScore.frame = CGRectMake(100.0, self.labelRiskTip.frame.origin.y+self.labelRiskTip.frame.size.height+10.0, 120, 18);
    self.viewRiskProcess.frame = CGRectMake(self.labelTip.frame.origin.x, self.labelRiskScore.frame.origin.y+self.labelRiskScore.frame.size.height+10.0, self.bounds.size.width-2*self.labelTip.frame.origin.x, 12);
    self.viewRiskProcessBk.frame = CGRectMake(self.labelTip.frame.origin.x, self.labelRiskScore.frame.origin.y+self.labelRiskScore.frame.size.height+10.0, self.bounds.size.width-2*self.labelTip.frame.origin.x, 12);
    
    UILabel* label1 = [self createLabel:@"高"];
    [self addSubview:label1];
    label1.frame = CGRectMake(self.labelTip.frame.origin.x, self.viewRiskProcess.frame.origin.y+self.viewRiskProcess.frame.size.height+10.0, 20.0, 15);
    
    UILabel* label2 = [self createLabel:@"中"];
    [self addSubview:label2];
    label2.frame = CGRectMake(self.frame.size.width/2-10, self.viewRiskProcess.frame.origin.y+self.viewRiskProcess.frame.size.height+10.0, 20.0, 15);
  
    UILabel* label3 = [self createLabel:@"低"];
    [self addSubview:label3];
    label3.frame = CGRectMake(self.frame.size.width-self.labelTip.frame.origin.x-20, self.viewRiskProcess.frame.origin.y+self.viewRiskProcess.frame.size.height+10.0, 20.0, 15);
   
}

- (UILabel* )createLabel:(NSString* )name
{
    UILabel* label = [[UILabel alloc] init];
    label.text = name;
    label.textColor = [UIColor grayColor];
    label.font = [UIFont fontWithName:@"PingFangSC-Regular" size:11];
    label.textAlignment = NSTextAlignmentLeft;
    return label;
}

- (UIImageView* ) imgViewHeadBk
{
    if(_imgViewHeadBk == nil)
    {
        _imgViewHeadBk = [[UIImageView alloc] init];
        _imgViewHeadBk.image = [UIImage imageNamed:@"mcv_result_show_headbk"];
    }
    return _imgViewHeadBk;
}

- (UIView* )viewRiskProcess
{
    if(_viewRiskProcess == nil)
    {
        _viewRiskProcess = [[UIView alloc] init];
        _viewRiskProcess.layer.cornerRadius = 6.0;
        _viewRiskProcess.backgroundColor = [UIColor dslc_colorWithHexString:@"#7CFFCB"];
        
    }
    return _viewRiskProcess;
}

- (UIView* )viewRiskProcessBk
{
    if(_viewRiskProcessBk == nil)
    {
        _viewRiskProcessBk = [[UIView alloc] init];
        _viewRiskProcessBk.layer.cornerRadius = 6.0;
        _viewRiskProcessBk.backgroundColor = [UIColor dslc_colorWithHexString:@"#EDEDED"];
    }
    return _viewRiskProcessBk;
}

- (UILabel* )labelTip
{
    if(_labelTip == nil)
    {
        _labelTip = [[UILabel alloc] init];
        _labelTip.textColor = [UIColor whiteColor];
        _labelTip.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _labelTip.textAlignment = NSTextAlignmentLeft;
        _labelTip.text = @"结果信息展示";
    }
    return  _labelTip;
}

- (UILabel* )labelRiskTip
{
    if(_labelRiskTip == nil)
    {
        _labelRiskTip = [[UILabel alloc] init];
        _labelRiskTip.textColor = [UIColor grayColor];
        _labelRiskTip.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _labelRiskTip.textAlignment = NSTextAlignmentLeft;
        _labelRiskTip.text = @"风险预测:";
    }
    return  _labelRiskTip;
}


- (UILabel* )labelRiskScore
{
    if(_labelRiskScore == nil)
    {
        _labelRiskScore = [[UILabel alloc] init];
        _labelRiskScore.textColor = [UIColor dslc_colorWithHexString:@"#5AD8A6"];
        _labelRiskScore.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        _labelRiskScore.textAlignment = NSTextAlignmentLeft;
        _labelRiskScore.text = @"0.2(低风险)";
    }
    return  _labelRiskScore;
}

- (UIButton* )btnExplain
{
    if(_btnExplain == nil)
    {
        _btnExplain = [UIButton buttonWithType:UIButtonTypeCustom];
        [_btnExplain setImage:[UIImage imageNamed:@"result_explain"] forState:UIControlStateNormal];
        [_btnExplain addTarget:self action:@selector(clickBtnExplain:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return _btnExplain;
}

- (void)clickBtnExplain:(id)sender
{
    if(self.myDelegate)
    {
        if([self.myDelegate respondsToSelector:@selector(clickMCVTotalResultViewExplain)])
        {
            [self.myDelegate clickMCVTotalResultViewExplain];
        }
    }
}
@end
