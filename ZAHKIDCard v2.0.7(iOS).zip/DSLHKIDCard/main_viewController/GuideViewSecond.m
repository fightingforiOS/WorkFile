//
//  GuideViewSecond.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/11.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "GuideViewSecond.h"

@interface GuideViewSecond()

@property(nonatomic, strong) UIImageView* imgViewPhone;
@property(nonatomic, strong) UIImageView* imgViewHandleIDCard;
@property(nonatomic, strong) UIImageView* imgViewIDCard;
@property(nonatomic, strong) UIImageView* imgViewIDCardBorder;

@end

@implementation GuideViewSecond

- (instancetype)initWithFrame:(CGRect)frame RecType:(DSLHKIDCardTypeApp) recType
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView:recType];
    }
    
    return self;
}

- (void)setupView: (DSLHKIDCardTypeApp) recType
{
    [self addSubview:self.imgViewHandleIDCard];
    [self addSubview:self.imgViewPhone];
    [self addSubview:self.imgViewIDCard];
    [self addSubview:self.imgViewIDCardBorder];
    if(recType == DSLHKIDCardTypeApp_2018)
    {
        self.imgViewPhone.image = [UIImage imageNamed:@"guide2_handlephone_new"];
        self.imgViewHandleIDCard.image = [UIImage imageNamed:@"guide2_handleidcard_new"];
        self.imgViewIDCard.image = [UIImage imageNamed:@"guide2_idcard_new"];
        self.imgViewIDCardBorder.image = [UIImage imageNamed:@"guide2_idcardbord_new"];
    }
    else
    {
        self.imgViewPhone.image = [UIImage imageNamed:@"guide2_handlephone_old"];
        self.imgViewHandleIDCard.image = [UIImage imageNamed:@"guide2_handleidcard_old"];
        self.imgViewIDCard.image = [UIImage imageNamed:@"guide2_idcard_old"];
        self.imgViewIDCardBorder.image = [UIImage imageNamed:@"guide2_idcardbord_old"];
    }
    
    [self initViewLayout];
}

- (void)initViewLayout
{
    //self.imgViewIDCard.hidden = YES;
    //self.imgViewIDCardBorder.hidden = YES;

    self.imgViewIDCard.alpha = 0;
    self.imgViewIDCardBorder.alpha = 0;
    
    self.imgViewPhone.frame = CGRectMake(98, (self.frame.size.height-272-300)/2, 318, 300);
    self.imgViewHandleIDCard.frame = CGRectMake(-200, self.imgViewPhone.frame.origin.y+80, 239, 296);

    self.imgViewIDCard.frame = CGRectMake(159+5, self.imgViewHandleIDCard.frame.origin.y+20, 101, 85);
    self.imgViewIDCardBorder.frame = CGRectMake(153+7, self.imgViewHandleIDCard.frame.origin.y+20-4, 110, 93);
}

- (void)playAnimate
{
    [self initViewLayout];
    
    [UIView animateWithDuration:1 animations:^{
        self.imgViewHandleIDCard.frame = CGRectMake(0.0, self.imgViewPhone.frame.origin.y+80, 239, 296);
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:1.0 animations:^{
            self.imgViewIDCard.alpha = 1.0;
        } completion:^(BOOL finished) {
            self.imgViewIDCardBorder.alpha = 1.0;
        }];
    }];
}

- (UIImageView* )imgViewPhone
{
    if(_imgViewPhone == nil)
    {
        _imgViewPhone = [[UIImageView alloc] init];
    }
    return _imgViewPhone;
}

- (UIImageView* )imgViewHandleIDCard
{
    if(_imgViewHandleIDCard == nil)
    {
        _imgViewHandleIDCard = [[UIImageView alloc] init];
    }
    return _imgViewHandleIDCard;
}

- (UIImageView* )imgViewIDCard
{
    if(_imgViewIDCard == nil)
    {
        _imgViewIDCard = [[UIImageView alloc] init];
    }
    return _imgViewIDCard;
}

- (UIImageView* )imgViewIDCardBorder
{
    if(_imgViewIDCardBorder == nil)
    {
        _imgViewIDCardBorder = [[UIImageView alloc] init];
    }
    return _imgViewIDCardBorder;
}

@end
