
//
//  UIDevice+Utility.m
//  XLMovieKit
//
//  Created by liuhu on 2017/6/23.
//  Copyright © 2017年 xunlei. All rights reserved.
//

#import "UIDevice+Utility.h"
#import <sys/sysctl.h>
#include <sys/param.h>
#include <sys/mount.h>
#import <UIKit/UIKit.h>

@implementation UIDevice(Utility)

- (NSString *)ir_deviceModel {
    int mib[2];
    size_t len;
    char *machine;
    
    mib[0] = 6; //CTL_HW;
    mib[1] = 1; //HW_MACHINE;
    sysctl(mib, 2, NULL, &len, NULL, 0);
    machine = malloc(len);
    sysctl(mib, 2, machine, &len, NULL, 0);
    
    NSString *platform = [NSString stringWithCString:machine encoding:NSASCIIStringEncoding];
    free(machine);
    
    if ([platform isEqualToString:@"iPhone1,1"]) {
        return @"iPhone2G";    //(A1203)
    }
    
    if ([platform isEqualToString:@"iPhone1,2"]) {
        return @"iPhone3G";   //(A1241/A1324)
    }
    
    if ([platform isEqualToString:@"iPhone2,1"]) {
        return @"iPhone3GS";  //(A1303/A1325)
    }
    
    if ([platform isEqualToString:@"iPhone3,1"]) {
        return @"iPhone4";   //(A1332)
    }
    
    if ([platform isEqualToString:@"iPhone3,2"]) {
        return @"iPhone4";  //(A1332)
    }
    
    if ([platform isEqualToString:@"iPhone3,3"]) {
        return @"iPhone4";  //(A1349)
    }
    
    if ([platform isEqualToString:@"iPhone4,1"]) {
        return @"iPhone4S";//(A1387/A1431)
    }
    
    if ([platform isEqualToString:@"iPhone5,1"]) {
        return @"iPhone5"; //(A1428)
    }
    
    if ([platform isEqualToString:@"iPhone5,2"]) {
        return @"iPhone5"; //(A1429/A1442)
    }
    
    if ([platform isEqualToString:@"iPhone5,3"]) {
        return @"iPhone5c";//(A1456/A1532)
    }
    
    if ([platform isEqualToString:@"iPhone5,4"]) {
        return @"iPhone5c";//(A1507/A1516/A1526/A1529)
    }
    
    if ([platform isEqualToString:@"iPhone6,1"]) {
        return @"iPhone5s";//(A1453/A1533)
    }
    
    if ([platform isEqualToString:@"iPhone6,2"]) {
        return @"iPhone5s";//(A1457/A1518/A1528/A1530)
    }
    
    if ([platform isEqualToString:@"iPhone7,1"]) {
        return @"iPhone6 Plus";//(A1522/A1524)
    }
    
    if ([platform isEqualToString:@"iPhone7,2"]) {
        return @"iPhone6";  //(A1549/A1586)
    }
    
    if ([platform isEqualToString:@"iPhone8,1"]) {
        return @"iPhone6s";//(A1522/A1524)
    }
    
    if ([platform isEqualToString:@"iPhone8,2"]) {
        return @"iPhone6s Plus";  //(A1549/A1586)
    }
    
    if ([platform isEqualToString:@"iPhone8,3"]) {
        return @"iPhoneSE";
    }
    
    if ([platform isEqualToString:@"iPhone8,4"]) {
        return @"iPhoneSE";
    }
    
    if ([platform isEqualToString:@"iPhone9,1"]) {
        return @"iPhone7";
    }
    
    if ([platform isEqualToString:@"iPhone9,2"]) {
        return @"iPhone7 Plus";
    }
    
    if ([platform isEqualToString:@"iPhone9,3"]) {
        return @"iPhone7";
    }
    
    if ([platform isEqualToString:@"iPhone9,4"]) {
        return @"iPhone7 Plus";
    }
    
    if ([platform isEqualToString:@"iPhone10,1"]) {
        return @"iPhone 8";
    }
    
    if ([platform isEqualToString:@"iPhone10,4"]) {
        return @"iPhone 8";
    }
    
    if ([platform isEqualToString:@"iPhone10,2"]) {
        return @"iPhone8 Plus";
    }
    
    if ([platform isEqualToString:@"iPhone10,5"]) {
        return @"iPhone8 Plus";
    }
    
    if ([platform isEqualToString:@"iPhone10,3"]) {
        return @"iPhone X";
    }
    
    if ([platform isEqualToString:@"iPhone10,6"]) {
        return @"iPhone X";
    }
  
    if ([platform isEqualToString:@"iPod1,1"]) {
        return @"iPod Touch 1G";   //(A1213)
    }
    
    if ([platform isEqualToString:@"iPod2,1"]) {
        return @"iPod Touch 2G";  //(A1288)
    }
    
    if ([platform isEqualToString:@"iPod3,1"]) {
        return @"iPod Touch 3G";  //(A1318)
    }
    
    if ([platform isEqualToString:@"iPod4,1"]) {
        return @"iPod Touch 4G";  //(A1367)
    }
    
    if ([platform isEqualToString:@"iPod5,1"]) {
        return @"iPod Touch 5G";  //(A1421/A1509)
    }
    
    if ([platform isEqualToString:@"iPod7,1"]) {
        return @"iPod Touch6G";
    }
    
    if ([platform isEqualToString:@"iPad1,1"]) {
        return @"iPad 1G";       //(A1219/A1337)
    }
    
    if ([platform isEqualToString:@"iPad2,1"]) {
        return @"iPad 2";        //(A1395)
    }
    
    if ([platform isEqualToString:@"iPad2,2"]) {
        return @"iPad 2";        //(A1396)
    }
    
    if ([platform isEqualToString:@"iPad2,3"]) {
        return @"iPad 2";       //(A1397)
    }
    
    if ([platform isEqualToString:@"iPad2,4"]) {
        return @"iPad 2";      //(A1395+New Chip)
    }
    
    if ([platform isEqualToString:@"iPad2,5"]) {
        return @"iPad Mini 1G"; //(A1432)
    }
    
    if ([platform isEqualToString:@"iPad2,6"]) {
        return @"iPad Mini 1G"; //(A1454)
    }
    
    if ([platform isEqualToString:@"iPad2,7"]) {
        return @"iPad Mini 1G"; //(A1455)
    }
    
    if ([platform isEqualToString:@"iPad3,1"]) {
        return @"iPad 3";       //(A1416)
    }
    
    if ([platform isEqualToString:@"iPad3,2"]) {
        return @"iPad 3";       //(A1403)
    }
    
    if ([platform isEqualToString:@"iPad3,3"]) {
        return @"iPad 3";       //(A1430)
    }
    
    if ([platform isEqualToString:@"iPad3,4"]) {
        return @"iPad 4";       //(A1458)
    }
    
    if ([platform isEqualToString:@"iPad3,5"]) {
        return @"iPad 4";      //(A1459)
    }
    
    if ([platform isEqualToString:@"iPad3,6"]) {
        return @"iPad 4";      //(A1460)
    }
    
    if ([platform isEqualToString:@"iPad4,1"]) {
        return @"iPad Air";   //(A1474)
    }
    
    if ([platform isEqualToString:@"iPad4,2"]) {
        return @"iPad Air";   //(A1475)
    }
    
    if ([platform isEqualToString:@"iPad4,3"]) {
        return @"iPad Air";   //(A1476)
    }
    
    if ([platform isEqualToString:@"iPad4,4"]) {
        return @"iPad Mini 2G"; //(A1489)
    }
    
    if ([platform isEqualToString:@"iPad4,5"]) {
        return @"iPad Mini 2G"; //(A1490)
    }
    
    if ([platform isEqualToString:@"iPad4,6"]) {
        return @"iPad Mini 2G"; //(A1491)
    }
    
    if ([platform isEqualToString:@"iPad4,7"]) {
        return @"iPad mini3";
    }
    
    if ([platform isEqualToString:@"iPad4,8"]) {
        return @"iPad mini3";
    }
    
    if ([platform isEqualToString:@"iPad4,9"]) {
        return @"iPad mini3";
    }
    
    if ([platform isEqualToString:@"iPad5,1"]) {
        return @"iPad mini4";
    }
    
    if ([platform isEqualToString:@"iPad5,2"]) {
        return @"iPad mini4";
    }
    
    if ([platform isEqualToString:@"iPad5,3"]) {
        return @"iPadAir2";
    }
    
    if ([platform isEqualToString:@"iPad5,4"]) {
        return @"iPadAir2";
    }
    
    if ([platform isEqualToString:@"iPad6,11"]) {
        return @"iPad(9.7)";
    }
    
    if ([platform isEqualToString:@"iPad6,12"]) {
        return @"iPad(9.7)";
    }
    
    if ([platform isEqualToString:@"iPad6,3"]) {
        return @"iPad Pro(9.7)";
    }
    
    if ([platform isEqualToString:@"iPad6,4"]) {
        return @"iPad Pro(9.7)";
    }
    
    if ([platform isEqualToString:@"iPad6,7"]) {
        return @"iPad Pro(12.9)";
    }
    
    if ([platform isEqualToString:@"iPad6,8"]) {
        return @"iPad Pro(12.9)";
    }
    
    if ([platform isEqualToString:@"iPad7,1"]) {
        return @"iPad Pro2(12.9)";
    }
    
    if ([platform isEqualToString:@"iPad7,2"]) {
        return @"iPad Pro2(12.9)";
    }
    
    if ([platform isEqualToString:@"iPad7,3"]) {
        return @"iPad Pro2(10.5)";
    }
    
    if ([platform isEqualToString:@"iPad7,4"]) {
        return @"iPad Pro2(10.5)";
    }
    
    if ([platform isEqualToString:@"i386"]) {
        return @"iPhone Simulator";
    }
    
    if ([platform isEqualToString:@"x86_64"]) {
        return @"iPhone Simulator";
    }
    
    return platform;
}

- (BOOL)highPerformanceDevice{
    
    NSString *deV =  [[UIDevice currentDevice] ir_deviceModel];
    if ([deV isEqualToString:@"iPhone2G"]||
        [deV isEqualToString:@"iPhone3G"]||
        [deV isEqualToString:@"iPhone3GS"]||
        [deV isEqualToString:@"iPhone4"]||
        [deV isEqualToString:@"iPhone4S"]||
        [deV isEqualToString:@"iPhone5"]||
        [deV isEqualToString:@"iPhone5c"]||
        [deV isEqualToString:@"iPod Touch 1G"]||
        [deV isEqualToString:@"iPod Touch 2G"]||
        [deV isEqualToString:@"iPod Touch 3G"]||
        [deV isEqualToString:@"iPod Touch 4G"]||
        [deV isEqualToString:@"iPod Touch 5G"]||
        [deV isEqualToString:@"iPad 1G"]||
        [deV isEqualToString:@"iPad 2"]||
        [deV isEqualToString:@"iPad Mini 1G"]
        ) {
        
        return NO;
    }else{
        
        return YES;
    }
}


@end
