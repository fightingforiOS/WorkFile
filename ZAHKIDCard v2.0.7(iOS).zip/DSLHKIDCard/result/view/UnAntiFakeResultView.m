//
//  UnAntiFakeResultView.m
//  TestHKIDCard
//
//  Created by chenliqun on 2019/1/23.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "UnAntiFakeResultView.h"
#import "UIColor+DSLCHexColor.h"

#import "DSLHKIDCardBundle.h"

@interface UnAntiFakeResultView()

@property(nonatomic, strong) UILabel* labelTitle;
@property(nonatomic, strong) UILabel* labelTitle1;
@property(nonatomic, strong) UILabel* labelTitle2;
@property(nonatomic, strong) UILabel* labelTitle3;

@property(nonatomic, strong) UIView* viewBk;

@property(nonatomic, copy) NSString* strHeightRisk;
@property(nonatomic, copy) NSString* strLowRisk;
@property(nonatomic, assign) int totalRiskCount;

@end

@implementation UnAntiFakeResultView

- (instancetype)initWithFrame:(CGRect)frame HeightRisk:(NSString* )strHeightRisk LowRisk:(NSString* )strLowRisk totalRisks:(int)totalRiskCount
{
    if(self = [super initWithFrame:frame])
    {
        self.strHeightRisk = strHeightRisk;
        self.strLowRisk = strLowRisk;
        self.totalRiskCount = totalRiskCount;
        [self setupView];
    }
    
    return self;
}

- (void)setupView
{
//    self.layer.borderColor = [UIColor blueColor].CGColor;
//    self.layer.borderWidth = 1.0;
    float viewW = self.bounds.size.width;
    
    [self addSubview:self.viewBk];
    self.viewBk.frame = CGRectMake(-8, 12, 184, 10);
    
    [self addSubview:self.labelTitle];
    self.labelTitle.frame = CGRectMake(0, 0, viewW, 26);

//    if(self.totalRiskCount > 0)
//    {
//        [self addSubview:self.labelTitle1];
//        self.labelTitle1.frame =  CGRectMake(0, self.labelTitle.frame.origin.y+self.labelTitle.frame.size.height+16, viewW, 18);
//
//        if(!(self.strHeightRisk == nil || [self.strHeightRisk isEqualToString:@""]))
//        {
//            [self addSubview:self.labelTitle2];
//            self.labelTitle2.frame =  CGRectMake(0, self.labelTitle1.frame.origin.y+self.labelTitle1.frame.size.height+8, viewW, 18);
//        }
//
//        if(!(self.strLowRisk == nil || [self.strLowRisk isEqualToString:@""]))
//        {
//            [self addSubview:self.labelTitle3];
//            if([self.strHeightRisk isEqualToString:@""])
//            {
//                self.labelTitle3.frame =  CGRectMake(0, self.labelTitle1.frame.origin.y+self.labelTitle1.frame.size.height+8, viewW, 18);
//            }
//            else
//            {
//                self.labelTitle3.frame =  CGRectMake(0, self.labelTitle2.frame.origin.y+self.labelTitle2.frame.size.height+8, viewW, 18);
//            }
//        }
//    }
}

-(UIView* )viewBk
{
    if(_viewBk == nil)
    {
        _viewBk = [[UIView alloc] init];
        _viewBk.backgroundColor = [UIColor dslc_colorWithHexString:@"0x02A6CA"];
        _viewBk.alpha = 0.18;
    }
    
    return _viewBk;
}

- (UILabel* )labelTitle
{
    if(_labelTitle == nil)
    {
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textColor = [UIColor blackColor];
        _labelTitle.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:20];
        _labelTitle.textAlignment = NSTextAlignmentLeft;
        _labelTitle.text = [NSString stringWithFormat:@"%@:", [DSLHKIDCardBundle IDCardBundleString:@"result_title51"]];
    }
    return  _labelTitle;
}

- (UILabel* )labelTitle1
{
    if(_labelTitle1 == nil)
    {
        _labelTitle1 = [[UILabel alloc] init];
        _labelTitle1.textColor = [UIColor blackColor];
        _labelTitle1.numberOfLines = 1;
        _labelTitle1.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:13];
        _labelTitle1.textAlignment = NSTextAlignmentLeft;
        _labelTitle1.text = [NSString stringWithFormat:@"未識別成功的共%i項，分别是：", self.totalRiskCount];
    }
    return  _labelTitle1;
}

- (UILabel* )labelTitle2
{
    if(_labelTitle2 == nil)
    {
        _labelTitle2 = [[UILabel alloc] init];
        _labelTitle2.textColor = [UIColor blackColor];
        _labelTitle2.numberOfLines = 1;
        _labelTitle2.font = [UIFont fontWithName:@"PingFangSC-Medium" size:13];
        _labelTitle2.textAlignment = NSTextAlignmentLeft;
        NSString* str = [NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title52"], self.strHeightRisk];
        
        
        NSMutableAttributedString* mAttribute = [[NSMutableAttributedString alloc] initWithString:str];
        [mAttribute addAttribute:NSForegroundColorAttributeName
                           value:[UIColor dslc_colorWithHexString:@"0xDF2E26"]
                           range:NSMakeRange(0, 5)];
        [mAttribute addAttribute:NSForegroundColorAttributeName
                           value:[UIColor blackColor]
                           range:NSMakeRange(5, str.length-5)];
        _labelTitle2.attributedText = mAttribute;
    }
    return  _labelTitle2;
}

- (UILabel* )labelTitle3
{
    if(_labelTitle3 == nil)
    {
        _labelTitle3 = [[UILabel alloc] init];
        _labelTitle3.textColor = [UIColor blackColor];
        _labelTitle3.numberOfLines = 1;
        _labelTitle3.font = [UIFont fontWithName:@"PingFangSC-Medium" size:13];
        _labelTitle3.textAlignment = NSTextAlignmentLeft;
        NSString* str = [NSString stringWithFormat:@"%@: %@", [DSLHKIDCardBundle IDCardBundleString:@"result_title53"], self.strLowRisk];
        
        
        NSMutableAttributedString* mAttribute = [[NSMutableAttributedString alloc] initWithString:str];
        [mAttribute addAttribute:NSForegroundColorAttributeName
                           value:[UIColor dslc_colorWithHexString:@"0xF5A623"]
                           range:NSMakeRange(0, 5)];
        [mAttribute addAttribute:NSForegroundColorAttributeName
                           value:[UIColor blackColor]
                           range:NSMakeRange(5, str.length-5)];
        _labelTitle3.attributedText = mAttribute;
    }
    return  _labelTitle3;
}

@end
