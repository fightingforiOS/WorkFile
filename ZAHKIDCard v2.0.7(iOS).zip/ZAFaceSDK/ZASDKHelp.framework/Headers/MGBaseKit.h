//
//  MGBaseAPI.h
//  MGBaseAPI
//
//  Created by megvii on 15/12/24.
//  Copyright © 2015Year megvii. All rights reserved.
//

#ifndef MGBaseAPI_h
#define MGBaseAPI_h

#import "LicenseManager.h"
#import "MGVideoManager.h"
#import "MGLicenseManager.h"
#import "MGLogManager.h"
#import "MGAutoSessionPreset.h"
#import "MGBaseDefine.h"
#import "MGImage.h"
#import "MGAnimation.h"


#endif
