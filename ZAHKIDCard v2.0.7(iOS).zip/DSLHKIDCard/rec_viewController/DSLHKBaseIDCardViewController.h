//
//  DSLHKBaseIDCardViewController.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/7/15.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

#import "FLAnimatedImageView.h"
#import "FLAnimatedImage.h"
#import "DSLHKIDCardEnumType.h"

#define dispatch_main_safe(block)\
if ([NSThread isMainThread])\
{\
block();\
}\
else\
{\
dispatch_async(dispatch_get_main_queue(), block);\
}

//转动动画时间
#define Play_Time 8

NS_ASSUME_NONNULL_BEGIN

//__attribute__((objc_subclassing_restricted))
@interface DSLHKBaseIDCardViewController : UIViewController


//身份证件类别
@property(nonatomic, assign) DSLHKIDCardTypeApp recType;

//图片处理会话
@property(nonatomic,strong)AVCaptureSession *captureSession;

//摄像头数据输入设备
@property(nonatomic,strong)AVCaptureDevice *inputDevice;

//身份证件需要放置的区域
@property (assign, nonatomic) CGRect idCardToRect;

//摄像拍摄的有效区域
@property (assign, nonatomic) CGRect effectiveRect;

//身份证件需要放置的区域背景框
@property(nonatomic, strong) UIImageView* idCardToRectImgView;

//操作动作提示图标
@property(nonatomic, strong) FLAnimatedImageView* imgViewRecStatus;

//是否已经停止录制视频
@property (nonatomic, assign) BOOL bStopRecording;

//是否开始识别
@property(nonatomic, assign) BOOL bStartRec;

//已经点击退出按钮
@property(nonatomic, assign) BOOL bExited;

//APP是否是从后台恢复
@property(nonatomic, assign) BOOL bAppRelaunched;

//识别静态图片完成
@property(nonatomic, assign) BOOL bRecStaticImgOk;

//视频保存到相册的文件名
@property(nonatomic, strong) NSString* videoSaveAlbumFileName;

//视频开始时间
@property(nonatomic, assign) double dRecStartTimeStamp;

//第一个动作识别结束时间
@property(nonatomic, assign) double dORTHTimeStamp;

//第二个动作识别结束时间(打开闪光灯录制视频时间)
@property(nonatomic, assign) double dRecStartExposureTimeStamp;

//视频结束时间
@property(nonatomic, assign) double dRecEndTimeStamp;

//操作版本类型 0：手持版；1：桌面版
@property(nonatomic, assign) int iOpType;
//是否是只采集视频(不进行DA验证)上传模式
@property(nonatomic, assign) BOOL isVideoDataOnlyCollectionMode;

#pragma Statistics 相关
//一些埋点统计基本信息
@property(nonatomic, strong) NSMutableDictionary* muDicStatisticsBaseInfo;
//识别开始时间
@property(nonatomic, assign) double dRecOpStartTimeStamp;
//失败次数统计
@property(nonatomic, assign) int iFailCount;
//警告提示统计
@property(nonatomic, assign) int iInvalidCount;
@property(nonatomic, assign) int iBlurCount;
@property(nonatomic, assign) int iFarCount;
@property(nonatomic, assign) int iNearCount;
@property(nonatomic, assign) int iOutOfRangeCount;
@property(nonatomic, assign) int iNoParallelToMobilePhoneCount;
@property(nonatomic, assign) int iTiltCount;

//是否开启Lite版本
@property(nonatomic, assign) BOOL useLiteVersion;

@property(nonatomic, assign) BOOL bOCRCheckCodeFail;

//当前证件旋转角度
@property(nonatomic, assign) double curIDCardRotateAngle;

//码率倍数
//@property(nonatomic, assign) int iBitRate;

/**
 重置视频UI
 */
- (void)resetVideoUI;

/**
初始化身份证件需要放置的区域
*/
- (void)initIDCardToRect;

/**
 绘制摄像拍摄的有效区域

 @param needDraw 是否需要更新; YES:需要更新; NO:不需要更新
 */
- (void)updateEffectiveRect:(BOOL)needDraw;

/**
 停止视频录制
 */
- (void)stopMovieRecorder;

/**
 完成视频录制
 */
- (void)finishVideoWriter;

/**
 设置存放视频的路径

 @param newPath 路径地址, 例如:/private/var/mobile/Containers/Data/Application/F2B0CD52-C3CC-4954-9691-298BFED3717F/tmp/videos/video_100926.mp4
 */
- (void)setNewVideoPath:(NSString *)newPath;
    
/**
 视频存放路径

 @return 视频存放路径
 */
- (NSString *)videoPath;

/**
 计算文件大小

 @param path 文件路径
 @return 文件大小
 */
- (CGFloat)fileSize:(NSURL *)path;

/**
 保存视频文件到相册中

 @param fileUrl 文件路径
 */
- (void)saveVideoToAlbum:(NSURL *)fileUrl;

/**
 视频录制结束后执行,由子类来实现
 */
- (void)proccessRecordVideo __attribute__((objc_requires_super));

/**
 设置闪光灯

 @param on YES:开；NO:关闭
 */
- (void)turnTorchOn:(BOOL)on;

/**
 根据返回的提示改变翻转动画
 @param recStatus 0:恢复正常；1:老证件上翻，新证件右翻；2:老证件下翻，新证件左翻；
 */
- (void)setRecStatus:(DSLHKIDCardRecStatus)recStatus;

/**
 翻转动画
 
 @param type 0:上；1：下；2：右；3：左；4：恢复默认
 */
- (void)playOpAnimation:(DSLHKIDCardPlayOpAnimation)type;
/**
 初始化证件旋转动画
 */
- (void)initPlayOpAnimation;
/**
 启动证件旋转动画计时器
 */
- (void)startTimerAnimation;
/**
  停止证件旋转动画计时器
 */
- (void)stopTimerAnimation;

@end

NS_ASSUME_NONNULL_END
