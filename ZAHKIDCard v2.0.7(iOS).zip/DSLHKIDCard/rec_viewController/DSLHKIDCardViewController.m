//
//  DSLHKIDCardViewController.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/4/15.
//  Copyright © 2019年 chentao. All rights reserved.
//

#import "DSLHKIDCardViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <DSLHKIDCard/DSLHKIDCard.h>
#import <ZAFaceSDK/ZAFaceSDK.h>

#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/PHImageManager.h>
#import <Photos/PHPhotoLibrary.h>
#import <Photos/PHAssetChangeRequest.h>
#import <Photos/PHAsset.h>
#import <Photos/PHAssetResource.h>

#import <CoreImage/CoreImage.h>

#import "UIColor+DSLCHexColor.h"
#import "HandIDCardTipView.h"
#import "DSLMovieRecorder.h"
#import "ResultFailView.h"
#import "UIView+Toast.h"
#import "UIDevice+Utility.h"

#import "DSLHKIDCardResultController.h"
#import "DSLHKIDCardResultFailViewController.h"
#import "LoadingRecView.h"

#import "IRNetworkEngine.h"
#import "ResultInfoModel.h"
#import "NextOperationView.h"
#import "DSLHKIDCardConfig.h"
#import "DSLHKIDCardBundle.h"
#import "SelectTypeForSaveLocal.h"
#import "DSLRecStepFinishView.h"
#import "DSLPlayAudio.h"
#import "DSLHKBaseIDCardViewController+Statistics.h"
#import "RecIDCardOkTipView.h"
#import "AppDelegate.h"
#import "GuideViewController.h"

#import "AppDelegate.h"

@interface DSLHKIDCardViewController ()  <DSLHKIDCardDetectObserverDelegate,HandIDCardTipViewDelegate, ResultFailViewDelegate, DSLHKIDCardResultFailVcDelegate, SelectTypeForSaveLocalDelegate, GuideViewControllerDelegate>

@property(nonatomic,strong)UIButton *backButton;
    
@property(nonatomic,strong)NextOperationView *nextOperationView;

//识别过程中，每个阶段识别成功提示
@property(nonatomic,strong)DSLRecStepFinishView *recStepFinishView;

//在识别过程中出现的操作错误提示
@property(nonatomic,strong)UILabel *labelOpErrorTip;

//当前识别到哪一步显示
@property(nonatomic,strong)UIImageView *imgViewCurRecStep;

//视频录制结束等待进入人脸识别
@property(nonatomic, strong) UIImageView* imgViewRecIDCardOkTip;

//在识别过程中遇到的失败提示(比如，超时，旋转速度过快等)
@property(nonatomic, strong) ResultFailView* resultFailView;


@property(nonatomic, copy) NSString* ocrResultId;

//识别Session ID,方便后台定位
@property(nonatomic, copy) NSString* contextId;

@property(nonatomic, strong) HandIDCardTipView* handIDCardTipView;

@property(nonatomic, strong) DSLHKIDCardResult* curIDCardResult;

@property(nonatomic, strong) UIImage* curImgFaceData;

//保存验真结果和OCR结果数据
@property(nonatomic, strong) ResultInfoModel* resultInfoModel;

@property(nonatomic, strong) LoadingRecView* loadingRecView;

//上传人脸识别图片成功
@property(nonatomic, assign) BOOL bUploadFaceRecognitionSuccess;

//上传视频成功
@property(nonatomic, assign) BOOL bUploadVideoDataSuccess;

//三次阻拦转lite模式
@property(nonatomic, assign) int litecount;

//当前流程操作动作提示语
@property(nonatomic, strong) NSString* strCurOpTip;

//图片保存到相册的文件名
@property(nonatomic, strong) NSString* imgSaveAlbumFileName;

@property(nonatomic, strong) NSMutableArray* muArrSaveRequestDatas;

//显示进度到达哪一步了
@property(nonatomic, strong) UIView* viewProgressBar;

//中间竖线提示
@property(nonatomic,strong)UIImageView *imgViewCenterLine;

//旋转方向提示
@property(nonatomic,strong)UIImageView *imgViewRotationDirection;

//识别成功提示
@property(nonatomic,strong)RecIDCardOkTipView *recIDCardOkTipView;

@end

@implementation DSLHKIDCardViewController


/**
 初始化SDK
 */
- (void)initHKIDCardSDK:(BOOL)useLiteVersion
{
    NSLog(@"当前是否启用lite版本：%d", useLiteVersion);
    _litecount = 0;
    //必需, 设置证件类型2018版或者2003版
    [DSLHKIDCardSDK setIDCardType:self.recType == DSLHKIDCardTypeApp_2018 UseLietVersion:useLiteVersion Occlusion_check:YES Exposure_t:0.2 Dark_t:0.9 Stop_t1_03:0.9 Stop_t2_03:0.95 Stop_t1_2018:0.9 Stop_t2_2018:0.95 Lost_cnt:3];
    //必需, 注册回调对象
    [DSLHKIDCardSDK registerObserver:self];
    
    //可选, 设置识别超时时间
    [DSLHKIDCardSDK setOverTimes:Rec_Over_Time];
    //设置appID
    [DSLHKIDCardSDK setAppId:@"zhongan_demo"];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self configBackButton];
    
    //SDK初始化
    [self initHKIDCardSDK:self.useLiteVersion];
    
    [self.view addSubview:self.imgViewCurRecStep];
    [self.view addSubview:self.nextOperationView];
    self.nextOperationView.hidden = YES;
    
    [self.view addSubview:self.loadingRecView];
    
    if(self.isVideoDataOnlyCollectionMode)
    {
        [self.loadingRecView setLoadingTitle:[DSLHKIDCardBundle IDCardBundleString:@"loading_rec_title2"]];
    }
    [self.view addSubview:self.imgViewRecIDCardOkTip];
    
    [self.nextOperationView setNextOpStatus:DSLHKIDCardOperation_Default Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title23"] IDCardType:self.recType];
    
    [self.view addSubview:self.viewProgressBar];
    [self setViewProgressBarStep:0];
    
    [self.view addSubview:self.imgViewRotationDirection];
    
    [self.view addSubview:self.imgViewCenterLine];
    self.imgViewCurRecStep.hidden = YES;
    [self.view addSubview:self.handIDCardTipView];
    [self.handIDCardTipView setShowTime:2.5];
    
    [self.view addSubview:self.recStepFinishView];
    
    [self.view addSubview:self.resultFailView];
    self.resultFailView.hidden = YES;
    [self.view addSubview:self.labelOpErrorTip];
    
    [self.view addSubview:self.recIDCardOkTipView];
    
    [self startRecognize:NO];
    
//    if(SHOW_HAND_IDCARD_TIP_VIEW)
//    {
//        [self.view addSubview:self.handIDCardTipView];
//    }
//    else
//    {
//        //开始启动识别
//        [self startRecognize];
//    }
    
    [self initNotification];
}

- (void)initNotification
{
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
      [notificationCenter addObserver:self
                               selector:@selector(applicationWillEnterForeground:)
                                   name:UIApplicationWillEnterForegroundNotification
                                 object:nil];
    
      [notificationCenter addObserver:self
                               selector:@selector(applicationDidBecomeActive:)
                                   name:UIApplicationDidBecomeActiveNotification
                                 object:nil];
    
      [notificationCenter addObserver:self
                               selector:@selector(applicationDidEnterBackground:)
                                   name:UIApplicationDidEnterBackgroundNotification
                                 object:nil];
}

- (void)applicationDidBecomeActive:(NSNotification *)notification
{
    if(self.bAppRelaunched)
    {
        self.bAppRelaunched = NO;
        //SDK初始化
        [self initHKIDCardSDK:self.useLiteVersion];
        [self startRecognize:YES];
    }
}
- (void)applicationWillEnterForeground:(NSNotification *)notification
{
    NSLog(@"applicationWillEnterForeground....");
    
    self.bAppRelaunched = YES;
}

- (void)applicationDidEnterBackground:(NSNotification *)notification
{
    NSLog(@"applicationDidEnterBackground....");

    self.recStepFinishView.hidden = YES;
    [self hideOpErrorTip];
    //取消所有延时处理任务
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    
    //必需, 注销回调设置的对象
    [DSLHKIDCardSDK unregisterObserver:self];
    [self clearData];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [UIApplication sharedApplication].idleTimerDisabled = YES;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    NSLog(@"%@ viewWillDisappear!",NSStringFromClass([self class]));
    
    [UIApplication sharedApplication].idleTimerDisabled = NO;
    
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter removeObserver:self];
    
    //必需, 注销回调设置的对象
    [DSLHKIDCardSDK unregisterObserver:self];
    
    [self clearData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{
    NSLog(@"%@ dealloc!",NSStringFromClass([self class]));
    
    //必需, 注销回调设置的对象
    [DSLHKIDCardSDK unregisterObserver:self];
    
    self.resultFailView.myDelegate = nil;
    self.handIDCardTipView.myDelegate = nil;
}

#pragma mark -- 退出识别按钮
-(void)configBackButton{
    _backButton = [[UIButton alloc] initWithFrame:CGRectMake(10, 40, 50, 50)];
    
    UIImage* image =  [UIImage imageNamed:@"remind_close"];
    
    [_backButton setImage:image forState:UIControlStateNormal];
    [_backButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.view addSubview:_backButton];
    [_backButton addTarget:self action:@selector(doPopBack:) forControlEvents:UIControlEventTouchUpInside];
}
    
-(void)doPopBack:(id)sender{
    
    [self clearData];
    
    self.bExited = YES;
    
    double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
    [self recordFail:5 DurationTime:d SessionID:[self getUUID]];
    
    [[AppDelegate sharedInstance] gotoHKIDCard_MCV];
    
}

- (void)clearData
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    [NSObject cancelPreviousPerformRequestsWithTarget:self.handIDCardTipView];
    [NSObject cancelPreviousPerformRequestsWithTarget:self.recStepFinishView];
    [NSObject cancelPreviousPerformRequestsWithTarget:self.nextOperationView];
    
    [self stopTimerAnimation];
    
    if ([self.captureSession isRunning])
    {
        [self.captureSession stopRunning];
    }
    //识别停止
    self.bStartRec = NO;
    //停止录制视频
    if(!ALL_Save_Video)
    {
        [self stopMovieRecorder];
    }
    
    //必需, 当页面消失的时候，需要调用destroyOCR把SDK内部的资源销毁
    [DSLHKIDCardSDK destroyOCR];
}

- (void)resetInitUseLiteVersion
{
    [DSLHKIDCardSDK destroyOCR];
    
    [self initHKIDCardSDK:YES];

}

- (void)startRecognize:(BOOL)bStartIDCardSDK
{
    [self resetVideoUI];
    
    if(!ALL_Save_Video)
    {
        [self stopMovieRecorder];
    }
    
    self.dRecOpStartTimeStamp = [[NSDate date] timeIntervalSince1970] * 1000;
    [self initStatisticsData];
    
    [self resetUUID];
    
    self.bStartRec = YES;
    self.bStopRecording = NO;
    
    self.nextOperationView.hidden = NO;
    self.curIDCardResult = nil;
    self.resultInfoModel = nil;
    self.bUploadVideoDataSuccess = NO;
    self.bUploadFaceRecognitionSuccess = NO;
    self.bRecStaticImgOk = NO;
    
    self.imgViewRecStatus.hidden = YES;
    
    self.imgSaveAlbumFileName = @"";
    self.videoSaveAlbumFileName = @"";
    [self.captureSession startRunning];
    if(bStartIDCardSDK)
    {
        self.idCardToRectImgView.hidden = NO;
        self.imgViewCenterLine.hidden = NO;

        [DSLHKIDCardSDK startDetect];
    }
    else
    {
        self.imgViewCenterLine.hidden = YES;
        self.idCardToRectImgView.hidden = YES;
    }
}

-(ResultInfoModel* )resultInfoModel
{
    if(_resultInfoModel == nil)
    {
        _resultInfoModel = [[ResultInfoModel alloc] init];
    }
    
    return _resultInfoModel;
}


#pragma mark -- UI相关

- (RecIDCardOkTipView* )recIDCardOkTipView
{
    if(_recIDCardOkTipView == nil)
       {
           _recIDCardOkTipView = [[RecIDCardOkTipView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-190)/2, 304, 190)];
           _recIDCardOkTipView.hidden = YES;
           _recIDCardOkTipView.layer.cornerRadius = 8;
       }
    return _recIDCardOkTipView;
}

- (UIImageView* )imgViewRotationDirection
{
    if(_imgViewRotationDirection == nil)
    {
        _imgViewRotationDirection = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.frame.size.width-45)/2, self.effectiveRect.origin.y+self.effectiveRect.size.height+10, 45, 26)];
  
        _imgViewRotationDirection.image = [UIImage imageNamed:@"rec_rotation_direction_right"];
        _imgViewRotationDirection.hidden = YES;
    }
    return _imgViewRotationDirection;
}

- (UIImageView* )imgViewCenterLine
{
    if(_imgViewCenterLine == nil)
    {
        if(self.recType == DSLHKIDCardTypeApp_2003)
        {
            _imgViewCenterLine = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-264)/2, (self.view.bounds.size.height-5)/2, 264, 5)];
            _imgViewCenterLine.image = [UIImage imageNamed:@"rec_level_line_tip"];
        }
        else
        {
            _imgViewCenterLine = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-5)/2, (self.view.bounds.size.height-264)/2, 5, 264)];
            _imgViewCenterLine.image = [UIImage imageNamed:@"rec_vertical_line_tip"];
        }
        
    }
    return _imgViewCenterLine;
}


- (UIView*) viewProgressBar
{
    if(_viewProgressBar == nil)
    {
        _viewProgressBar = [[UIView alloc] init];
        _viewProgressBar.backgroundColor = [UIColor whiteColor];
    }
    return _viewProgressBar;
}

- (LoadingRecView* )loadingRecView
{
    if(_loadingRecView == nil)
    {
        _loadingRecView = [[LoadingRecView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-190)/2, 304, 190)];
        _loadingRecView.hidden = YES;
    }
    
    return _loadingRecView;
}

- (HandIDCardTipView* )handIDCardTipView
{
    if(_handIDCardTipView == nil)
    {
        _handIDCardTipView = [[HandIDCardTipView alloc] initWithFrame:CGRectMake((self.view.frame.size.width-251.0)/2, (self.view.frame.size.height-251.0)/2, 251.0, 251.0) IDCardType:(self.recType == DSLHKIDCardTypeApp_2018 ? NO : YES)];
        _handIDCardTipView.myDelegate = self;
        
    }
    return _handIDCardTipView;
}

- (UIImageView* )imgViewRecIDCardOkTip
{
    if(_imgViewRecIDCardOkTip == nil)
    {
        _imgViewRecIDCardOkTip = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-190)/2, 304, 190)];
        NSString* imgName = @"rec_IDCardOkTip";
        if([self isCurrentLanguageEn])
        {
            imgName = @"rec_IDCardOkTip_english";
        }
        _imgViewRecIDCardOkTip.image = [UIImage imageNamed:imgName];
        _imgViewRecIDCardOkTip.hidden = YES;
    }
    return _imgViewRecIDCardOkTip;
}

- (ResultFailView* )resultFailView
{
    if(_resultFailView == nil)
    {
        _resultFailView = [[ResultFailView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-304)/2, (self.view.bounds.size.height-370)/2, 304, 370)];
        _resultFailView.myDelegate = self;
    }
    return _resultFailView;
}

- (UIImageView* )imgViewCurRecStep
{
    if(_imgViewCurRecStep == nil)
    {
        _imgViewCurRecStep = [[UIImageView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-244)/2, self.nextOperationView.frame.origin.y-60.0, 244, 22.0)];
        _imgViewCurRecStep.image = [UIImage imageNamed:@"rec_step1_bk"];
    }
    return _imgViewCurRecStep;
}

- (UIView* )nextOperationView
{
    if(_nextOperationView == nil)
    {
        if([DSLHKIDCardBundle isChineseLanguage])
        {
            _nextOperationView = [[NextOperationView alloc] initWithFrame:CGRectMake(10.0, self.idCardToRect.origin.y-42.0-23, self.view.bounds.size.width-20.0, 42.0)];
        }
        else
        {
            _nextOperationView = [[NextOperationView alloc] initWithFrame:CGRectMake(10.0, self.idCardToRect.origin.y-42.0-23-20, self.view.bounds.size.width-20.0, 42.0*2)];

        }

    }
    return _nextOperationView;
}

- (DSLRecStepFinishView* )recStepFinishView
{
    if(_recStepFinishView == nil)
    {
        _recStepFinishView = [[DSLRecStepFinishView alloc] initWithFrame:CGRectMake((self.view.bounds.size.width-88.0)/2, self.idCardToRect.origin.y+50.0, 88.0, 88.0)];
        _recStepFinishView.hidden = YES;
    }
    
    return _recStepFinishView;
}

- (UILabel* )labelOpErrorTip
{
    if (_labelOpErrorTip == nil) {
        _labelOpErrorTip = [[UILabel alloc] init];
        
        if([DSLHKIDCardBundle isChineseLanguage])
        {
            _labelOpErrorTip.frame = CGRectMake((self.view.bounds.size.width-180.0)/2, self.idCardToRect.origin.y+90.0, 180.0, 42.0);
        }
        else
        {
            _labelOpErrorTip.frame = CGRectMake(30, self.idCardToRect.origin.y+90.0, self.view.bounds.size.width-60, 42.0);
            _labelOpErrorTip.lineBreakMode = NSLineBreakByWordWrapping;
            _labelOpErrorTip.numberOfLines = 0;
        }
    
        _labelOpErrorTip.textAlignment = NSTextAlignmentCenter;
        _labelOpErrorTip.textColor = [UIColor whiteColor];
        _labelOpErrorTip.font = [UIFont fontWithName:@"PingFangSC-Medium" size:16];
        _labelOpErrorTip.text = @"证件超出识别框外";
        _labelOpErrorTip.backgroundColor = [UIColor dslc_colorWithHexString:@"0xF60000"];
        _labelOpErrorTip.alpha = 0.5;
        _labelOpErrorTip.layer.masksToBounds = YES;
        _labelOpErrorTip.layer.cornerRadius = 2.0;
        _labelOpErrorTip.hidden = YES;
    }
    return _labelOpErrorTip;
}


- (CGSize) computerContentHeight:(NSString*) content ContentSize:(CGSize) contentSize FontSize:(float) fontSize
{
    UIFont *font = [UIFont systemFontOfSize:fontSize];
    
    NSDictionary *attrDictionary = [NSDictionary dictionaryWithObject:font
                                                               forKey:NSFontAttributeName];
    
    NSAttributedString* attrContent = [[NSAttributedString alloc] initWithString:content attributes:attrDictionary];
    CGRect attrContentSize = [attrContent boundingRectWithSize:contentSize options:NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize size = CGSizeMake(ceilf(attrContentSize.size.width), ceilf(attrContentSize.size.height));
    return size;
    
}

- (void)setViewProgressBarStep:(int)step
{
    [UIView animateWithDuration:0.3 animations:^{
        self.viewProgressBar.frame = CGRectMake(self.effectiveRect.origin.x, self.effectiveRect.origin.y, self.view.frame.size.width/4*step, 4);
    }];
    
}

- (void)setCurRecStep:(DSLHKIDCardOperationStatus) opStatus
{
    NSString* strImgName = @"rec_step1_bk";
    switch (opStatus) {
        case DSLHKIDCardOperation_BEGIN:
            break;
        case DSLHKIDCardOperation_ORTH:
            strImgName = @"rec_step2_bk";
            break;
        case DSLHKIDCardOperation_RESET:
            strImgName = @"rec_step3_bk";
            break;
        case DSLHKIDCardOperation_LEFTDOWN:
            strImgName = @"rec_step4_bk";
            break;
        case DSLHKIDCardOperation_COMPLETE:
            strImgName = @"rec_step5_bk";
            break;
        default:
            break;
    }
    
    self.imgViewCurRecStep.image = [UIImage imageNamed:strImgName];
}

- (void)setOpErrorTip:(NSString* )errorTip
{
    //如果识别阶段成功标志显示，则不显示操作错误提示
    if([self.recStepFinishView isHidden])
    {
        self.labelOpErrorTip.hidden = NO;
        self.labelOpErrorTip.text = errorTip;
    }
    else
    {
        self.labelOpErrorTip.hidden = YES;
    }
    
    CGSize sz = [self computerContentHeight:errorTip ContentSize:CGSizeMake(self.view.bounds.size.width-20, 100) FontSize:16];
    //self.labelOpErrorTip.frame = CGRectMake((self.view.bounds.size.width-sz.width)/2, self.idCardToRect.origin.y+90.0, sz.width, 42.0);
    
}
- (void)hideOpErrorTip
{
    self.labelOpErrorTip.hidden = YES;
}

- (void)setShowRecStepFinish:(NSString* )stepFinishTip
{
    [[DSLPlayAudio sharedAudioPlayer] playWithFileName:@"op_success" continueNext:NO];
    self.labelOpErrorTip.hidden = YES;
    [self.recStepFinishView setRecStepFinishTip:stepFinishTip];
    self.recStepFinishView.hidden = NO;
}

- (void)updateOpTip:(DSLHKIDCardNextOperation *)command
{
    switch (command.currentStatus) {
        case DSLHKIDCardOperation_BEGIN:
        {
            [self setCurRecStep:command.currentStatus];
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title1"] IDCardType:self.recType];
            break;
        }

        case DSLHKIDCardOperation_ORTH:
        {
            self.labelOpErrorTip.hidden = YES;
            
            //[self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title17"]];
            [self setCurRecStep:command.currentStatus];
            if(self.recType == DSLHKIDCardTypeApp_2018)   //新证件
            {
                [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title17"] IDCardType:self.recType];

            }
            else
            {
                 [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title17"] IDCardType:self.recType];
            }

            break;
        }
        case DSLHKIDCardOperation_RESET:
        {
            self.recStepFinishView.hidden = YES;
            [self setCurRecStep:command.currentStatus];
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title18"] IDCardType:self.recType];

            break;
        }
        case DSLHKIDCardOperation_LEFTDOWN:
        {
            self.labelOpErrorTip.hidden = YES;
            self.recStepFinishView.hidden = YES;
            [self setCurRecStep:command.currentStatus];
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title3"] IDCardType:self.recType];
            }
            else
            {
                 [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title5"] IDCardType:self.recType];
            }
            //[self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title18"] IDCardType:self.recType];
            break;
        }
        case DSLHKIDCardOperation_STOP1:
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title8"]];
            }
            else
            {
                 [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title9"]];
            }
            
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title22"] IDCardType:self.recType];
            
            break;
        }
        case DSLHKIDCardOperation_STOP2:
        {
            [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title12"]];
            //[self setCurRecStep:command.currentStatus];
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title22"] IDCardType:self.recType];
            break;
        }
        case DSLHKIDCardOperation_STOP3:
        {
            [self setShowRecStepFinish:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title7"]];
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title22"] IDCardType:self.recType];
            break;
        }
         case DSLHKIDCardOperation_COMPLETE:
        {
            [self.nextOperationView setNextOpStatus:command.currentStatus Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title7"] IDCardType:self.recType];
            [self setCurRecStep:command.currentStatus];
            [[DSLPlayAudio sharedAudioPlayer] playWithFileName:@"op_success" continueNext:NO];
            self.labelOpErrorTip.hidden = YES;
            break;
        }
        case DSLHKIDCardOperation_FAR:
        {
            self.iFarCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title13"]];
            break;
        }
        case DSLHKIDCardOperation_NEAR:
        {
            self.iNearCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title14"]];
            break;
        }
        case DSLHKIDCardOperation_BLUR:
        {
            self.iBlurCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title15"]];
            break;
        }
        case DSLHKIDCardOperation_OUT_OF_RANGE:
        {
            self.iOutOfRangeCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title19"]];
            break;
        }
        case DSLHKIDCardOperation_NO_PARALLEL_TO_MOBILEPHONE:
        {
            self.iNoParallelToMobilePhoneCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title20"]];
            break;
        }
        case DSLHKIDCardOperation_DIRECTION_TILT:
        {
            self.iTiltCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title21"]];
            break;
        }
            
        case DSLHKIDCardOperation_INVALID:
        {
            self.iInvalidCount++;
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title16"]];
            break;
        }
        case DSLHKIDCardOperation_VALID:
        {
            [self hideOpErrorTip];
            break;
        }
        case DSLHKIDCardOperation_OCCLUSION:
        {
            [self setOpErrorTip:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title26"]];
            break;
        }
        default:
            break;
    }
   
}

- (NSString* )getOpTip:(DSLHKIDCardOperationStatus) currentStatus
{
    NSString* opTip = @"";
    
    switch (currentStatus)
    {
        case DSLHKIDCardOperation_BEGIN:
            opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title1"];
            break;
            
        case DSLHKIDCardOperation_ORTH:
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)   //新证件
            {
                opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title2"];
            }
            else
            {
                opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title4"];
            }
        }
            break;
            
        case DSLHKIDCardOperation_LEFTDOWN:
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)   //新证件
            {
                opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title3"];
            }
            else
            {
                opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title5"];
            }
        }
            break;
            
        case DSLHKIDCardOperation_COMPLETE:
            opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title7"];
            break;
        case DSLHKIDCardOperation_RESET:
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)   //新证件
            {
                opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title8"];
            }
            else
            {
                opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title9"];
            }
        }
            break;
        case DSLHKIDCardOperation_FAR:
            opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title13"];
            break;
        case DSLHKIDCardOperation_NEAR:
            opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title14"];
            break;
        case DSLHKIDCardOperation_BLUR:
            opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title15"];
            break;
        case DSLHKIDCardOperation_VALID:
            opTip = self.strCurOpTip;
            break;
        case DSLHKIDCardOperation_INVALID:
            opTip = [DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title16"];
            break;
        default:
            break;
    }
    return opTip;
}

#pragma mark-- faceSDK
- (void)start
{
    ZAFaceManager *faceSdk = [ZAFaceManager sharedInstance];
    faceSdk.times = 3;
    faceSdk.duration = 10;
    faceSdk.randomAction = YES;
    faceSdk.tipsText = @"开始人脸识别";
    __weak __typeof(self)weakSelf = self;
    
    [faceSdk startDetectInViewController:self successHandle:^(NSString *imageData, NSDictionary *otherImgs) {
            
        __strong __typeof(weakSelf) strongSelf = weakSelf;
        
        NSData *faceData = [[NSData alloc]initWithBase64EncodedString:imageData options:NSDataBase64DecodingIgnoreUnknownCharacters];
        UIImage *img = [[UIImage alloc]initWithData:faceData];
        strongSelf.curImgFaceData = img;
        [strongSelf updateEffectiveRect:NO];
        
        [strongSelf uploadFaceRecognition:strongSelf.curIDCardResult.imageDataArray.lastObject ImgFace:faceData];
        
        }
    errorHandler:^(ZAFaceDetectErrorResult errorType) {
            
        }];
    
//    [faceSdk startDetectInViewController:self successHandle:^(NSString *imageData) {
//
//        __strong __typeof(weakSelf) strongSelf = weakSelf;
//
//        NSData *faceData = [[NSData alloc]initWithBase64EncodedString:imageData options:NSDataBase64DecodingIgnoreUnknownCharacters];
//        UIImage *img = [[UIImage alloc]initWithData:faceData];
//        strongSelf.curImgFaceData = img;
//        [strongSelf updateEffectiveRect:NO];
//
//        [strongSelf uploadFaceRecognition:strongSelf.curIDCardResult.imageDataArray.lastObject ImgFace:faceData];
//
//    } errorHandler:^(ZAFaceDetectErrorResult errorType) {
//        // __strong __typeof(weakSelf)strongSelf = weakSelf;
//        //[strongSelf.view makeToast:@"活检失败" duration:2.0 position:CSToastPositionCenter];
//
//    }];
}

- (void)delaySetRecStatus
{
    if(self.recType == DSLHKIDCardTypeApp_2018)
    {
         [self.nextOperationView setNextOpStatus:DSLHKIDCardOperation_Default Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title2"] IDCardType:self.recType];
        
        self.imgViewRotationDirection.hidden = NO;
        self.imgViewRotationDirection.image = [UIImage imageNamed:@"rec_rotation_direction_right"];
        self.imgViewRotationDirection.frame = CGRectMake((self.view.frame.size.width-45)/2, self.idCardToRect.origin.y+self.idCardToRect.size.height+10, 45, 26);
        
        
    }
    else
    {
        [self.nextOperationView setNextOpStatus:DSLHKIDCardOperation_Default Text:[DSLHKIDCardBundle IDCardBundleString:@"idcard_operation_title4"] IDCardType:self.recType];
        self.imgViewRotationDirection.hidden = NO;
        self.imgViewRotationDirection.image = [UIImage imageNamed:@"rec_rotation_direction_up"];
        self.imgViewRotationDirection.frame = CGRectMake((self.view.frame.size.width-28), self.idCardToRect.origin.y+(self.idCardToRect.size.height-46)/2, 26, 46);
        
    }
    
    self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_bk"];
    [self setRecStatus:DSLHKIDCardRecStatus_UpOrRight];
}
#pragma mark -- Delegate protocols

#pragma mark -- DSLHKIDCardDetectObserverDelegate
-(void)didUpdateOperationCommand:(DSLHKIDCardNextOperation *)command {
    
    if(command.currentStatus == 0)
    {
        
    }
    NSLog(@"operation command = %@, 操作: %@",@(command.currentStatus), command.nextOperationHint);
    dispatch_main_safe(^{
        
        
        [self updateOpTip:command];
        
        if(command.currentStatus == DSLHKIDCardOperation_BEGIN)
        {
            [self setViewProgressBarStep:0];
            [self setRecStatus:DSLHKIDCardRecStatus_Default];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_ORTH)
        {
            [self setViewProgressBarStep:1];
            
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_finish_bk"];
            
            [self stopTimerAnimation];
            [self performSelector:@selector(delaySetRecStatus) withObject:nil afterDelay:1.4];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_ORTH_HALF)
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {

                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_bk"];
            }
            else
            {
                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_old_card_bk"];
            }
        }
        else if(command.currentStatus == DSLHKIDCardOperation_LEFTDOWN)
        {
            [self setViewProgressBarStep:3];
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                self.imgViewRotationDirection.hidden = NO;
                self.imgViewRotationDirection.image = [UIImage imageNamed:@"rec_rotation_direction_left"];
                self.imgViewRotationDirection.frame = CGRectMake((self.view.frame.size.width-45)/2, self.idCardToRect.origin.y+self.idCardToRect.size.height+10, 45, 26);
                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_bk"];
            }
            else
            {
                self.imgViewRotationDirection.hidden = NO;
                self.imgViewRotationDirection.image = [UIImage imageNamed:@"rec_rotation_direction_down"];
                self.imgViewRotationDirection.frame = CGRectMake((self.view.frame.size.width-28), self.idCardToRect.origin.y+(self.idCardToRect.size.height-46)/2, 26, 46);
                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_old_card_bk"];
            }
            
            [self setRecStatus:DSLHKIDCardRecStatus_DownOrLeft];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_LEFTDOWN_HALF)
        {
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_bk"];
            }
            else
            {
                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_old_card_bk"];
            }
        }
        else if(command.currentStatus == DSLHKIDCardOperation_RESET)
        {
            [self setViewProgressBarStep:2];
            //提示用户把证件复位，设置拍摄有效区域证件背景框为未识别状态
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                self.imgViewRotationDirection.hidden = NO;
                self.imgViewRotationDirection.image = [UIImage imageNamed:@"rec_rotation_direction_left"];
                self.imgViewRotationDirection.frame = CGRectMake((self.view.frame.size.width-45)/2, self.idCardToRect.origin.y+self.idCardToRect.size.height+10, 45, 26);
                
                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_bk"];
            }
            else
            {
                self.imgViewRotationDirection.hidden = NO;
                self.imgViewRotationDirection.image = [UIImage imageNamed:@"rec_rotation_direction_down"];
                self.imgViewRotationDirection.frame = CGRectMake((self.view.frame.size.width-28), self.idCardToRect.origin.y+(self.idCardToRect.size.height-46)/2, 26, 46);
                self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_old_card_bk"];
            }
            
            //在收到reset状态时打开闪光灯
            if(self.dRecStartExposureTimeStamp < 0.01)
            {
                self.dRecStartExposureTimeStamp = [[NSDate date] timeIntervalSince1970] * 1000;
            }
            
            [self setRecStatus:DSLHKIDCardRecStatus_Reset];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_STOP1)
        {
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_finish_bk"];
            [self stopTimerAnimation];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_STOP2)
        {
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_finish_bk"];
            [self stopTimerAnimation];
            
        }
        else if(command.currentStatus == DSLHKIDCardOperation_STOP3)
        {
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_finish_bk"];
            [self stopTimerAnimation];
        }
        else if(command.currentStatus == DSLHKIDCardOperation_COMPLETE)
        {
            self.idCardToRectImgView.image = [UIImage imageNamed:@"rec_new_card_finish_bk"];
            [self setViewProgressBarStep:4];
             [self setRecStatus:DSLHKIDCardRecStatus_Default];
        }
    });
}

-(void)didDetectResult:(DSLHKIDCardResult *)result
{
    
    NSLog(@"didDetectResult retCode=%li", (long)result.idCardResultStatus);
    
    
    dispatch_main_safe((^{
        
        if(result.idCardResultStatus == DSLHKIDCardResultStatus_FirstActionOver)
        {
            self.bRecStaticImgOk = YES;
            
            self.recType = result.idCardType == DSLHKIDCardType_2003 ? DSLHKIDCardTypeApp_2003 : DSLHKIDCardTypeApp_2018;
            
            //已经识别到证件正面，设置拍摄有效区域证件背景框为识别状态
            //获取第一个动作的静态图片
            //可以在这向服务器请求静态图片信息
//            if(!Is_Local_Save)
//            {
//                if(self.isVideoDataOnlyCollectionMode)
//                {
//                    [self uploadStaticImgOnlyCollection:[result.imageDataArray firstObject]];
//                }
//                else
//                {
//                    [self uploadStaticImg:[result.imageDataArray firstObject]];
//                }
//            }
        }
        else
        {
            //重新初始化证件旋转动画
            [self initPlayOpAnimation];
            //隐藏错误提示框
            [self hideOpErrorTip];
            self.bStopRecording = YES;
            self.imgViewRotationDirection.hidden = YES;
            
            if(!ALL_Save_Video)
            {
                if ([self.captureSession isRunning])
                {
                    [self.captureSession stopRunning];
                }
            }
            
            if(self.recType == DSLHKIDCardTypeApp_2018)
            {
                [self turnTorchOn:NO];
            }
            
            if (result.idCardResultStatus != DSLHKIDCardResultStatus_Success)
            {
                [self setViewProgressBarStep:0];
                //识别失败
                self.recStepFinishView.hidden = YES;
                //取消所有延时处理任务
                [NSObject cancelPreviousPerformRequestsWithTarget:self];
                [self proccessRecFail:result];
                self.curIDCardResult = nil;
                
                //识别失败次数统计
                self.iFailCount++;
                int ifailReason = -1;
                switch (result.idCardResultStatus)
                {
                    case DSLHKIDCardResultStatus_Exposure:
                        ifailReason = 0;
                        break;
                    case DSLHKIDCardResultStatus_Lost:
                        ifailReason = 1;
                        break;
                    case DSLHKIDCardResultStatus_Overtime:
                        ifailReason = 2;
                        break;
                    case DSLHKIDCardResultStatus_Dark:
                        ifailReason = 4;
                        break;
                    default:
                        break;
                }
                double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
                [self recordFail:ifailReason DurationTime:d SessionID:[self getUUID]];
                
#warning 以下代码支持在识别失败一次的情况后，直接调起Lite版本来简化操作流程，方便快速录制视频供后台人工识别
                NSLog(@"失败次数： %d", self.iFailCount);
                if(!self.useLiteVersion && self.iFailCount >=3)
                {
                    [self.view makeToast:@"进入lite模式" duration:3.0 position:CSToastPositionCenter];
                    self.useLiteVersion = YES;
                    [self resetInitUseLiteVersion];
                }
            }
            else
            {
                //识别成功关闭视频流
                if(ALL_Save_Video)
                {
                    if ([self.captureSession isRunning])
                    {
                        [self.captureSession stopRunning];
                    }
                }
                
                self.dRecEndTimeStamp = [[NSDate date] timeIntervalSince1970] * 1000;
                self.curIDCardResult = result;
                
                //识别成功才关闭视频录制
                if(ALL_Save_Video)
                {
                    [self finishVideoWriter];
                }
            }

            if(!ALL_Save_Video)
            {
               [self finishVideoWriter];
            }
            
            if(result.idCardResultStatus == DSLHKIDCardResultStatus_Success)
            {
                //save图片
                if(Is_Save_Video_Picture)
                {
                    for(int i = 0; i < (int)[result.imageDataArray count]; ++i)
                    {
                        UIImage *image = [UIImage imageWithData:[result.imageDataArray objectAtIndex:i]];
                        UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
                    }
                }
                else if(Is_Local_Save)
                {
                     UIImage *image = [UIImage imageWithData:[result.imageDataArray firstObject]];
                    __block ALAssetsLibrary *lib = [[ALAssetsLibrary alloc] init];
                    [lib writeImageToSavedPhotosAlbum:image.CGImage metadata:nil completionBlock:^(NSURL *assetURL,NSError *error) {
                        
                        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *imageAsset)
                        {
                            ALAssetRepresentation *imageRep = [imageAsset defaultRepresentation];
                            self.imgSaveAlbumFileName = [imageRep filename];
                           if(![self.imgSaveAlbumFileName isEqualToString:@""] && ![self.videoSaveAlbumFileName isEqualToString:@""])
                            {
                                //[self saveRequestData];
                                [self selectIDCardTypeForSaveLocal];
                            }
                            NSLog(@"[imageRep filename ] : %@", [imageRep filename]);
                            
                        };
                        
                        ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
                        [assetslibrary assetForURL:assetURL resultBlock:resultblock failureBlock:nil];
                        
                        NSLog(@"save image assetURL = %@, error = %@", assetURL, error);
                        lib = nil;
                        
                    }];
                }
            }
        }

    }));
}

- (void)proccessRecFail:(DSLHKIDCardResult *)result
{
    switch (result.idCardResultStatus)
    {
        case DSLHKIDCardResultStatus_Exposure:
        {
            //exposure:表示当前返回反光过强，重新开始识别;
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_Slices];
        }
            break;
        case DSLHKIDCardResultStatus_Lost:
        {
            //lost:目标(证件)丢失,在识别证件过程中，发现某些证件特征持续捕获不到导致识别失败
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_LostObject];
        }
            break;
        case DSLHKIDCardResultStatus_Overtime:
        {
            //overtime:识别超时,超时时间可以设置
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_OverTime];
        }
            break;
        case DSLHKIDCardResultStatus_Dark:
        {
            //dark:光线过暗，重新开始识别
            
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_Dark];
        }
            break;
        case DSLHKIDCardResultStatus_Invalid:
        {
            //invalid:不正确的操作动作，重新开始识别，重新开始识别
            self.bStartRec = NO;
            [self showRecFailResult:DSLHKIDCardRecFailType_Invalid];
        }
        break;
        default:
            //异常的情况
            [self showRecFailResult:DSLHKIDCardRecFailType_Default];
            break;
    }
}

- (void)selectIDCardTypeForSaveLocal
{
    SelectTypeForSaveLocal* selectTypeForSaveLocal = [[SelectTypeForSaveLocal alloc] initWithFrame:CGRectMake(20.0, (self.view.bounds.size.height-500)/2, self.view.bounds.size.width-20*2, 500)];
    selectTypeForSaveLocal.myDelegate = self;
    [self.view addSubview:selectTypeForSaveLocal];
    
}

- (void)selectTypeForSaveLocalOk:(NSString* )env IDCardType:(NSString* )idCardType
{
    [self stopMovieRecorder];
    
    [self saveRequestData:env IDCardType:idCardType];
}

- (void)saveRequestData:(NSString* )env IDCardType:(NSString* )idCardType
{
    NSString* videoTimeStamp = [NSString stringWithFormat:@"%f|%f|%f|%f", self.dRecStartTimeStamp, self.dORTHTimeStamp, self.dRecStartExposureTimeStamp, self.dRecEndTimeStamp];
    
    NSDate *date = [NSDate date];
    NSTimeInterval timeIn = [date timeIntervalSince1970];
    
    NSString *videoPath = [self videoPath];
    NSURL *urlLocl = [NSURL fileURLWithPath:videoPath];
    NSData *videoData = [NSData dataWithContentsOfURL:urlLocl];

    NSDictionary *params = @{@"contextId": [self getUUID],
                             @"timestamp": [NSString stringWithFormat:@"%.0f", timeIn],
                             @"fileSize":[NSString stringWithFormat:@"%lu", (unsigned long)videoData.length],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",  //新老版本标志
                             @"return_illustraon": @"1",
                             @"imgSaveAlbumFileName" : self.imgSaveAlbumFileName,
                             @"videoSaveAlbumFileName" : self.videoSaveAlbumFileName,
                             @"videoTimeStamp":videoTimeStamp,
                             @"env":env,
                             @"idCardType":idCardType
                             };
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:params options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString;
    if (jsonData)
    {
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSLog(@"\n%@\n", jsonString);
        NSString* path = [self pathForSaveRequestData];
        
        NSMutableArray* muArrTmp = [self getSaveRequestData];
        if(muArrTmp == nil)
        {
            muArrTmp = [NSMutableArray arrayWithCapacity:5];
        }
        [muArrTmp addObject:jsonString];
        
        [NSKeyedArchiver archiveRootObject:muArrTmp toFile:path];
        
        [self showFinishedSaveAlert:@"保存成功!"];
    }
    
    self.videoSaveAlbumFileName = @"";
    self.imgSaveAlbumFileName = @"";
}

- (void)showFinishedSaveAlert:(NSString* )msg
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:msg preferredStyle:UIAlertControllerStyleAlert];
    
    //增加确定按钮；
    [alertController addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self startRecognize:YES];
        
    }]];
    
    [self presentViewController:alertController animated:true completion:nil];
}
    
- (void)removeSaveRequestData
{
    NSMutableArray* muArr = [NSMutableArray arrayWithCapacity:5];
    NSString* path = [self pathForSaveRequestData];
    [NSKeyedArchiver archiveRootObject:muArr toFile:path];
}
- (NSMutableArray* )getSaveRequestData
{
    NSString* path = [self pathForSaveRequestData];
    
    if(path == nil || [path isEqualToString:@""])
    {
        return [NSMutableArray arrayWithCapacity:5];
    }
    
    return [NSKeyedUnarchiver unarchiveObjectWithFile:path];
}
    
- (NSString* ) pathForSaveRequestData
{
    NSString* path = nil;
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    if ([paths count] > 0)
    {
        path = [paths objectAtIndex:0];
    }
    path = [path stringByAppendingString:@"/saveRequestData.za"];
    
    return path;
}

    - (NSString* ) pathForSaveRequestDataTxt
    {
        NSString* path = nil;
        
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        if ([paths count] > 0)
        {
            path = [paths objectAtIndex:0];
        }
        path = [path stringByAppendingString:@"/zaData.txt"];
        
        return path;
    }

- (void)proccessRecordVideo
{
    [super proccessRecordVideo];
    
    //如果curIDCardResult为nil,则说明是识别失败的，需要删除当前录制的视频
    if(self.curIDCardResult)
    {
          self.imgViewRecStatus.hidden = YES;
        if(Is_Local_Save)
        {
            [self saveVideoToAlbumForLocalVersion:[NSURL fileURLWithPath:[self videoPath]]];
        }
        else
        {
            if(ALL_Save_Video)
            {
                [self saveVideoToAlbum:[NSURL fileURLWithPath:[self videoPath]]];
                return;
            }
            
            if(Is_Save_Video_Picture)
            {
                [self saveVideoToAlbum:[NSURL fileURLWithPath:[self videoPath]]];
            }
            
            if(self.isVideoDataOnlyCollectionMode)
            {
                [self uploadVideoDataOnlyCollection];
            }
            else
            {
                [self hideRecIDCardOkTip:@"NO"];
                [self performSelector:@selector(hideRecIDCardOkTip:) withObject:@"YES" afterDelay:2];
                [self uploadVideoData];
            }
        }
      
    }
    else
    {
        if(ALL_Save_Video)
        {
            //该模式下，识别失败也不删除视频，在识别成功后删除
            return;
        }
        
        BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:[self videoPath]];
        if(blHave)
        {
            BOOL b = [[NSFileManager defaultManager] removeItemAtPath:[self videoPath] error:nil];
            NSLog(@"movieRecorderDidFinishRecording 删除视频: %@", [NSString stringWithFormat:@"%i", b]);
        }
    }

}

- (void)saveVideoToAlbumForLocalVersion:(NSURL *)fileUrl {
    
    if(!Is_Save_Video_Picture && !Is_Local_Save)
    {
        return;
    }

    NSLog(@"saveVideoToAlbumForLocalVersion 当前视频文件大小 %f MB", [self fileSize:fileUrl]);
    __block ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    
    [library writeVideoAtPathToSavedPhotosAlbum:fileUrl
                                completionBlock:^(NSURL *assetURL, NSError *error) {
                                    if (error)
                                    {
                                        NSLog(@"Save video fail:%@",error);
                                    }
                                    else
                                    {
                                        NSLog(@"Save video succeed.");
                                        
                                        ALAssetsLibraryAssetForURLResultBlock resultblock = ^(ALAsset *imageAsset)
                                        {
                                            ALAssetRepresentation *imageRep = [imageAsset defaultRepresentation];
                                            self.videoSaveAlbumFileName = [imageRep filename];
                                            if(![self.imgSaveAlbumFileName isEqualToString:@""] && ![self.videoSaveAlbumFileName isEqualToString:@""])
                                            {
                                                //[self saveRequestData];
                                                [self selectIDCardTypeForSaveLocal];
                                            }
                                         
                                            NSLog(@"文件视频地址 : %@", [imageRep filename]);
                                        };
                                        
                                        ALAssetsLibrary* assetslibrary = [[ALAssetsLibrary alloc] init];
                                        [assetslibrary assetForURL:assetURL resultBlock:resultblock failureBlock:nil];
                                        NSLog(@"save video assetURL = %@, error = %@", assetURL, error);
                                        library = nil;
                                    }
                                }];
}

- (void)showRecFailResult:(DSLHKIDCardRecFailType)failType
{
    [self.resultFailView showResultFailView:failType];
    }

- (void)hideRecIDCardOkTip:(NSString* ) strHidden
{
 
    self.recStepFinishView.hidden = YES;
    BOOL hidden = [strHidden boolValue];
    self.recIDCardOkTipView.hidden = hidden;
    if(hidden)
    {
        if(Is_Local_Save)
        {
            if(self.isVideoDataOnlyCollectionMode)
            {
                [self uploadVideoDataOnlyCollection];
            }
            else
            {
                [self uploadVideoData];
            }

        }
        else
        {
            //进入人脸识别
            [self start];
        }

    }
}

- (void)clickFailOK
{
#warning 当用户点击退出按钮后，由于一些网络请求的原因，该viewcontroller并不会立即dealloc,加了个判断
    if(!self.bExited && [UIApplication sharedApplication].applicationState == UIApplicationStateActive)
    {
        [self startRecognize:YES];
    }
}

- (void)clickGuide
{
    GuideViewController* vc = [[GuideViewController alloc] init];
    vc.recType = self.recType;
    vc.myDelegate = self;
   vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:^{
        
    }];
}

- (void)clickCloseGuide
{
    [self initHKIDCardSDK:self.useLiteVersion];
    
    [self startRecognize:YES];
}
- (void)clickHandIDCardTipViewOK
{
    self.handIDCardTipView.hidden = YES;
    [self startRecognize:YES];
}

#pragma mark -- help methods
- (NSString* )getUUID
{
    if(self.contextId == nil || [self.contextId isEqualToString:@""])
    {
        self.contextId = [[NSUUID UUID] UUIDString];
        
        
    }
    
    return self.contextId;
}

- (void)resetUUID
{
    
    self.contextId = @"";
    self.dRecStartTimeStamp = 0;
    self.dRecEndTimeStamp = 0;
    self.dRecStartExposureTimeStamp = 0;
    self.dORTHTimeStamp = 0;
}


#pragma mark -- 上传相关

/**
 静态图片上传接口

 @param img 静态图片
 */
- (void)uploadStaticImg:(NSData* )img
{

    if(img == nil)
    {
        [self.view makeToast:@"静态图片空" duration:30.0 position:CSToastPositionCenter];
        return;
    }
    
    //UIImage *image = [UIImage imageWithData:img];
    //UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
    
    NSArray* arrImg = [NSArray arrayWithObjects:img, nil];
    
    __weak typeof(self) weakSelf = self;
    
    NSString* url = @"/kyc/api/drei/ocr";
   
    NSMutableDictionary* dicCustom = [DSLHKIDCardSDK signatureWithImg:img];
    NSString* signature = [dicCustom objectForKey:@"signature"];
    NSString* custom = [dicCustom objectForKey:@"custom"];
    
    NSDictionary* params = @{@"contextId": [self getUUID],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",//新老版本标志
                             @"rectifyTemplate": [DSLHKIDCardSDK getVersion],
                             @"signature":signature,
                             @"custom":custom
                             };
    [IRNetworkEngine uploadTaskIRService:url files:arrImg filename:@"files" header:nil parameters:params custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog(@"uploadStaticImg end...");
            if (error) {
                NSLog(@"静态图上传失败: %@", [error localizedDescription]);
                [weakSelf.view makeToast:@"静态图上传失败" duration:30.0 position:CSToastPositionCenter];
                
            } else {
                NSLog(@"静态图上传结果: %@", [NSString stringWithFormat:@"%@", result]);
                
                NSDictionary* dicOCRResult = result[@"result"];
                if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]] &&  [result[@"resultCode"] intValue] == 0)
                {
                    weakSelf.bOCRCheckCodeFail = NO;
                    weakSelf.resultInfoModel.gender = dicOCRResult[@"sex"];
                    if([weakSelf isCurrentLanguageEn])
                    {
                        weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_en"];
                        weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_en"];
                    }
                    else
                    {
                        weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_cn"];
                        weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_cn"];
                    }
                    weakSelf.resultInfoModel.certiNo = dicOCRResult[@"card_number"];
                    weakSelf.resultInfoModel.birthday = dicOCRResult[@"date_birth"];

                    NSLog(@"OCR info: gender:%@, certiType:%@, certiNo:%@, birthday:%@, firstName:%@", weakSelf.resultInfoModel.gender, weakSelf.resultInfoModel.certiType, weakSelf.resultInfoModel.certiNo, weakSelf.resultInfoModel.birthday, weakSelf.resultInfoModel.firstName);
                    
                    if(weakSelf.bUploadVideoDataSuccess && weakSelf.bUploadFaceRecognitionSuccess)
                    {
                        [weakSelf gotoResultVc:weakSelf.resultInfoModel];
                    }
                    
                }
                else if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]] &&  [result[@"resultCode"] intValue] == 100)
                {
                    //OCR校验码错误
                    weakSelf.bOCRCheckCodeFail = YES;
                    weakSelf.resultInfoModel.gender = dicOCRResult[@"sex"];
                    if([weakSelf isCurrentLanguageEn])
                    {
                        weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_en"];
                        weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_en"];
                    }
                    else
                    {
                        weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_cn"];
                        weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_cn"];
                    }
                    weakSelf.resultInfoModel.certiNo = dicOCRResult[@"card_number"];
                    weakSelf.resultInfoModel.birthday = dicOCRResult[@"date_birth"];

                    NSLog(@"OCR info: gender:%@, certiType:%@, certiNo:%@, birthday:%@, firstName:%@, checkcode:-100", weakSelf.resultInfoModel.gender, weakSelf.resultInfoModel.certiType, weakSelf.resultInfoModel.certiNo, weakSelf.resultInfoModel.birthday, weakSelf.resultInfoModel.firstName);
                    
                    if(weakSelf.bUploadVideoDataSuccess && weakSelf.bUploadFaceRecognitionSuccess)
                    {
                        [weakSelf gotoResultVc:weakSelf.resultInfoModel];
                    }
                }
                else
                {
                    if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]])
                    {
                        [weakSelf.view makeToast:[NSString stringWithFormat:@"静态图上传错误resultCode=%i", [result[@"resultCode"] intValue]] duration:30.0 position:CSToastPositionCenter];
                    }
                }
                
            }
        });
    }];
    
}

/**
  用于采集视频，仅仅上传视频，不进行DA等识别

 @param img 静态图片
 */
- (void)uploadStaticImgOnlyCollection:(NSData* )img
{

    if(img == nil)
    {
        [self.view makeToast:@"静态图片空" duration:30.0 position:CSToastPositionCenter];
        return;
    }
    
    //UIImage *image = [UIImage imageWithData:img];
    //UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
    
    NSArray* arrImg = [NSArray arrayWithObjects:img, nil];
    
    __weak typeof(self) weakSelf = self;
    
    NSString* url = @"/kyc/api/drei/ocr";
   
    NSMutableDictionary* dicCustom = [DSLHKIDCardSDK signatureWithImg:img];
    NSString* signature = [dicCustom objectForKey:@"signature"];
    NSString* custom = [dicCustom objectForKey:@"custom"];
    
    NSDictionary* params = @{@"contextId": [self getUUID],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",//新老版本标志
                             @"rectifyTemplate": [DSLHKIDCardSDK getVersion],
                             @"signature":signature,
                             @"custom":custom
                             };
    [IRNetworkEngine uploadTaskIRService:url files:arrImg filename:@"files" header:nil parameters:params custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            NSLog(@"uploadStaticImg end...");
            if (error) {
                NSLog(@"静态图上传失败: %@", [error localizedDescription]);
                [weakSelf.view makeToast:@"静态图上传失败" duration:30.0 position:CSToastPositionCenter];
                
            } else {
                NSLog(@"静态图上传结果: %@", [NSString stringWithFormat:@"%@", result]);
                
                NSDictionary* dicOCRResult = result[@"result"];
                if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]] &&  [result[@"resultCode"] intValue] == 0)
                {
                    if(weakSelf.bUploadVideoDataSuccess)
                    {
                        [weakSelf.loadingRecView setHidden:YES];
                        [weakSelf showFinishedSaveAlert:@"上传成功!"];
                    }
                    
                }
                else
                {
                    if(weakSelf.bUploadFaceRecognitionSuccess)
                    {
                        [weakSelf.loadingRecView setHidden:YES];
                        if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]])
                        {
                            [weakSelf.view makeToast:[NSString stringWithFormat:@"静态图上传错误resultCode=%i", [result[@"resultCode"] intValue]] duration:30.0 position:CSToastPositionCenter];
                        }
                    }
                    
                }
                
            }
        });
    }];
    
}


/**
 用于采集视频，仅仅上传视频，不进行DA等识别
 */
- (void)uploadVideoDataOnlyCollection
{
    NSLog(@"uploadVideoDataOnlyCollection start...");
    self.bUploadVideoDataSuccess = NO;
    
    NSDate *date = [NSDate date];
    NSTimeInterval timeIn = [date timeIntervalSince1970];

    NSString *videoPath = [self videoPath];
    NSURL *urlLocl = [NSURL fileURLWithPath:videoPath];
    NSData *videoData = [NSData dataWithContentsOfURL:urlLocl];
    
    double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
    
    [self recordSuccess:self.iFailCount DurationTime:d VideoSize:(unsigned long)videoData.length VideoTimeLenght:(self.dRecEndTimeStamp-self.dRecStartTimeStamp) SessionID:[self getUUID]];
    
    if(videoData.length == 0)
    {
        //[self.view makeToast:@"视频是空的" duration:6.0 position:CSToastPositionCenter];
        return;
    }
    
    [self.loadingRecView setHidden:NO];
    
    NSLog(@"uploadVideoData 当前视频文件大小 %f MB", [self fileSize:urlLocl]);
    
    NSString* url =  @"/kyc/api/vier/da";//@"/kyc/api/drei/da";
    
    NSString* videoTimeStamp = [NSString stringWithFormat:@"%f|%f|%f|%f", self.dRecStartTimeStamp, self.dORTHTimeStamp, self.dRecStartExposureTimeStamp, self.dRecEndTimeStamp];
    
    NSData* imgData = [self.curIDCardResult.imageDataArray firstObject];
    NSString* base64Str = [imgData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSLog(@"videoTimeStamp = %@", videoTimeStamp);
    __weak typeof(self) weakSelf = self;
    NSMutableDictionary* dicCustom = [DSLHKIDCardSDK signatureWithVideoFile:[self videoPath] TemplateImage:base64Str VideoTimeStamp:videoTimeStamp];
    
    NSString* signature = [dicCustom objectForKey:@"signature"];
    NSString* custom = [dicCustom objectForKey:@"custom"];
    
    BOOL blocking = !self.useLiteVersion;
    NSDictionary *params = @{@"contextId": [self getUUID],
                             @"equipmentModel": [[UIDevice currentDevice] ir_deviceModel],
                             @"timestamp": [NSString stringWithFormat:@"%.0f", timeIn],
                             @"pushresult": @"",
                             @"delta": @"",
                             @"fileSize":[NSString stringWithFormat:@"%lu", (unsigned long)videoData.length],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",  //新老版本标志
                             @"return_illustraon": @"1",
                             @"signature":signature,
                             @"custom":custom,
                             @"sdkBlocking": [NSString stringWithFormat:@"%d", blocking],
                             };
    [IRNetworkEngine uploadTaskIRService:url files:@[videoData] filename:@"files" header:nil parameters:params custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            weakSelf.bUploadVideoDataSuccess = YES;
            weakSelf.recStepFinishView.hidden = YES;
            
            NSLog(@"uploadVideoData end...");
            if (error) {
                NSLog(@"视频上传失败: %@", [error localizedDescription]);
                [weakSelf.view makeToast:@"视频上传失败" duration:30.0 position:CSToastPositionCenter];
                
            } else {
                NSLog(@"视频上传结果: %@", [NSString stringWithFormat:@"%@", result]);
                
                if(![result isKindOfClass:[NSNull class]] && [result[@"resultCode"] intValue] == 0)   //成功
                {
                    [weakSelf.loadingRecView setHidden:YES];
                    [weakSelf showFinishedSaveAlert:@"上传成功!"];
                }
                else
                {
                    //失败
                    [weakSelf.loadingRecView setHidden:YES];
                    if(![result isKindOfClass:[NSNull class]])   //成功
                    {
                        [weakSelf.view makeToast:[NSString stringWithFormat:@"resultCode=%i", [result[@"resultCode"] intValue]] duration:30.0 position:CSToastPositionCenter];
                    }
                    [weakSelf gotoResultFailVc];
                }
                
                
                BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:[weakSelf videoPath]];
                if(blHave)
                {
                    BOOL b = [[NSFileManager defaultManager] removeItemAtPath:[weakSelf videoPath] error:nil];
                    NSLog(@"删除视频: %@", [NSString stringWithFormat:@"%i", b]);
                }
            }
        });
    }];
    
}
/**
 视频上传接口
 */
- (void)uploadVideoData {
    // [self.view makeToastActivity:CSToastPositionCenter];
    //[self.view makeToast:@"视频上传中..."];
    NSLog(@"uploadVideoData start...");
    //[self.view makeToast:@"视频上传中..." duration:1000 position:CSToastPositionCenter];
    
    self.bUploadVideoDataSuccess = NO;
    
    NSDate *date = [NSDate date];
    NSTimeInterval timeIn = [date timeIntervalSince1970];

    NSString *videoPath = [self videoPath];
    NSURL *urlLocl = [NSURL fileURLWithPath:videoPath];
    NSData *videoData = [NSData dataWithContentsOfURL:urlLocl];
    
    double d = [[NSDate date] timeIntervalSince1970] * 1000 - self.dRecOpStartTimeStamp;
    
    [self recordSuccess:self.iFailCount DurationTime:d VideoSize:(unsigned long)videoData.length VideoTimeLenght:(self.dRecEndTimeStamp-self.dRecStartTimeStamp) SessionID:[self getUUID]];
    
    if(videoData.length == 0)
    {
        //[self.view makeToast:@"视频是空的" duration:6.0 position:CSToastPositionCenter];
        return;
    }
    
    NSLog(@"uploadVideoData 当前视频文件大小 %f MB", [self fileSize:urlLocl]);
    
    NSString* url = @"/kyc/api/vier/da";//@"/kyc/api/drei/da";
    
    NSString* videoTimeStamp = [NSString stringWithFormat:@"%f|%f|%f|%f", self.dRecStartTimeStamp, self.dORTHTimeStamp, self.dRecStartExposureTimeStamp, self.dRecEndTimeStamp];
    
    NSData* imgData = [self.curIDCardResult.imageDataArray firstObject];
    NSString* base64Str = [imgData base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    
    NSLog(@"videoTimeStamp = %@", videoTimeStamp);
    __weak typeof(self) weakSelf = self;
    NSMutableDictionary* dicCustom = [DSLHKIDCardSDK signatureWithVideoFile:[self videoPath] TemplateImage:base64Str VideoTimeStamp:videoTimeStamp];
    
    NSString* signature = [dicCustom objectForKey:@"signature"];
    NSString* custom = [dicCustom objectForKey:@"custom"];
    
    BOOL blocking = !self.useLiteVersion;
    NSDictionary *params = @{@"contextId": [self getUUID],
                             @"equipmentModel": [[UIDevice currentDevice] ir_deviceModel],
                             @"timestamp": [NSString stringWithFormat:@"%.0f", timeIn],
                             @"pushresult": @"",
                             @"delta": @"",
                             @"fileSize":[NSString stringWithFormat:@"%lu", (unsigned long)videoData.length],
                             @"version": self.recType == DSLHKIDCardTypeApp_2018 ? @"2018" : @"2003",  //新老版本标志
                             @"return_illustraon": @"1",
                             @"signature":signature,
                             @"custom":custom,
                             @"sdkBlocking": [NSString stringWithFormat:@"%d", blocking],
                             };
    

    [IRNetworkEngine uploadTaskIRService:url files:@[videoData] filename:@"files" header:nil parameters:params custom:nil completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            //[weakSelf.view hideToastActivity];
            
            weakSelf.bUploadVideoDataSuccess = YES;
            
            NSLog(@"uploadVideoData end...");
            if (error) {
                NSLog(@"视频上传失败: %@", [error localizedDescription]);
                [weakSelf.view makeToast:@"视频上传失败" duration:30.0 position:CSToastPositionCenter];
                
            } else {
                NSLog(@"视频上传结果: %@", [NSString stringWithFormat:@"%@", result]);
                
                if(![result isKindOfClass:[NSNull class]] && [result[@"resultCode"] intValue] == 0)   //成功
                {
                    if([result[@"result"][@"event"] intValue] == 100)
                    {
                        weakSelf.loadingRecView.hidden = YES;
                        //视频质量差导致无法获取OCR图片
                        [weakSelf showRecFailResult:DSLHKIDCardRecFailType_VideoQuality_Low];
                        return;
                    }
                    
                    NSDictionary* dicOCRResult = result[@"result"][@"ocr"];
                    if(dicOCRResult != nil && ![dicOCRResult isKindOfClass:[NSNull class]])
                    {
                        NSArray* arr = dicOCRResult[@"occlusion"];
                        if([arr count] > 0)
                        {
                            weakSelf.resultInfoModel.fingerOcclusionNum = [arr componentsJoinedByString:@","];
                        }
                        
                        weakSelf.resultInfoModel.gender = dicOCRResult[@"sex"];
                        if([weakSelf isCurrentLanguageEn])
                        {
                            weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_en"];
                            weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_en"];
                        }
                        else
                        {
                            weakSelf.resultInfoModel.firstName = dicOCRResult[@"name_cn"];
                            weakSelf.resultInfoModel.certiType = dicOCRResult[@"title_cn"];
                        }
                        weakSelf.resultInfoModel.certiNo = dicOCRResult[@"card_number"];
                        weakSelf.resultInfoModel.birthday = dicOCRResult[@"date_birth"];

                        NSLog(@"OCR info: gender:%@, certiType:%@, certiNo:%@, birthday:%@, firstName:%@", weakSelf.resultInfoModel.gender, weakSelf.resultInfoModel.certiType, weakSelf.resultInfoModel.certiNo, weakSelf.resultInfoModel.birthday, weakSelf.resultInfoModel.firstName);
                    }
                
                    NSDictionary* dicDaResult =  result[@"result"][@"da"][@"detail"];
                    if(weakSelf.recType == DSLHKIDCardTypeApp_2018)
                    {
                        if(![dicDaResult[@"face_similarity"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"face_similarity"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                 weakSelf.resultInfoModel.bFaceSimilarity = [dicDaResult[@"face_similarity"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"color_printing"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"color_printing"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bColorPrinting = [dicDaResult[@"color_printing"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"image_quality"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"image_quality"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bImageQuality = [dicDaResult[@"image_quality"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"laser_face"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"laser_face"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bLaserFace = [dicDaResult[@"laser_face"][@"is_accept"] boolValue];
                            }
                        }
                        
                        if(![dicDaResult[@"laser_redbud"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"laser_redbud"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bLaserRedbud = [dicDaResult[@"laser_redbud"][@"is_accept"] boolValue];
                                weakSelf.resultInfoModel.laserRedbudScore = [dicDaResult[@"laser_redbud"][@"score"] doubleValue];
                            }
                        }
                        
                        
                        if(![dicDaResult[@"highlight"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"highlight"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bHighlight = [dicDaResult[@"highlight"][@"is_accept"] boolValue];
                            }
                        }
                 
                        //证件是否被篡改
                        if(![dicDaResult[@"tampered"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"tampered"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bTampered = [dicDaResult[@"tampered"][@"is_accept"] boolValue];
                            }
                        }
                        //材质检测
                        if(![dicDaResult[@"deep_rtriangle"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"deep_rtriangle"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bDeep_rtriangle = [dicDaResult[@"deep_rtriangle"][@"is_accept"] boolValue];
                            }
                        }
                        
                    }
                    else
                    {
                        //动感印刷HK字母是否通过
                        if(![dicDaResult[@"H_K"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"H_K"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bHkOld = [dicDaResult[@"H_K"][@"is_accept"] boolValue];
                            }
                        }
                        //变色油墨是否通过
                        if(![dicDaResult[@"optical_variable"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"optical_variable"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bTriColorOld = [dicDaResult[@"optical_variable"][@"is_accept"] boolValue];
                            }
                        }
                        
                        //动感印刷人脸变化是否通过
                        if(![dicDaResult[@"smallface"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"smallface"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bSmallFace = [dicDaResult[@"smallface"][@"is_accept"] boolValue];
                            }
                        }
                        //证件人脸对比是否通过
                        if(![dicDaResult[@"face_similarity"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"face_similarity"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bFaceSimilarity = [dicDaResult[@"face_similarity"][@"is_accept"] boolValue];
                            }
                        }
                        //芯片匹配是否通过
                        if(![dicDaResult[@"chip_match"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"chip_match"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bChipOld = [dicDaResult[@"chip_match"][@"is_accept"] boolValue];
                            }
                        }
                        //图像亮度是否通过
                        if(![dicDaResult[@"reflection"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"reflection"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bHighlight = [dicDaResult[@"reflection"][@"is_accept"] boolValue];
                            }
                        }
                        //渐变色特征是否通过
                        if(![dicDaResult[@"gradual_color"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"gradual_color"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bGradualOld = [dicDaResult[@"gradual_color"][@"is_accept"] boolValue];
                            }
                        }
                 
                        //证件是否被篡改
                        if(![dicDaResult[@"tampered"] isKindOfClass:[NSNull class]])
                        {
                            if(![dicDaResult[@"tampered"][@"is_accept"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.bTampered = [dicDaResult[@"tampered"][@"is_accept"] boolValue];
                            }
                        }
                        
                    }
                    
                    //验真结果分数
                    if(![result[@"result"][@"da"][@"authenticity"] isKindOfClass:[NSNull class]])
                    {
                        if(![result[@"result"][@"da"][@"authenticity"][@"score"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.authenticity = [result[@"result"][@"da"][@"authenticity"][@"score"] doubleValue];
                        }
                        
                        if(![result[@"result"][@"da"][@"authenticity"][@"thresholds"] isKindOfClass:[NSNull class]])
                        {
                            
                             if(![result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"high_risk"] isKindOfClass:[NSNull class]])
                             {
                                 weakSelf.resultInfoModel.low_threshold = [result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"high_risk"] doubleValue];
                             }
                            
                            if(![result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"low_risk"] isKindOfClass:[NSNull class]])
                            {
                                weakSelf.resultInfoModel.high_threshold = [result[@"result"][@"da"][@"authenticity"][@"thresholds"][@"low_risk"] doubleValue];
                            }
                        }
                        
                    }
                    
                    //视频质量分数
                    if(![result[@"result"][@"da"][@"quality"] isKindOfClass:[NSNull class]])
                    {
                        if(![result[@"result"][@"da"][@"quality"][@"score"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.qualityScore = [result[@"result"][@"da"][@"quality"][@"score"] doubleValue];
                        }
                        
                        if(![result[@"result"][@"da"][@"quality"][@"threshold"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.qualitythreshold = [result[@"result"][@"da"][@"quality"][@"threshold"] doubleValue];
                        }
                    }
                    
                    //是否翻拍
                    
                    if(![dicDaResult[@"reproduction"] isKindOfClass:[NSNull class]])
                    {
                        if(![dicDaResult[@"reproduction"][@"is_reproduction"] isKindOfClass:[NSNull class]])
                        {
                            weakSelf.resultInfoModel.bReproduction = [dicDaResult[@"reproduction"][@"is_reproduction"] boolValue];
                        }
                    }
                    
                    NSData * idImageData = nil;
                    if(![result[@"result"][@"da"][@"image"] isKindOfClass:[NSNull class]])
                    {
                        NSString* imgStr = result[@"result"][@"da"][@"image"];
                        if(imgStr != nil)
                        {
                            idImageData   = [[NSData alloc] initWithBase64EncodedString:imgStr options:NSDataBase64DecodingIgnoreUnknownCharacters];
                        }

                    }
                    else
                    {
                        idImageData = [weakSelf.curIDCardResult.imageDataArray firstObject];
                    }
                    weakSelf.resultInfoModel.imgIdCard = idImageData;
                    if(weakSelf.bUploadFaceRecognitionSuccess)
                    {
                        weakSelf.loadingRecView.hidden = YES;
                        [weakSelf gotoResultVc:weakSelf.resultInfoModel];
                    }
                }
                else
                {
                    //失败
                    if(weakSelf.bUploadFaceRecognitionSuccess)
                    {
                        
                         if(![result isKindOfClass:[NSNull class]])   //成功
                         {
                            [weakSelf.view makeToast:[NSString stringWithFormat:@"resultCode=%i", [result[@"resultCode"] intValue]] duration:30.0 position:CSToastPositionCenter];
                         }

                        weakSelf.loadingRecView.hidden = YES;
                        [weakSelf gotoResultFailVc];
                    }
                }
                
                
                BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:[weakSelf videoPath]];
                if(blHave)
                {
                    BOOL b = [[NSFileManager defaultManager] removeItemAtPath:[weakSelf videoPath] error:nil];
                    NSLog(@"删除视频: %@", [NSString stringWithFormat:@"%i", b]);
                }
                
            }
        });
    }];
}

/**
 人脸比对上传接口
 
 @param imgRec 证件图片
 @param imgFace 人脸图片
 */
- (void)uploadFaceRecognition:(NSData* )imgRec ImgFace:(NSData* )imgFace
{
    
    if(imgRec == nil)
    {
        [self.view makeToast:@"证件图片空" duration:30.0 position:CSToastPositionCenter];
        return;
    }
    if(imgFace == nil)
    {
        [self.view makeToast:@"人脸图片空" duration:30.0 position:CSToastPositionCenter];
        return;
    }
    
    self.bUploadFaceRecognitionSuccess = NO;
    self.loadingRecView.hidden = NO;
    
    NSString* url = @"/kyc/api/drei/face";
 
    __weak typeof(self) weakSelf = self;
    NSArray* arr = [NSArray arrayWithObjects:imgRec, imgFace, nil];
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *app_Version = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    
    [IRNetworkEngine uploadTaskIRService:url files:arr filename:@"files" header:nil  parameters:@{@"contextId":[self getUUID]} custom:@{@"appVersion": [NSString stringWithFormat:@"%@", app_Version]} completionHandler:^(NSDictionary * _Nullable result, NSError * _Nullable error) {
        dispatch_async(dispatch_get_main_queue(), ^{
          
            weakSelf.bUploadFaceRecognitionSuccess = YES;
            
            NSLog(@"uploadFaceRecognition end...");
            
            NSDictionary* dicFaceResult = result[@"result"];

            if([result isKindOfClass:[NSNull class]]
               ||
               ([result[@"success"] intValue] == 0)
               ||
               (dicFaceResult == nil || [dicFaceResult isKindOfClass:[NSNull class]])
               )
            {
                weakSelf.loadingRecView.hidden = YES;
                [weakSelf.view makeToast:@"人脸比对结果返回错误" duration:30.0 position:CSToastPositionCenter];
                [weakSelf gotoResultFailVc];
            }
            else
            {
                if(![result[@"result"][@"verifySimilarity"] isKindOfClass:[NSNull class]])
                {
                    weakSelf.resultInfoModel.similarity = [result[@"result"][@"verifySimilarity"] doubleValue];
                    
                }
                if(![result[@"result"][@"resultCode"] isKindOfClass:[NSNull class]])
                {
                    weakSelf.resultInfoModel.bFaceVerifyValid = [result[@"result"][@"resultCode"] intValue] == 0 ? YES : NO;
                    
                }
                
                if(weakSelf.bUploadVideoDataSuccess)
                {
                    weakSelf.loadingRecView.hidden = YES;
                    [weakSelf gotoResultVc:weakSelf.resultInfoModel];
                }
                
            }
            
            
            
        });
    }];
}

- (void)gotoResultVc:(ResultInfoModel* )model
{
    DSLHKIDCardResultController* vc = [[DSLHKIDCardResultController alloc] init];
    vc.imgFaceRec = self.curImgFaceData;
    vc.imgSmallHead = [UIImage imageWithData:[self.curIDCardResult.imageDataArray lastObject]];
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    vc.imgIDCard =  [UIImage imageWithData:model.imgIdCard];

    vc.resultInfoModel = model;
    if(self.bOCRCheckCodeFail)
    {
        vc.resultInfoModel.authenticity = 0.0;
    }

    vc.recType = self.recType;
    
    if(self.contextId != nil &&  ![self.contextId isEqualToString:@""])
    {
        vc.recID = [self.contextId substringWithRange:NSMakeRange(self.contextId.length-8, 8)];
    }
    else
    {
        vc.recID = @"ABCDEFGH";
    }
    
    self.bUploadVideoDataSuccess = NO;
    self.bUploadFaceRecognitionSuccess = NO;
    
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)gotoResultFailVc
{
    DSLHKIDCardResultFailViewController* vc = [[DSLHKIDCardResultFailViewController alloc] init];
    vc.myDelegate = self;
    vc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:vc animated:YES completion:nil];
}

- (BOOL)isCurrentLanguageEn
{
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages objectAtIndex:0];
    if ([currentLanguage containsString:@"en-"])
    {
        return YES;
    }
    
    return NO;
}

#pragma mark-- DSLHKIDCardResultFailVcDelegate methods
- (void)resultFailDismissVc
{
    //[self.presentingViewController dismissViewControllerAnimated:NO completion:nil];
   [[AppDelegate sharedInstance] gotoMainVc];
}

@end

