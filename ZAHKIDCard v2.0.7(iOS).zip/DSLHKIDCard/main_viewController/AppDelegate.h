//
//  AppDelegate.h
//  DSLHKIDCard
//
//  Created by chenliqun on 2019/5/8.
//  Copyright © 2019 chenliqun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSLHKIDCardEnumType.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

+(instancetype)sharedInstance;

- (void)gotoLoginVc;

- (void)gotoMainVc;

- (void)gotoIDCardVc:(DSLHKIDCardTypeApp)recType useLiteVersion:(BOOL)userLiteVersion;

- (void)gotoMCVVc;

- (void)gotoHKIDCard_MCV;

@end

