//
//  TotalResultView.h
//  TestHKIDCard
//
//  Created by chenliqun on 2019/5/20.
//  Copyright © 2019 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol TotalResultViewDelegate <NSObject>

- (void)clickTotalResultViewExplain;

@end

@interface TotalResultView : UIView

@property(nonatomic, assign) id<TotalResultViewDelegate> myDelegate;

- (void)setTotalResult:(NSString* )strTotalScore VideoQuality:(NSString* )videoQuality TotalScoreColor:(UIColor* )color IsShowTipText:(BOOL) showTipText LevelRisk:(int) levelRisk;

@end

NS_ASSUME_NONNULL_END
