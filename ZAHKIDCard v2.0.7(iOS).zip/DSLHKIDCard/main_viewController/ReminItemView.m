//
//  ReminItemView.m
//  DSLHKIDCard
//
//  Created by chenliqun on 2020/9/10.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import "ReminItemView.h"
#import "UIColor+DSLCHexColor.h"
@interface ReminItemView()
@property(nonatomic, strong) UIImageView* imgViewHead;
@property(nonatomic, strong) UILabel* labelTitle1;
@property(nonatomic, strong) UILabel* labelTitle2;

@end

@implementation ReminItemView

- (instancetype)initWithFrame:(CGRect)frame ImageHead:(UIImage*)imgHead Title1:(NSString* )title1 Title2:(NSString* )title2
{
    if(self = [super initWithFrame:frame])
    {
        [self setupView: imgHead Title1:title1 Title2:title2];
    }
    
    return self;
}

- (void)setupView:(UIImage*)imgHead Title1:(NSString* )title1 Title2:(NSString* )title2
{
    [self addSubview:self.imgViewHead];
    self.imgViewHead.image = imgHead;
    self.imgViewHead.frame = CGRectMake(0.0, 0.0, 103, 103);
    
    [self addSubview:self.labelTitle1];
    self.labelTitle1.text = title1;
    self.labelTitle1.frame = CGRectMake(self.imgViewHead.frame.origin.x+self.imgViewHead.frame.size.width+14, 22.0, 200, 52);
    
    [self addSubview:self.labelTitle2];
    self.labelTitle2.text = title2;
    self.labelTitle2.frame = CGRectMake(self.imgViewHead.frame.origin.x+self.imgViewHead.frame.size.width+10+30, self.labelTitle1.frame.origin.y+self.labelTitle1.frame.size.height+ 10.0, 200, 52);
}

- (UILabel* )labelTitle1
{
    if (_labelTitle1 == nil) {
        _labelTitle1 = [[UILabel alloc] init];
        _labelTitle1.textAlignment = NSTextAlignmentLeft;
        _labelTitle1.textColor = [UIColor dslc_colorWithHexString:@"0x02A6CA"];
        _labelTitle1.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
        _labelTitle1.text = @"⚠️ 證件不要放在桌上";
        _labelTitle1.lineBreakMode = NSLineBreakByWordWrapping;
        _labelTitle1.numberOfLines = 0;
        
    }
    return _labelTitle1;
}

- (UILabel* )labelTitle2
{
    if (_labelTitle2 == nil) {
        _labelTitle2 = [[UILabel alloc] init];
        _labelTitle2.textAlignment = NSTextAlignmentLeft;
        _labelTitle2.textColor = [UIColor dslc_colorWithHexString:@"0x7F7F7F"];
        _labelTitle2.font = [UIFont fontWithName:@"PingFangSC-Medium" size:18];
        _labelTitle2.text = @"手持身份證邊緣";
        _labelTitle2.lineBreakMode = NSLineBreakByWordWrapping;
        _labelTitle2.numberOfLines = 0;
        
    }
    return _labelTitle2;
}

- (UIImageView* )imgViewHead
{
    if(_imgViewHead == nil)
    {
        _imgViewHead = [[UIImageView alloc] init];
    }
    return _imgViewHead;
}

@end
